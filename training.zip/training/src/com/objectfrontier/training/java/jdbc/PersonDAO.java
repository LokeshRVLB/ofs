package com.objectfrontier.training.java.jdbc;

import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 27, 2018
 */
public interface PersonDAO {

    List<Person> readALL();
    Person read(int id) throws DataBaseException;
    Person read(int id, boolean includeAddress) throws DataBaseException;
    int update(int id, Person person) throws DataBaseException;
    int delete(int id) throws DataBaseException;
    long insert(Person person) throws DataBaseException;
    boolean isPresent(String field, Object value) throws DataBaseException;
}
