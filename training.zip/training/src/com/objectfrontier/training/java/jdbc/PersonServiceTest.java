package com.objectfrontier.training.java.jdbc;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.time.LocalDateTime;
import java.util.Properties;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author Lokesh.
 * @since Sep 24, 2018
 */
public class PersonServiceTest {

    private PersonService personService;
    @BeforeClass
    private void initService() {
        try (InputStream propertyFileStream = getClass().getResourceAsStream("mysqlCredentials.txt")) {
            Properties mysqlCredentials = new Properties();
            mysqlCredentials.load(propertyFileStream);
            try {
                Connection connection = DriverManager.getConnection("jdbc:mysql://pc1620:3306/lokesh_rajendran", mysqlCredentials);
                personService = new PersonService(connection);
            } catch (SQLException e) {
                throw new RuntimeException("Unable to establish connection, Check credentials");
            }
        } catch (IOException e) {
            throw new RuntimeException("Unable to read properties file");
        }
    }

    @Test (dataProvider = "positiveCase_insertRecord")
    private void insertRecordTest_positive(long expectedResult, Person person) {
        long actualResult = 0;
        try {
            actualResult = personService.insertRecord(person);
            System.out.println(actualResult);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, person));
        }
    }

    @Test (dataProvider = "negativeCase_insertRecord")
    private void insertRecordTest_negative(Person person, DataBaseException expectedResult) {
        try {
            personService.insertRecord(person);
            Assert.fail(MessageFormat.format("Expected an Exception for {0}", person));
        } catch (DataBaseException e) {
            Assert.assertEquals(e.getAssociateErrorsAsCollection().toString(), expectedResult.getAssociateErrorsAsCollection().toString());
        }
    }



    @DataProvider (name = "positiveCase_insertRecord")
    private Object[][] insertRecordTest_positiveDP() {
        Address address = new Address("hassan khan street", "Chittoor", 517001);
        return new Object[][] {
            {5, new Person("R.Boovan", "boovanNaiks@gmail.com", address, Person.getDate(1997, 1, 1))},
            {6, new Person("R.Rajendran", "RajendranNaikar2@gmail.com", null, Person.getDate(1997, 1, 1))},
            {7, new Person("R.BoovanClone", "boovanNaiker3S@gmail.com", address, Person.getDate(1997, 1, 1))}
        };
    }

    @DataProvider (name = "negativeCase_insertRecord")
    private Object[][] insertRecordTEst_negativeDP() {

        Address address = new Address("hassan khan street", "Chittoor", 517001);
        DataBaseException dataBaseException = new DataBaseException();
        dataBaseException.add(new DataBaseException("Name cannot be Empty"));
        dataBaseException.add(new DataBaseException("Email id already exists"));

        return new Object[][] {
            {new Person(null, "lokeshbalaji68@gmail.com", address, Person.getDate(1997, 1, 1)), dataBaseException},
        };
    }

    @DataProvider (name = "positiveCase_delete")
    private Object[][] deleteTest_positiveDP() {
        Address address = new Address("hassan khan street", "Chittoor", 517001);
        return new Object[][] {
            {1, 1},
            {2, 1},
            {3, 1}
        };
    }

    @DataProvider (name = "positiveCase_read")
    private Object[][] readTest_positiveDP() {
        Address address = new Address("hassan khan street", "Chittoor", 517001);
        address.setId(3);
        Person personOne = new Person("R.Boovan", "boovanNaiks@gmail.com", address, Person.getDate(1997, 1, 1));
        personOne.setId(6);
        personOne.setCreatedDate(LocalDateTime.of(2018, 9, 24, 16, 47, 55));
        Person personTwo = new Person("R.Rajendran", "RajendranNaikar@gmail.com", null, Person.getDate(1997, 1, 1));
        personTwo.setId(7);
        personTwo.setCreatedDate(LocalDateTime.of(2018, 9, 24, 16, 47, 55));
        return new Object[][] {
            {personOne, 6, true},
            {personTwo, 7, false}
        };
    }

    @DataProvider(name = "positiveCase_update")
    private Object[][] updateTest_positiveDP() {
        return new Object[][] {
            
        };
    }
    @AfterClass
    private void afterClass() {

    }
}
