package com.objectfrontier.training.service.DAO;

import java.util.List;

import com.objectfrontier.training.java.jdbc.DataBaseException;
import com.objectfrontier.training.service.entity.DTO.PersonDTO;
import com.objectfrontier.training.service.entity.POJO.Person;

/**
 * @author Lokesh.
 * @since Sep 27, 2018
 */
public interface PersonDAO {

    List<Person> readAll() throws DataBaseException;
    Person read(int id) throws DataBaseException;
    Person read(int id, boolean includeAddress) throws DataBaseException;
    PersonDTO update(int id, Person person) throws DataBaseException;
    PersonDTO delete(int id) throws DataBaseException;
    PersonDTO insert(Person person) throws DataBaseException;
    boolean isPresent(String field, Object value) throws DataBaseException;
}
