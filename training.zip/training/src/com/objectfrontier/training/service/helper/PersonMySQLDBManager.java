package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.java.jdbc.DataBaseException;
import com.objectfrontier.training.service.DAO.PersonDAO;
import com.objectfrontier.training.service.entity.DTO.PersonDTO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public class PersonMySQLDBManager implements PersonDAO{

	ConnectionManager connectionManager;
	
	public PersonMySQLDBManager(ConnectionManager connectionManager) {
		this.connectionManager = connectionManager;
	}

	@Override
	public List<Person> readAll() throws DataBaseException {
		String query = new StringBuilder().append("SELECT person.id")
										  .append("		 ,person.first_name")
										  .append("		 ,person.last_name")
										  .append("		 ,person.dob")
										  .append("      ,address.id")
										  .append("	 	 ,address.street")
										  .append("		 ,address.city")
										  .append("		 ,address.postal_code ")
										  .append("FROM person ")
										  .append("LEFT JOIN address ")
										  .append("ON person.address_id = address.id ").toString();
		QueryManager<List<Person>, ResultSet> readAll = (resultSet) -> {
			ArrayList<Person> persons = new ArrayList<>(resultSet.getFetchSize());
			while (resultSet.next()) {
				Person person = new Person();
				Address address;
				person.setId(resultSet.getLong(1));
				person.setFirstName(resultSet.getString(2));
				person.setLastName(resultSet.getString(3));
				person.setBirthDate(resultSet.getDate(4).toLocalDate());
				address = new Address(resultSet.getString(6), resultSet.getString(7), resultSet.getLong(8));
				address.setId(resultSet.getLong(5));
				person.setAddress(address);
				persons.add(person);
			}
			return persons;
		};
		try {
			return readAll.execute(query, null, connectionManager, false, 0);
		} catch (SQLException e) {
			throw new DataBaseException(e);
		}
	}

	@Override
	public Person read(int id) throws DataBaseException {
		String query = new StringBuilder().append("SELECT person.id")
										  .append("		 ,person.first_name")
				 						  .append("		 ,person.last_name")
										  .append("		 ,person.dob")
										  .append("      ,address.id")
										  .append("	 	 ,address.street")
										  .append("		 ,address.city")
										  .append("		 ,address.postal_code ")
										  .append("FROM person ")
										  .append("LEFT JOIN address ")
										  .append("ON person.address_id = address.id ")
										  .append("WHERE person.id = ?").toString();
		QueryManager<Person, ResultSet> read = (resultSet) -> {
			Person person = new Person();
			Address address;
			while (resultSet.next()) {
				person.setId(resultSet.getLong(1));
				person.setFirstName(resultSet.getString(2));
				person.setLastName(resultSet.getString(3));
				person.setBirthDate(resultSet.getDate(4).toLocalDate());
				address = new Address(resultSet.getString(6),
						  			  resultSet.getString(7),
						  			  resultSet.getLong(8));
				address.setId(resultSet.getLong(5));
				person.setAddress(address);
			}
			return person;
		};
		try {
			List<Object> parameters = new ArrayList<>();
			parameters.add(id);
			return read.execute(query, parameters, connectionManager, false, 0);
		} catch (SQLException e) {
			throw new DataBaseException(e);
		}
	}

	@Override
	public Person read(int id, boolean includeAddress) throws DataBaseException {
		if (!includeAddress) {
			String query = new StringBuilder().append("SELECT person.id")
											  .append("		 ,person.first_name")
											  .append("		 ,person.last_name")
											  .append("		 ,person.dob ")
											  .append("FROM person WHERE person.id = ?").toString();
			QueryManager<Person, ResultSet> read = (resultSet) -> {
				Person person = new Person();
				while (resultSet.next()) {
					person.setId(resultSet.getLong(1));
					person.setFirstName(resultSet.getString(2));
					person.setLastName(resultSet.getString(3));
					person.setBirthDate(resultSet.getDate(4).toLocalDate());
				}
				return person;
			};
			try {
				List<Object> parameters = new ArrayList<>();
				parameters.add(id);
				return read.execute(query, parameters, connectionManager, false, 0);
			} catch (SQLException e) {
				throw new DataBaseException(e);
			}
		}
		
		return read(id);
	}

	@Override
	public PersonDTO update(int id, Person person) throws DataBaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonDTO delete(int id) throws DataBaseException {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public PersonDTO insert(Person person) throws DataBaseException {

		long addressId = 0;
		Address address = person.getAddress();
		String insertAddressQuery = new StringBuilder().append("INSERT INTO address (address.street")
				  								   .append("	         			 ,address.city")
				  								   .append("	         			 ,address.postal_code) ")
				  								   .append("VALUES (?, ?, ?)").toString();
		QueryManager<Long, Long> insertAddress = (addrId) -> addrId;
		try {
			List<Object> parameters = new ArrayList<>();
			parameters.add(0,address.getStreet());
			parameters.add(1,address.getCity());
			parameters.add(2,address.getPostalCode());
			addressId = insertAddress.execute(insertAddressQuery, parameters, connectionManager, true, Statement.RETURN_GENERATED_KEYS);
		} catch (SQLException e) {
			throw new DataBaseException(e);
		}
		
		PersonDTO personDTO = null;
		String insertPersonQuery = new StringBuilder().append("INSERT INTO person (person.first_name")
										              .append("	          		   ,person.last_name")
										              .append("	          		   ,person.dob")
										              .append("	          	       ,person.address_id) ")
										              .append("VALUES (?, ?, ?, ?)").toString();
		QueryManager<Long, Long> insertPerson = (personId) -> personId; 
		try {
			List<Object> parameters = new ArrayList<>();
			parameters.add(0, person.getFirstName());
			parameters.add(1, person.getLastName());
			parameters.add(2, java.sql.Date.valueOf(person.getBirthDate()));
			parameters.add(3, addressId);
			long personId = insertPerson.execute(insertPersonQuery, parameters, connectionManager, true,  Statement.RETURN_GENERATED_KEYS);
			personDTO = new PersonDTO(person.getFirstName(), person.getLastName(), person.getEmail());
			personDTO.setId(personId);
			return personDTO;
		} catch (SQLException e) {
			throw new DataBaseException(e);
		}
	}

	@Override
	public boolean isPresent(String field, Object value) throws DataBaseException {
		// TODO Auto-generated method stub
		return false;
	}

}
