package com.objectfrontier.training.service.helper;

import java.io.IOException;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;

import com.objectfrontier.training.java.jdbc.DataBaseException;
import com.objectfrontier.training.service.entity.DTO.PersonDTO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public class Testing {

	public static void main(String[] args) throws IOException, SQLException, DataBaseException {
		ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://localhost:3306/lokesh_rajendran", "mysqlCredentials.txt");
		connectionManager.getConnection();
		PersonMySQLDBManager personManager = new PersonMySQLDBManager(connectionManager);
		System.out.println(personManager.readAll());
		Address address = new Address("Ragava street", "chennai", 600113);
		Person person = new Person("Lokesh2","Balaji2", "lokes", address, LocalDate.of(2018, 3, 3));
		PersonDTO personDTO = personManager.insert(person);
		System.out.println(personDTO.getFirstName() + " " + personDTO.getLastName() + " " + personDTO.getId());
	}
	
}
