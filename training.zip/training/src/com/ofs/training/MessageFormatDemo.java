package com.ofs.training;


import java.text.DateFormat;
import java.text.MessageFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;
import java.util.Date;

/**
 * @author Lokesh.
 * @since Sep 26, 2018
 */
public class MessageFormatDemo {

    public static void main(String[] args) {
        MessageFormatDemo obj = new MessageFormatDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws ParseException {

        Date date = new Date();
        DateFormat dFormatter;
        dFormatter = DateFormat.getDateInstance(DateFormat.SHORT, Locale.JAPAN);
        log("%s%n", dFormatter.format(date));
        dFormatter = DateFormat.getDateInstance(DateFormat.LONG, Locale.US);
        log("%s%n", dFormatter.format(date));
        dFormatter = DateFormat.getDateInstance(DateFormat.MEDIUM, Locale.KOREA);
        log("%s%n", dFormatter.format(date));
        log("%s%n", new SimpleDateFormat("dd-MM-yy", Locale.getDefault()).parse("06-08-1996"));
        dFormatter = DateFormat.getTimeInstance(DateFormat.SHORT, Locale.JAPAN);
        log("%s%n", dFormatter.format(date));
        dFormatter = DateFormat.getTimeInstance(DateFormat.LONG, Locale.US);
        log("%s%n", dFormatter.format(date));
        dFormatter = DateFormat.getTimeInstance(DateFormat.MEDIUM, Locale.UK);
        log("%s%n", dFormatter.format(date));
        log("%s%n", MessageFormat.format("hai hello", Locale.JAPAN));
        log("%s%n", MessageFormat.format("hai hello", Locale.KOREA));
        log("%s%n", MessageFormat.format("hai hello", Locale.UK));
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
