package com.ofs.training;

import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class ForEachDemo {

    public static void main(String[] args) {
        ForEachDemo forEachDemo = new ForEachDemo();
        forEachDemo.run();
    }

    private void run() {
        List<Person> persons = Person.createRoster();
        persons.stream().forEach(person -> log("%s%n", person));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
