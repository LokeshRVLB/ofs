package com.ofs.training;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 * @author Lokesh.
 * @since Sep 18, 2018
 */
public class ObjectToInputStreamConvertor {

    public static void main(String[] args) {
        ObjectToInputStreamConvertor obj = new ObjectToInputStreamConvertor();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws Throwable {

        try (FileInputStream fileInputStream = new FileInputStream("D:/temp/temp.txt");
             FileOutputStream fileOutputStream = new FileOutputStream("D:/temp/temp.txt")) {

            ObjectOutputStream objectOutputStream = new ObjectOutputStream(fileOutputStream);
            objectOutputStream.writeObject(new String("Lokesh"));

            ObjectInputStream objectInput = new ObjectInputStream(fileInputStream);
            String data = objectInput.readUTF();
            log("%s", data);
        } catch (Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
