package com.ofs.training;

import java.math.BigDecimal;
import java.math.RoundingMode;

/**
 * @author Lokesh.
 * @since Sep 26, 2018
 */
public class MathDemo {

    public static void main(String[] args) {
        MathDemo obj = new MathDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        BigDecimal bDecimal = new BigDecimal(Double.toString(1.234567889));
        BigDecimal bDecimalTwo = new BigDecimal(Double.toString(1.3));
        log("%s%n", bDecimal);
        log("%s%n", bDecimal.setScale(3, RoundingMode.HALF_UP));
        log("%s%n", bDecimal.abs());
        log("%s%n", bDecimal.setScale(0, RoundingMode.CEILING));
        log("%s%n", bDecimal.setScale(0, RoundingMode.FLOOR));
        log("%s%n", bDecimal.max(bDecimalTwo));
        log("%s%n", bDecimal.min(bDecimalTwo));
        log("%s%n", Math.rint(bDecimal.doubleValue()));
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
