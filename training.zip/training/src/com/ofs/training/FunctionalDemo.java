package com.ofs.training;

public class FunctionalDemo {

	public static void main(String[] args) {
//		FunctionalInterfaceDemo fiDemo = new FunctionalInterfaceDemo() {
//			
//			@Override
//			public int calculateResult() {
//				
//				return 10;
//			}
//		};
		FunctionalInterfaceDemo fiDemo = () -> 10;
		System.out.println(fiDemo.showResult());
		
	}
}
