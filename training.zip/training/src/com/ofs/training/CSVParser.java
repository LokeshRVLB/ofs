package com.ofs.training;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.ZoneId;
import java.util.Date;
import java.util.List;
import java.util.StringTokenizer;
import java.util.stream.Collectors;


/**
 * @author Lokesh.
 * @since Sep 19, 2018
 */
public class CSVParser {

    public static void main(String[] args) {
        CSVParser obj = new CSVParser();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        csvToList().stream().forEach(person -> log("%s%n", person));
    }

    private List<Person> csvToList(){

        try (InputStream fileStream = getClass().getResourceAsStream("test.csv")){
            BufferedReader csvStream = new BufferedReader(new InputStreamReader(fileStream));
            return csvStream.lines()
                            .map(CSVParser::personMapper)
                            .collect(Collectors.toList());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static Person personMapper(String csvRecord) {
        StringTokenizer tokenizer = new StringTokenizer(csvRecord, ",");
        Person person = new Person();
        while (tokenizer.hasMoreTokens()) {
            person.setName(tokenizer.nextToken());
            person.setEmailAddress(tokenizer.nextToken());
            Date date;
            try {
                date = new SimpleDateFormat("dd-mm-yy").parse(tokenizer.nextToken());
            } catch (ParseException e) {
                // TODO Auto-generated catch block
                throw new RuntimeException(e);
            }
            person.setBirthday(date.toInstant().atZone(ZoneId.systemDefault()).toLocalDate());
            person.setGender(Person.Sex.valueOf(Person.Sex.class, tokenizer.nextToken()));
        }
        return person;
    }
    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
