package com.ofs.training;

import java.util.HashMap;
import java.util.Map.Entry;
import java.util.Set;

/**
 * @author Lokesh.
 * @since Sep 22, 2018
 */
public class MapDemo {

    public static void main(String[] args) {
        MapDemo obj = new MapDemo();
        obj.run();

    }

    private void run() {

        HashMap<String, String> name = new HashMap<String, String>();
        name.put("Lokesh", "naidu");
        name.put("Boovan", "naidu");
        name.put("Vijaya", "naidu");
        name.put("Rajendran", "naidu");
        Set<Entry<String,String>> data = name.entrySet();
        data.stream().forEach((key) -> key.setValue("reddy"));
        log("%s%n", name.get("Lokesh"));
        log("%s%n", name.get("Boovan"));
        log("%s%n", name.get("Vijaya"));
        log("%s%n", name.get("Rajendran"));
//        name.compute("Lokesh", (k, v) -> { if (v != null) return "naidu"; else return "Reddy"; });
//        log("%s%n", name.get("Lokesh"));
//        String updatedName = name.merge("Lokesh", "naidu", (k, v) -> "Balaji");
//        log("%s%n", updatedName);
//        log("%s%n", name.get("Lokesh"));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
