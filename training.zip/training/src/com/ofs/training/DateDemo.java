package com.ofs.training;

import java.time.LocalDateTime;
import java.util.Calendar;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author Lokesh.
 * @since Sep 20, 2018
 */
public class DateDemo {

    public static void main(String[] args) {
        DateDemo obj = new DateDemo();
        obj.run();

    }

    private void run() {

        Date date = new Date(System.currentTimeMillis());
        log("%s%n", date);

        Date date2 = new Date();
        log("%s%n", date2);

        Date date3 = Calendar.getInstance().getTime();
        log("%s%n", date3);
        log("%s%n", Calendar.getInstance().getTimeZone());
        log("%s%n", TimeZone.getDefault());
//        log("%b%n", TimeZone.getDefault().useDaylightTime());
//        Arrays.stream(Calendar.getAvailableLocales()).forEach(locale -> log("%s%n", locale));
//        TimeZone timeZone2 = TimeZone.getDefault();
//        log("%s%n", timeZone2.getDisplayName());
//        log("%s%n", timeZone2.getDisplayName(false, TimeZone.LONG));
//        log("%s%n", timeZone2.getDisplayName(false, TimeZone.SHORT));
//        log("%d%n", timeZone2.getOffset(System.currentTimeMillis()));
//        Arrays.stream(TimeZone.getAvailableIDs(timeZone2.getOffset(System.currentTimeMillis()))).forEach(timeZone -> log("%s%n", timeZone));
//        GregorianCalendar gregoryCalendar = (GregorianCalendar) Calendar.getInstance();
//        log("%s%n", gregoryCalendar.getCalendarType());
//        TimeZone timeZone = TimeZone.getTimeZone("Asia/Oral");
//        TimeZone.setDefault(timeZone);
//        Calendar calendar = Calendar.getInstance(timeZone, Locale.ENGLISH);
//        log("%s%n", calendar.getTime());
        LocalDateTime localDateTime = LocalDateTime.now();
        log("%s%n", localDateTime);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
