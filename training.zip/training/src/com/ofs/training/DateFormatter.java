package com.ofs.training;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * @author Lokesh.
 * @since Sep 20, 2018
 */
public class DateFormatter {

    public static void main(String[] args) {
        DateFormatter obj = new DateFormatter();
        obj.run();

    }

    private void run() {

//        DateFormat dateFormat = new SimpleDateFormat("yyyy.mm.dd hh:mm:ss X");
//        log("%s%n", dateFormat.format(new Date()));
        LocalDateTime localDateTime = LocalDateTime.now();
        log("%s%n", localDateTime);
        log("%s%n", localDateTime.format(DateTimeFormatter.ofPattern("yyyy'.'MM'.'dd 'at' hh':'mm':'ss z")));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
