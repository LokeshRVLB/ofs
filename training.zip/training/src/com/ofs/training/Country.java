package com.ofs.training;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class Country {

    private String name;
    private int temperature;

    public Country(String name, int temperature) {
        super();
        this.name = name;
        this.temperature = temperature;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }
}
