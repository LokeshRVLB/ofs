package com.ofs.training;

public interface FunctionalInterfaceDemo {

	int x = 2;
	public int calculateResult();
	public default int showResult() {
		x = calculateResult() + 1;
		return x;
	}
}
