package com.ofs.training;

import java.util.List;
import java.util.stream.Collectors;

import com.ofs.training.Person.Sex;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class PersonFilter {

    public static void main(String[] args) {
        PersonFilter obj = new PersonFilter();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        List<Person> persons = Person.createRoster();
        List<Person> filteredPersons = persons.stream().
                                               filter(person -> person.getGender() == Sex.MALE).
                                               filter(person -> person.getAge() > 21).
                                               collect(Collectors.toList());
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
