package com.ofs.training;

public class StaticMethodOveridingDemo {

    public void methodOne() {
        System.out.println("This is methodOne");
    }

    public void methodTwo() {
        System.out.println("This is methodTwo");
    }

    public void methodThree() {
        System.out.println("This is methodThree");
    }

    public static void methodFour() {
        System.out.println("This is methodFour");
    }
}
