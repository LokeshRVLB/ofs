package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author Lokesh.
 * @since Aug 31, 2018
 */
@Test
public class CitySorterTest {

    private CitySorter citySorter;
    @BeforeClass
    private void initClass() {

        citySorter = new CitySorter();
    }

    @Test(dataProvider = "positiveCase_sortIgnoringCases")
    private void testSortIgnoringCases_positive(String[] expected, String[] cities) {

        try {
            citySorter.sortIgnoringCases(cities);
            Assert.assertEquals(cities, expected);
        } catch (Exception e) {

            StringBuilder sb = new StringBuilder();
            StringBuilder sb2 = new StringBuilder();

            for (String expectedResult : expected) {
                sb.append(expectedResult + ",");
            }
            for (String expectedResult : cities) {
                sb2.append(expectedResult + ",");
            }

            Assert.fail("expected result is "
                        + sb.toString()
                        + " But actual result is "
                        + sb2.toString()
                        , e);
        }

    }

    @Test(dataProvider = "positiveCase_covertEvenIndexedToUpper")
    private void testCovertEvenIndexedToUpper(String[] expected, String[] cities) {

        try {
            citySorter.convertEvenIndexedToUpper(cities);
            Assert.assertEquals(cities, expected);
        } catch (Exception e) {

            StringBuilder sb = new StringBuilder();
            StringBuilder sb2 = new StringBuilder();

            for (String expectedResult : expected) {
                sb.append(expectedResult + ",");
            }
            for (String expectedResult : cities) {
                sb2.append(expectedResult + ",");
            }

            Assert.fail("expected result is "
                        + sb.toString()
                        + " But actual result is "
                        + sb2.toString()
                        , e);
        }
    }

    @DataProvider(name = "positiveCase_sortIgnoringCases")
    private Object[][] testSortIgnoringCases_positiveDP() {

        return new Object[][] {
            {new String[] {"Balaji", "Lokesh", "Vijaya"}, new String[] {"Lokesh", "Balaji", "Vijaya"}},
            {new String[] {"Boovan", "Naikar", "Rajendran"}, new String[] {"Rajendran", "Boovan", "Naikar"}}
        };
    }

    @DataProvider(name = "positiveCase_covertEvenIndexedToUpper")
    private Object[][] testCovertEvenIndexedToUpper_positiveDP() {

        return new Object[][] {
            {new String[] {"LOKESH", "Balaji", "VIJAYA"}, new String[] {"Lokesh", "Balaji", "Vijaya"}},
            {new String[] {"RAJENDRAN", "Boovan", "NAIKAR"}, new String[] {"Rajendran", "Boovan", "Naikar"}}
        };
    }

    @AfterClass
    private void afterClass() {

    }
}
