package com.ofs.training;

public class IntegetToHexConvertor {

    public static void main(String[] args) {
        int decimalValue = 65;
        System.out.println("Hexadecimal representation is " + Integer.toHexString(decimalValue));
    }
}
