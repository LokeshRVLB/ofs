package com.ofs.training;

import java.io.IOException;
import java.io.File;

public class Notepad {

    public void open(String absoluteFilePath) {
        Runtime runtime =  Runtime.getRuntime();

        try {
            Process process = runtime.exec("D:\\tools\\Notepad++\\notepad++.exe " + absoluteFilePath);
        } catch (IOException e) {
            throw new RuntimeException("Process failed");
        }
    }
}
