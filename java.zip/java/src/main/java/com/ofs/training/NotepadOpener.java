package com.ofs.training;

import java.io.File;

public class NotepadOpener {

    public static void main(String[] args) {
        NotepadOpener obj = new NotepadOpener();

        try {
            obj.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run() throws Throwable {
        String absoluteFilePath = isExists(getAbsoluteFilePath(getCurrentClass()));
        log("Opening Notepad++ Process%n");
        Notepad notepad = new Notepad();
        notepad.open(absoluteFilePath);
    }

    private String isExists(String absoluteFilePath) throws Throwable {
        File file = new File(absoluteFilePath);

        if (! file.exists()) {
            throw new RuntimeException("file system error")
                        .initCause(new java.io.FileNotFoundException());
        }
        return file.getAbsolutePath();
    }

    private String getAbsoluteFilePath(Class currentClass) {
        return currentClass.getProtectionDomain()
                           .getCodeSource()
                           .getLocation()
                           .getFile() + currentClass.getName() + ".java";
    }

    private Class getCurrentClass() {
        return getClass();
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
