package com.ofs.training;

/**
 * @author Lokesh.
 * @since Sep 5, 2018
 */
interface StrReverse {
    String reverseString();
}

public class StringReverser implements CharSequence{

    private char[] charOfString;

    private StringReverser(String str) {
        charOfString = str.toCharArray();
    }

    public static void main(String[] args) {
        StringReverser obj = new StringReverser("hsekoL");

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        displayReversedString(() -> {

                                char[] newCharOfString = new char[length()];

                                for (int i = length() - 1, j = 0; i >= 0; i--, j++) {
                                    newCharOfString[j] = charAt(i);
                                }
                                charOfString = newCharOfString;
                                return toString();
                                });
    }

    private void displayReversedString(StrReverse strReverse) {
        log("%s", strReverse.reverseString());
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }

    @Override
    public int length() {
        int index = 0;

        for (char ch : this.charOfString) {
            index = index + 1;
        }
        return index;
    }

    @Override
    public char charAt(int index) {
        return charOfString[index];
    }

    @Override
    public String toString() {
        String result = "";

        for (int index = 0; index < length(); index++) {
            result = result + charAt(index);
        }
        return result;
    }

    @Override
    public CharSequence subSequence(int start, int end) {
        StringBuilder sbBuilder = new StringBuilder();

        for (int index = start; index < end; index++) {
            sbBuilder.append(index);
        }
        return new StringReverser(sbBuilder.toString());
    }
}
