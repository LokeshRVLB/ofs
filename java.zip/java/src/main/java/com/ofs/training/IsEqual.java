package com.ofs.training;

/**
 * @author Lokesh.
 * @since Sep 6, 2018
 */
public class IsEqual {

    public static void main(String[] args) {
        IsEqual obj = new IsEqual();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {
        log("%b%n", isEqual(2, 2));
        log("%b%n", isEqual(2.0, 2.0));
    }

    private boolean isEqual(int a, int b) {

        try {
            int c = 1 / (a - b);
        } catch (Exception e) {
            return true;
        }
        return false;
    }

    private boolean isEqual(double a, double b) {

        try {
            double c = 1 / (a - b);
            log("%f%n", c);
        } catch (Exception e) {
            return true;
        }
        return false;
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
