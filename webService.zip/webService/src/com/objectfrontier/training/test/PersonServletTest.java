package com.objectfrontier.training.test;

import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Iterator;
import java.util.List;
import java.util.Objects;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.CSVParser;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.HttpMethod;
import com.objectfrontier.training.service.helper.JsonUtil;
import com.objectfrontier.training.service.helper.RequestHelper;

/**
 * @author Lokesh.
 * @since Nov 13, 2018
 */
public class PersonServletTest {

    @BeforeClass
    private void setup() throws IOException, SQLException {

    }

    @Test (dataProvider = "insertTest_positiveDP", groups = { "insert" }, priority = 1)
    private void insertTest_positive(Person person) throws Exception {

        String jsonString = JsonUtil.toJson(person);
        String url = "http://127.0.0.1:8080/ws/person/person.html?action=create";
        Person actualResult = getResponse(url, jsonString, HttpMethod.PUT, Person.class);

        Assert.assertTrue(actualResult.getId() > 0, "Auto generated ID should be greater than zero");
        person.setId(actualResult.getId());
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(person));

    }

    @DataProvider
    private Iterator<Person> insertTest_positiveDP() {
        CSVParser csvParser = new CSVParser("persons.csv", "addresses.csv");
        return csvParser.getPersons().iterator();
    }

    @Test (dataProvider = "insertTest_negativeDP", groups = { "insert" },  priority = 2)
    private void insertTest_negative(Person person, AppException expectedResult) throws Exception {
        String jsonString = JsonUtil.toJson(person);

        String url = "http://127.0.0.1:8080/ws/person/person.html?action=create";
        String actualResult = getResponse(url, HttpMethod.POST, jsonString);
        AppError expected = new AppError(expectedResult);
        Assert.assertEquals(actualResult, JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] insertTest_negativeDP() {
        Address address = new Address(null, null, 517001);
        Person person = new Person("Lokesh2",
                                   "Balaji",
                                   "lokeshbalaji268@gmail.com",
                                   address,
                                   null);
        Address addressTwo = new Address(null, null, 0);
        Person personTwo = new Person(null,
                                      null,
                                      null,
                                      addressTwo,
                                   null);
        Error[] errorsOne = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.DATA_FIRST_LAST_NAME_DUPLICATION_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_DUPLICATION_ERROR};

        Error[] errorsTwo = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.POSTAL_CODE_NULL_VALUE_ERROR,
                              Error.FIRST_NAME_NULL_VALUE_ERROR,
                              Error.LAST_NAME_NULL_VALUE_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_NULL_VALUE_ERROR};

        return new Object[][] {
            { person, new AppException(errorsOne, Error.DATA_VALIDATION_ERROR) },
            { personTwo, new AppException(errorsTwo, Error.DATA_VALIDATION_ERROR) }
        };
    }

    @Test (dataProvider = "readAllTest_positiveDP", groups = { "readAll" },  priority = 3)
    private void readAllTest_positive(List<Person> expectedResult) throws Exception {
        String actualResult = getResponse("http://127.0.0.1:8080/ws/person/person.html?action=readAll");
        Assert.assertEquals(actualResult, JsonUtil.toJson(expectedResult));
    }

    @DataProvider
    private Object[][] readAllTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsReadAll.csv", "addresses.csv");
        return new Object[][] {
            { csvParser.getPersons() }
        };
    }

    @Test (dataProvider = "readAllOffsetTest_positiveDP", groups = { "readAll" },  priority = 4)
    private void readAllOffsetTest_positive(List<Person> expectedResult, int limit, int offset) throws Exception {
        String url = String.format("http://127.0.0.1:8080/ws/person/person.html?action=indexedReadAll&lmt=%d&offst=%d",
                                    limit,offset);
        String actualResult = getResponse(url);
        Assert.assertEquals(actualResult, JsonUtil.toJson(expectedResult));
    }

    @DataProvider
    private Object[][] readAllOffsetTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsReadAll.csv", "addresses.csv");
        return new Object[][] {
            { csvParser.getPersons(5, 0), 5, 0},
            { csvParser.getPersons(5, 5), 5, 5}
        };
    }

    @Test (dataProvider = "readTest_positiveDP", groups = { "read" },  priority = 5)
    private void readTest_positive(Person expectedResult, boolean includeAddress, int id) throws Exception {
        String url = String.format("http://127.0.0.1:8080/ws/person/person.html?action=read&id=%d&addStatus=%b",
                                    id, includeAddress);
        String actualResult = getResponse(url);
        Assert.assertEquals(actualResult, JsonUtil.toJson(expectedResult));
    }


    @DataProvider
    private Object[][] readTest_positiveDP() {
        Address address = new Address("Hassan khan2 Street", "Mittoor", 517001);
        address.setId((long)2);
        Person person = new Person("Lokesh2",
                                   "Balaji",
                                   "lokeshbalaji268@gmail.com",
                                   address,
                                   LocalDate.parse("06-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId((long)2);
        Person personTwo = new Person("Lokesh2",
                "Balaji",
                "lokeshbalaji268@gmail.com",
                null,
                LocalDate.parse("06-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        personTwo.setId((long)2);
        return new Object[][] {
            {person, true, 2},
            {personTwo, false, 2}
        };
    }

    @Test (dataProvider = "readTest_negativeDP", groups = { "read" }, priority = 6)
    private void readTest_negative(int id, boolean includeAddress, AppException expectedResult) throws Exception {
        String url = String.format("http://127.0.0.1:8080/ws/person/person.html?action=read&id=%d&addStatus=%b", id,
                includeAddress);
        String actualResult = getResponse(url);
        Assert.assertEquals(actualResult, JsonUtil.toJson(new AppError(expectedResult)));
    }

    @DataProvider
    private Object[][] readTest_negativeDP() {
        return new Object[][] {
            {1000, true, new AppException(Error.INVALID_PERSON_REQUEST)}
        };
    }

    @Test (dataProvider = "searchTest_positiveDP", groups = { "search" }, priority = 7)
    private void searchTest_positive(String[] fields, String searchText, List<Person> expectedResult) throws Exception {
        StringBuilder sBuilder = new StringBuilder();
        for (String data : fields) {
            sBuilder.append(data).append(",");
        }
        String searchFields = sBuilder.substring(0, sBuilder.length() - 1);
        String url = String.format(
                    "http://127.0.0.1:8080/ws/person/person.html?searchFields=%s&searchText=%s&action=search",
                     searchFields,searchText);
        String actualResult = getResponse(url);
        Assert.assertEquals(actualResult, JsonUtil.toJson(expectedResult));
    }

    @DataProvider
    private Object[][] searchTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsReadAll.csv", "addresses.csv");
        return new Object[][] {
            {new String[] { "city" }, "mi" , csvParser.getPersons()},
            {new String[] { "postal_code" }, "517001", csvParser.getPersons(9, 0)}
        };
    }

    @Test (dataProvider = "updateTest_positiveDP", groups = { "update" }, priority = 8)
    private void updateTest_positive(Person person) throws Exception {
        String jsonString = JsonUtil.toJson(person);
        String url = "http://127.0.0.1:8080/ws/person/person.html?action=update";
        Person actualResult = getResponse(url, jsonString, HttpMethod.POST, Person.class);

        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(person));
    }

    @DataProvider
    private Iterator<Person> updateTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsUpdate.csv", "addressesUpdate.csv");
        return csvParser.getPersons().iterator();
    }

    @Test (dataProvider = "updateTest_negativeDP", groups = { "update" }, priority = 9)
    private void updateTest_negative(Person person, AppException expectedException) throws Exception {
        String jsonString = JsonUtil.toJson(person);

        String url = "http://127.0.0.1:8080/ws/person/person.html?action=update";
        String actualResult = getResponse(url, HttpMethod.POST, jsonString);
        AppError expected = new AppError(expectedException);
        Assert.assertEquals(actualResult, JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] updateTest_negativeDP() {
        Address address = new Address(null, null, 517001);
        address.setId((long)2000);
        Person person = new Person("Lokesh2",
                                   "Balajiupdate",
                                   "lokeshbalaji268@gmail.com",
                                   address,
                                   null);
        person.setId((long)2000);
        Address addressTwo = new Address(null, null, 0);
        address.setId((long)1000);
        Person personTwo = new Person(null,
                                      null,
                                      null,
                                      addressTwo,
                                   null);
        person.setId((long)1000);
        Address addressThree = new Address("hai", "hello", 517001);
        address.setId((long)1000);
        Person personThree = new Person("Vijaya",
                                      "Rajendran",
                                      "vijaya.rajendran@gmail.com",
                                      addressThree,
                                      LocalDate.parse("06-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy"))
                                   );
        person.setId((long)1000);
        Error[] errorsOne = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.INVALID_ADDRESS_REQUEST,
                              Error.DATA_FIRST_LAST_NAME_DUPLICATION_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_DUPLICATION_ERROR,
                              Error.INVALID_PERSON_REQUEST};

        Error[] errorsTwo = { Error.STREET_NULL_VALUE_ERROR,
                              Error.CITY_NULL_VALUE_ERROR,
                              Error.POSTAL_CODE_NULL_VALUE_ERROR,
                              Error.INVALID_ADDRESS_REQUEST,
                              Error.FIRST_NAME_NULL_VALUE_ERROR,
                              Error.LAST_NAME_NULL_VALUE_ERROR,
                              Error.DOB_NULL_VALUE_ERROR,
                              Error.EMAIL_NULL_VALUE_ERROR,
                              Error.INVALID_PERSON_REQUEST};
        Error[] errorThree = {
                Error.INVALID_ADDRESS_REQUEST,
                Error.INVALID_PERSON_REQUEST
        };

        return new Object[][] {
            { person, new AppException(errorsOne, Error.DATA_VALIDATION_ERROR) },
            { personTwo, new AppException(errorsTwo, Error.DATA_VALIDATION_ERROR)},
            { personThree, new AppException(errorThree, Error.DATA_VALIDATION_ERROR)}
        };
    }

    @Test (dataProvider = "deleteTest_positiveDP", groups = { "delete" }, priority = 10)
    private void deleteTest_positive(Person person) throws Exception {
        String jsonString = JsonUtil.toJson(person);
        String url = "http://127.0.0.1:8080/ws/person/person.html?action=delete";
        Person actualResult = getResponse(url, jsonString, HttpMethod.POST, Person.class);
        Assert.assertEquals(JsonUtil.toJson(actualResult), JsonUtil.toJson(person));
    }

    @DataProvider
    private Iterator<Person> deleteTest_positiveDP() {
        CSVParser csvParser = new CSVParser("personsDelete.csv", "addressesDelete.csv");
        return csvParser.getPersons().iterator();
    }

    @Test (dataProvider = "deleteTest_negativeDP", groups = { "delete" }, priority = 11)
    private void deleteTest_negative(Person person, AppException expectedException) throws Exception {
        String jsonString = JsonUtil.toJson(person);

        String url = "http://127.0.0.1:8080/ws/person/person.html?action=delete";
        String actualResult = getResponse(url, HttpMethod.POST, jsonString);
        AppError expected = new AppError(expectedException);
        Assert.assertEquals(actualResult, JsonUtil.toJson(expected));
    }

    @DataProvider
    private Object[][] deleteTest_negativeDP() {
        Address address = new Address("Boovan street", "Banglore", 600123);
        Person person = new Person("Lokesh4",
                                   "Lokesh4",
                                   "lokeshbalaji684@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId((long)8);
        return new Object[][] {
            {person, new AppException(Error.INVALID_PERSON_REQUEST)}
        };
    }

    @Test (dataProvider = "urlDataTest_DP", groups = { "check" }, priority = 12)
    private void urlDataTest(String url, HttpMethod method, String jsonString, AppError expectedException)
            throws Exception {
        String actualResult;
        if (Objects.isNull(jsonString)) { actualResult = getResponse(url); }
        else { actualResult = getResponse(url, method, jsonString); }
        Assert.assertEquals(actualResult, JsonUtil.toJson(expectedException));
    }
    
    @DataProvider
    private Object[][] urlDataTest_DP() {
        Address address = new Address("Boovan street", "Banglore", 600123);
        address.setId((long)8);
        Person person = new Person("Lokesh4",
                                   "Lokesh4",
                                   "lokeshbalaji684@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId((long)8);
        return new Object[][] {
            {"http://127.0.0.1:8080/ws/person/person.html?action=readAaaallu",
              HttpMethod.GET,
              null,
              new AppError(new AppException(Error.INVALID_OPERATION_REQUEST))
            },
            {"http://127.0.0.1:8080/ws/person/person.html?searchFields=citilu,statulu&searchText=mia&action=search",
              HttpMethod.GET,
              null,
              new AppError(new AppException(Error.INVALID_SEARCH_FIELDS))
            },
            {"http://127.0.0.1:8080/ws/person/person.html?searchFields=city,street&searchText=&action=search",
                HttpMethod.GET,
                null,
                new AppError(new AppException(Error.EMPTY_SEARCH_TEXT))
            },
            {"http://127.0.0.1:8080/ws/person/person.html?action=indexedReadAll&lmt=abcx&offst=def",
              HttpMethod.GET,
              null,
              new AppError(new AppException(Error.INVALID_LIMIT_OFFSET_PARAMETER))
            }
        };
    }
    
    @AfterClass
    private void afterClass() throws SQLException {
    }
    

    private String getResponse(String url) throws Exception {
        return RequestHelper.create().requestString(url);
    }
    private String getResponse(String url, HttpMethod httpMethod, String jsonString) throws Exception {
        return RequestHelper.create()
//                            .setSecured(true)
                            .setMethod(httpMethod)
                            .setInput(jsonString)
                            .requestString(url);
    }

    private <T> T getResponse(String url, String jsonString, HttpMethod method, Class<? extends T> classType)
            throws Exception {
        return RequestHelper.create()
//                            .setSecured(true)
                            .setMethod(method)
                            .setInput(jsonString)
                            .requestObject(url, classType);
    }
}
