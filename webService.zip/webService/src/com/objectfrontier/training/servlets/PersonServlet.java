package com.objectfrontier.training.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.entity.POJO.Result;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.AppStatusCode;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.DataSource;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;

/**
 * Servlet implementation class PersonServlet
 * @author Lokesh.
 * @since Nov 2, 2018
 */

@WebServlet("/PersonServlet")
public class PersonServlet extends BaseServlet {
    private static final long serialVersionUID = 1L;

    public PersonServlet() {
        super();
    }

    @Override
    public void init() throws ServletException {
        super.init();
        initLog(getClass());
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action(request.getParameter("action"),request, response, "Get");
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        action(req.getParameter("action"), req, resp, "Post");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        action(req.getParameter("action"), req, resp, "Put");
    }

    void action(String action, HttpServletRequest request, HttpServletResponse response, String method)
            throws IOException {

        PrintWriter out = response.getWriter();

        BufferedReader bufferedReader = request.getReader();
        StringBuilder jsonStringBuilder = new StringBuilder();
        bufferedReader.lines().forEach(lines -> jsonStringBuilder.append(lines).append("\n"));
        String jsonData = jsonStringBuilder.toString();

        HttpSession session = request.getSession();
        AddressService addressService = (AddressService) session.getAttribute("addressService");
        PersonService personService = new PersonService(addressService);

        String condition = new StringBuilder(action).append(method).toString();
        response.setStatus(AppStatusCode.SUCCESS.getStatusCode());
        switch (condition) {
            case "updatePost":
                out.write(JsonUtil.toJson(personService.update(getPerson(jsonData))));
                break;
            case "deletePost":
                out.write(JsonUtil.toJson(personService.delete(getPerson(jsonData))));
                break;
            case "createPut":
                out.write(JsonUtil.toJson(personService.create(getPerson(jsonData))));
                break;
            case "readGet":
                out.write(JsonUtil.toJson(personService.read(Long.parseLong(request.getParameter("id")),
                        Boolean.parseBoolean(request.getParameter("addStatus")))));
                break;
            case "readAllGet":
                out.write(JsonUtil.toJson(personService.readAll()));
                break;
            case "searchGet":
                String[] fields = request.getParameter("searchFields").split(",");
                out.write(JsonUtil.toJson(personService.searchPersonByAddress(fields,
                                                                              request.getParameter("searchText"))));
                break;
            case "indexedReadAllGet":
                out.write(JsonUtil.toJson(personService.readAll(Integer.parseInt(request.getParameter("lmt")),
                      Integer.parseInt(request.getParameter("offst")))));
                break;
            default:
                log("requested an invalid operation from servlet, Terminating process", "error");
                throw new AppException(Error.INVALID_OPERATION_REQUEST);
        }
        session.setAttribute("transactionStatus", "success");
        out.close();
    }

    private Person getPerson(String jsonString) {
        try {            
            return JsonUtil.toObject(jsonString, Person.class);
        } catch (Exception e) {
            throw new AppException(Error.JSON_LOAD_ERROR, e);
        }
    }
}
