package com.objectfrontier.training.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.DataSource;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;

/**
 * Servlet implementation class PersonServlet
 * @author Lokesh.
 * @since Nov 2, 2018
 */

@WebServlet("/PersonServlet")
public class PersonServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    public PersonServlet() {
        super();
    }

    static ConnectionManager initiliseConnection() {
        try {
            return new ConnectionManager(DataSource.getConnection());
        } catch (SQLException e) {
            throw new AppException(Error.SQL_CONNECTION_ERROR);
        }
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action(request.getParameter("action"),request, response, "Get");
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        action(req.getParameter("action"), req, resp, "Post");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        action(req.getParameter("action"), req, resp, "Put");
    }

    void action(String action, HttpServletRequest request, HttpServletResponse response, String method)
                throws IOException {
        PrintWriter out = response.getWriter();

        BufferedReader bufferedReader = request.getReader();
        StringBuilder jsonStringBuilder = new StringBuilder();
        bufferedReader.lines().forEach(lines -> jsonStringBuilder.append(lines).append("\n"));
        String jsonData = jsonStringBuilder.toString();
        
        ConnectionManager connectionManager = initiliseConnection();
        connectionManager.autoCommit(false);
        AddressService addressService = new AddressService(connectionManager);
        PersonService personService = new PersonService(connectionManager, addressService);
        
        List<Person> result;
        try {
            String condition = new StringBuilder(action).append(method).toString();
            switch (condition) {
            case "updatePost":
                out.write(JsonUtil.toJson(personService.update(getPerson(jsonData))));
                break;
            case "deletePost":
                out.write(JsonUtil.toJson(personService.delete(getPerson(jsonData))));
                break;
            case "createPut":
                Person person = personService.create(getPerson(jsonData));
                System.out.println(person);
                out.write(JsonUtil.toJson(person));
                break;
            case "readGet":
                try {
                    out.write(JsonUtil.toJson(personService.read(Long.parseLong(request.getParameter("id")),
                            Boolean.parseBoolean(request.getParameter("addStatus")))));
                } catch (NumberFormatException e) {
                    throw new AppException(Error.INVALID_ID_REQUEST);
                }
                break;
            case "readAllGet":
                result = personService.readAll();
                out.write(JsonUtil.toJson(result));
                break;
            case "searchGet":

                String[] fields = request.getParameter("searchFields").split(",");
                result = personService.searchPersonByAddress(fields, "%" + request.getParameter("searchText") + "%");
                out.write(JsonUtil.toJson(result));
                break;
            case "indexedReadAllGet":
                try {
                    result = personService.readAll(Integer.parseInt(request.getParameter("lmt")),
                            Integer.parseInt(request.getParameter("offst")));
                } catch (NumberFormatException e) {
                    throw new AppException(Error.INVALID_LIMIT_OFFSET_PARAMETER);
                }
                out.write(JsonUtil.toJson(result));
                break;
            default:
                throw new AppException(Error.INVALID_OPERATION_REQUEST);
            }
            connectionManager.commit();

        } catch (Exception e) {
            connectionManager.rollBack();
            AppError appError;
            if (e instanceof AppException) {
                appError = new AppError((AppException) e);
            } else {
                appError = new AppError(new AppException(Error.UNKOWN_ERROR));
            }
            out.write(JsonUtil.toJson(appError));
        } finally {            
            connectionManager.close();
            out.close();
        }
    }

    private Person getPerson(String jsonString) {
        return JsonUtil.toObject(jsonString, Person.class);
    }
}
