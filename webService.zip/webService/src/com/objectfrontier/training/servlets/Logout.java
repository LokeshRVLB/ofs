package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.entity.POJO.Result;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.AppStatusCode;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;

public class Logout extends BaseServlet {

private static final long serialVersionUID = 1L;

    @Override
    public void init() throws ServletException {
        super.init();
        initLog(getClass());
    }

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        PrintWriter out = resp.getWriter();

        if (Objects.isNull(req.getSession(false))) {
            resp.setStatus(AppStatusCode.SUCCESS_NO_RESPONSE_BODY.getStatusCode());
            return;
        }
        out.write(JsonUtil.toJson(new AppError(new AppException(Error.LOGOUT_FAILED))));
    }
}
