package com.objectfrontier.training.servlets;

import java.time.LocalDate;

import com.objectfrontier.training.service.AuthenticationService;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.entity.POJO.Result;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.DataSource;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.HttpMethod;
import com.objectfrontier.training.service.helper.JsonUtil;
import com.objectfrontier.training.service.helper.RequestHelper;

public class Tester {

    public static void main(String[] args) {
        Tester obj = new Tester();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws Exception {

//        Properties personProps = new Properties();
//        personProps.load(getClass().getResourceAsStream("personGetterMapper.properties"));
//        Properties addressProps = new Properties();
//        addressProps.load(getClass().getResourceAsStream("addressGetterMapper.properties"));
        Person person = new Person();
        person.setFirstName("Lokesh");
        person.setLastName("Balaji");
        person.setBirthDate(LocalDate.now());
        person.setEmail("lokeshbalaji68@gmail.com");
        person.setId(new Long(1)); 
        Address address = new Address();
        address.setCity("Chennai");
        address.setId(new Long(1));
        address.setStreet("Hassan Khan Street");
        address.setPostalCode(new Long(512001));
        person.setAddress(address);
//        AuthenticationService aService = new AuthenticationService(new ConnectionManager(DataSource.getConnection()));
//        log("%b", aService.authenticate("lokeshbalaji68@gmail.com", "lokesh1234"));
        
//        JSONMapper personJsonMapper = new JSONMapper(person, personProps);
//        JSONMapper addressJsonMapper = new JSONMapper(address, addressProps);
//        personJsonMapper.prepareJSONString();
//        addressJsonMapper.prepareJSONString();
////        log("%s%n", personJsonMapper.getJSONString());
////        log("%s%n", addressJsonMapper.getJSONString());
//        personJsonMapper.attach("address", addressJsonMapper.getObjectBuilder());
//        log("%s%n", personJsonMapper.getJSONString());
//        log("%s",JsonUtil.toJson(person));
        String json = JsonUtil.toJson(person);
        RequestHelper requestHelper = RequestHelper.create();
        String url = "http://127.0.0.1:8080/ws/login.html?user=lokesh@gmail.com&pass=lokesh@1234";
        String login = requestHelper.setMethod(HttpMethod.POST).requestString(url);
        System.out.println(login);
        url = "http://127.0.0.1:8080/ws/person/person.html?action=readAll";
        String read = requestHelper.setMethod(HttpMethod.GET).requestString(url);
        System.out.println(read);
//        url = "http://127.0.0.1:8080/ws/address/address.html?action=create";
//        String create = requestHelper.setMethod(HttpMethod.PUT).setInput("hai").requestString(url);
//        System.out.println(create);
//        url = "http://127.0.0.1:8080/ws/logout.html";
//        String logout = requestHelper.setMethod(HttpMethod.GET).requestString(url);
//        System.out.println(logout);
//        url = "http://127.0.0.1:8080/ws/address/address.html?action=create";
//        String createtwo = requestHelper.setMethod(HttpMethod.PUT).setInput(JsonUtil.toJson(address)).requestString(url);
//        System.out.println(createtwo);
//        Result<String> result = new Result<>();
//        result.setResult(JsonUtil.toJson(person));
//        result.setStatusCode(200);
//        
//        String test = JsonUtil.toJson(result);
//        Result<String> result2 = JsonUtil.toObject(test, Result.class);
//        System.out.println(result2.getResult());
//        System.out.println(result.getClass());
//        
//        url = "http://127.0.0.1:8080/ws/address/addresses.html?action=create";
//        String createDemo = requestHelper.setMethod(HttpMethod.PUT).setInput("hai").requestString(url);
//        System.out.println(createDemo);
//        try {
//            String actualResult = getResponse(url, null, HttpMethod.POST);
//            System.out.println(actualResult);
//        } catch (AppException e) {
//            System.out.println(e);
//            for (Error error : e.getAssociatedErrors()) {
//                System.out.println(error.getMessage());
//            }
//        }
    }


    private String getResponse(String url, String jsonString, HttpMethod method) throws Exception {
        return RequestHelper.create()
//                            .setSecured(true)
                            .setMethod(method)
//                            .setInput(jsonString)
                            .requestString(url);
    }
    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
