package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;
import com.objectfrontier.training.service.helper.ServerError;

/**
 * @author Lokesh.
 * @since Nov 16, 2018
 */
public class ErrorHandler extends HttpServlet {

    private static final long serialVersionUID = 1L;

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        System.out.println("I am inside");
        Throwable throwable = (Throwable) request.getAttribute("javax.servlet.error.exception");
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        String servletName = (String) request.getAttribute("javax.servlet.error.servlet_name");

        if (servletName == null) {
            servletName = "Unknown";
        }
        String requestUri = (String) request.getAttribute("javax.servlet.error.request_uri");

        if (requestUri == null) {
            requestUri = "Unknown";
        }

        PrintWriter out = response.getWriter();

        if (throwable == null && statusCode == null) {
            out.write(JsonUtil.toJson(new AppError(new AppException(Error.UNKOWN_ERROR))));
        } else if (statusCode != null) {
            out.write(JsonUtil.toJson(new ServerError(statusCode,requestUri)));
        } else {
            out.write(JsonUtil.toJson(new AppError(new AppException(Error.UNKOWN_ERROR))));
        }
        out.close();
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        doGet(request, response);
    }
}
