package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.entity.POJO.Result;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.AppStatusCode;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;
import com.objectfrontier.training.service.helper.ServerError;

/**
 * @author Lokesh.
 * @since Nov 16, 2018
 */
public class ErrorHandler extends BaseServlet {

    private static final long serialVersionUID = 1L;

    @Override
    public void init() throws ServletException {
        super.init();
        initLog(getClass());
    }

    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        Throwable exception = (Throwable) request.getAttribute("javax.servlet.error.exception");
        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
        String servletName = (String) request.getAttribute("javax.servlet.error.servlet_name");

        if (servletName == null) {
            servletName = "Unknown";
        }

        String requestUri = (String) request.getAttribute("javax.servlet.error.request_uri");

        if (requestUri == null) {
            requestUri = "Unknown";
        }

        PrintWriter out = response.getWriter();
        if (exception == null && statusCode == null) {
            internalError(out, response);
        } else if (statusCode != null) {
            log(String.format("Request ended with status Code %d", statusCode));
            response.setStatus(statusCode);
        } else {
            internalError(out, response);
        }
        out.close();
    }

    @Override
    protected void doTrace(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // TODO Auto-generated method stub
        doGet(request, response);
    }

    private void internalError(PrintWriter out, HttpServletResponse res) {
        res.setStatus(AppStatusCode.INTERNAL_SERVER_ERROR.getStatusCode());
        out.write(JsonUtil.toJson(new AppError(new AppException(Error.UNKOWN_ERROR))));
    }

    public void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

        doGet(request, response);
    }

    public void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doGet(req, resp);
    }

}
