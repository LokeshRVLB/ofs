package com.objectfrontier.training.servlets;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.helper.LoginTracker;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class loginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;
    

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        LoginTracker.LogIn(req.getRequestedSessionId());
    }
    

    
}
