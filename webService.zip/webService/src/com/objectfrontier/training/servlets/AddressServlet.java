package com.objectfrontier.training.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.DataSource;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;

/**
 * Servlet implementation class AddressServlet
 */
@WebServlet("/AddressServlet")
public class AddressServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;



    /**
     * @throws IOException 
     * @see HttpServlet#HttpServlet()
     */

    public AddressServlet() throws IOException {
        super();
    }

    static ConnectionManager initiliseConnection() {
            return new ConnectionManager(DataSource.getConnection());
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action(request.getParameter("action"), request, response, "Get");
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        action(req.getParameter("action"), req, resp, "Post");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        action(req.getParameter("action"), req, resp, "Put");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        action(req.getParameter("action"), req, resp, "Delete");
    }

    void action(String action, HttpServletRequest request, HttpServletResponse response, String method) throws IOException {
        PrintWriter out = response.getWriter();

        BufferedReader bufferedReader = request.getReader();
        StringBuilder jsonStringBuilder = new StringBuilder();
        bufferedReader.lines().forEach(lines -> jsonStringBuilder.append(lines).append("\n"));
        String jsonData = jsonStringBuilder.toString();
        
        ConnectionManager connectionManager = initiliseConnection();
        connectionManager.autoCommit(false);
        AddressService addressService = new AddressService(connectionManager);
        
        List<Address> result;
        try {
            String condition = new StringBuilder(action).append(method).toString();
            switch (condition) {
                case "updatePost":
                    out.write(JsonUtil.toJson(addressService.update(getAddress(jsonData))));
                    break;
                case "deletePost":
                    out.write(JsonUtil.toJson(addressService.delete(getAddress(jsonData))));
                    break;
                case "createPut":
                    out.write(JsonUtil.toJson(addressService.create(getAddress(jsonData))));
                    break;
                case "readGet":
                    System.out.println("I am in ");
                    try {                        
                        out.write(JsonUtil.toJson(addressService.read(Long.parseLong(request.getParameter("id")))));
                    } catch (NumberFormatException e) {
                        throw new AppException(Error.INVALID_ID_REQUEST);
                    }
                    break;
                case "searchGet":
                    String[] fields = request.getParameter("searchFields").split(",");
                    result = addressService.search(fields, "%"+request.getParameter("searchText")+"%");
                    out.write(JsonUtil.toJson(result));
                    break;
                case "readAllGet":
                    result = addressService.readAll();
                    out.write(JsonUtil.toJson(result));
                    break;
                case "indexedReadAllGet":
                    try {
                            result = addressService.readAll(Integer.parseInt(request.getParameter("lmt")),
                                                   Integer.parseInt(request.getParameter("offst")));
                    } catch (NumberFormatException e) {
                        throw new AppException(Error.INVALID_LIMIT_OFFSET_PARAMETER);
                    }
                    out.write(JsonUtil.toJson(result));
                    break;
                default : 
                    throw new AppException(Error.INVALID_OPERATION_REQUEST);
            }
            connectionManager.commit();
  
        } catch (AppException e) {
            connectionManager.rollBack();
            AppError appError;
            if (e instanceof AppException) {
                appError = new AppError((AppException) e);
            } else {
                appError = new AppError(new AppException(Error.UNKOWN_ERROR));
            }
            out.write(JsonUtil.toJson(appError));
        } finally {            
            connectionManager.close();
            out.close();
        }
    }

    private Address getAddress(String jsonString) {

        return JsonUtil.toObject(jsonString, Address.class);
    }

}
