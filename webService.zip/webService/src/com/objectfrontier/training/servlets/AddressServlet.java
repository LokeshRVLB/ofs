package com.objectfrontier.training.servlets;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.entity.POJO.Result;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.AppStatusCode;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.DataSource;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;

/**
 * @author Lokesh.
 * @since Nov 2, 2018
 */
@WebServlet("/AddressServlet")
public class AddressServlet extends BaseServlet {
    private static final long serialVersionUID = 1L;

    /**
     * @throws IOException 
     * @see HttpServlet#HttpServlet()
     */

    public AddressServlet() throws IOException {
        super();
    }
    
    @Override
    public void init() throws ServletException {
        super.init();
        initLog(getClass());
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action(request.getParameter("action"), request, response, "Get");
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        action(req.getParameter("action"), req, resp, "Post");
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        action(req.getParameter("action"), req, resp, "Put");
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        action(req.getParameter("action"), req, resp, "Delete");
    }

    void action(String action, HttpServletRequest request, HttpServletResponse response, String method)
            throws IOException {
        PrintWriter out = response.getWriter();

        BufferedReader bufferedReader = request.getReader();
        StringBuilder jsonStringBuilder = new StringBuilder();
        bufferedReader.lines().forEach(lines -> jsonStringBuilder.append(lines).append("\n"));
        String jsonData = jsonStringBuilder.toString();

        HttpSession session = request.getSession();
        AddressService addressService = new AddressService();

        response.setStatus(AppStatusCode.SUCCESS.getStatusCode());
        String condition = new StringBuilder(action).append(method).toString();

        switch (condition) {
        case "updatePost":
            out.write(JsonUtil.toJson(addressService.update(getAddress(jsonData))));
            break;
        case "deletePost":
            out.write(JsonUtil.toJson(addressService.delete(getAddress(jsonData))));
            break;
        case "createPut":
            out.write(JsonUtil.toJson(addressService.create(getAddress(jsonData))));
            break;
        case "readGet":
            out.write(JsonUtil.toJson(addressService.read(Long.parseLong(request.getParameter("id")))));
            break;
        case "searchGet":
            String[] fields = request.getParameter("searchFields").split(",");
            out.write(JsonUtil.toJson(addressService.search(fields, "%" + request.getParameter("searchText") + "%")));
            break;
        case "readAllGet":
            out.write(JsonUtil.toJson(addressService.readAll()));
            break;
        case "indexedReadAllGet":
            out.write(JsonUtil.toJson(addressService.readAll(Integer.parseInt(request.getParameter("lmt")),
                    Integer.parseInt(request.getParameter("offst")))));
            break;
        default:
            log("requested an invalid operation from servlet, Terminating process", "error");
            throw new AppException(Error.INVALID_OPERATION_REQUEST);
        }

        session.setAttribute("transactionStatus", "success");
        out.close();
    }

    private Address getAddress(String jsonString) {
        try {            
            return JsonUtil.toObject(jsonString, Address.class);
        } catch (Exception e) {
            throw new AppException(Error.JSON_LOAD_ERROR, e);
        }
    }

}
