package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.AuthenticationService;
import com.objectfrontier.training.service.entity.POJO.LoginCredentials;
import com.objectfrontier.training.service.entity.POJO.Result;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.AppStatusCode;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class LoginServlet extends BaseServlet {

    private static final long serialVersionUID = 1L;

    
    
    @Override
    public void init() throws ServletException {
        super.init();
        initLog(getClass());
    }


    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
//        log("No user credentials for login. Log in failed. Termination request", "error");
//        throw new AppException(Error.NO_LOGIN_SESSION);
        doPost(req, resp);
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        HttpSession session = req.getSession(false);

        PrintWriter out = resp.getWriter();
        AuthenticationService authenticationService = new AuthenticationService();
        String user = req.getParameter("user");
        String pass = req.getParameter("pass");

        log(String.format("Logging in user : %s", user));
        log(pass);
        if (!authenticationService.authenticate(user, pass)) {
            log("Authentication failed. Invalid credentials", "error");
            throw new AppException(Error.INVALID_PASSWORD);
        }

        log(String.format("User %s Logged In", user));
        LoginCredentials personDTO = authenticationService.getCredentials(user);
        session.setAttribute("userDetails", personDTO);
        session.setAttribute("transactionStatus", "success");

        resp.setStatus(AppStatusCode.SUCCESS_NO_RESPONSE_BODY.getStatusCode());
        out.close();
    }


    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        throw new AppException(Error.NO_LOGIN_SESSION);
    }
}
