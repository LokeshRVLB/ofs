package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.AuthenticationService;
import com.objectfrontier.training.service.entity.POJO.PersonDTO;
import com.objectfrontier.training.service.helper.AppError;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.DataSource;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.JsonUtil;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class LoginServlet extends HttpServlet {

    private static final long serialVersionUID = 1L;

    
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        doPost(req, resp);
    }


    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        ConnectionManager connectionManager =  new ConnectionManager(DataSource.getConnection()); 
        PrintWriter out = resp.getWriter();
        try {
            AuthenticationService authenticationService = new AuthenticationService(connectionManager);
            String user = req.getParameter("user");
            String pass = req.getParameter("pass");

            if (Objects.isNull(user)) {
                out.write(JsonUtil.toJson(new AppError(new AppException(Error.NO_LOGIN_SESSION))));
                return;
            }

            if (! authenticationService.authenticate(user, pass)) {
                out.write(JsonUtil.toJson(new AppError(new AppException(Error.INVALID_PASSWORD))));
                return;
            }

            HttpSession oldSession = req.getSession(false);
            if (! Objects.isNull(oldSession)) {
                oldSession.invalidate();
            }

            HttpSession newSession = req.getSession(true);
            System.out.println(newSession.getId());
            PersonDTO personDTO = authenticationService.getCredentials(user);
            newSession.setAttribute("userDetails", personDTO);
            out.write(JsonUtil.toJson(user));
            out.close();
        } catch (Exception e) {
            AppError appError;
            if (e instanceof AppException) {
                appError = new AppError((AppException) e);
            } else {
                appError = new AppError(new AppException(Error.UNKOWN_ERROR));
            }
            out.write(JsonUtil.toJson(appError));
        } finally {            
            connectionManager.close();
            out.close();
        }
    }
}
