package com.objectfrontier.training.service;

import java.util.ArrayList;
import java.util.Objects;

import com.objectfrontier.training.service.DAO.AuthenticationDAO;
import com.objectfrontier.training.service.entity.POJO.PersonDTO;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.AuthenticationDBManager;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.Error;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class AuthenticationService {

    private AuthenticationDAO authenticationDBManager;
    
    public AuthenticationService(ConnectionManager connectionManager) {
        this.authenticationDBManager = new AuthenticationDBManager(connectionManager);
    }

    public boolean authenticate(String email, String pass) {
        validate(email, pass);
        PersonDTO personDTO = authenticationDBManager.getCredentials(email);
        System.out.println(personDTO.getAdminStatus());
        if (Objects.isNull(personDTO.getPassword())) {
            throw new AppException(Error.UNREGISTERED_EMAIL_ID);
        }
        if(personDTO.getPassword().equals(pass)) {
            return true;
        }
        return false;
    }

    private void validate(String email, String pass) {
        ArrayList<Error> errors = new ArrayList<>(); 
        if (Objects.isNull(email)) {
            errors.add(Error.EMAIL_NULL_VALUE_ERROR);
        }
        if (Objects.isNull(pass)) {
            errors.add(Error.PASSWORD_NULL_VALUE_ERROR);
        }
        if (email.indexOf("@") == -1) {
            errors.add(Error.INVALID_EMAIL_ID);
        }
        if (pass.length() < 6 || pass.length() > 15) {
            errors.add(Error.INVALID_PASS_LENGTH);
        }
        if (errors.size() > 0) {
            throw new AppException(errors.toArray(new Error[errors.size()]), Error.DATA_VALIDATION_ERROR);
        }
        
    }

    
}
