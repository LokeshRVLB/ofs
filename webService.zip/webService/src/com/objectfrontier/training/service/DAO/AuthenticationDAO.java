package com.objectfrontier.training.service.DAO;

import com.objectfrontier.training.service.entity.POJO.LoginCredentials;
/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public interface AuthenticationDAO {

    LoginCredentials getCredentials(String email); 
    boolean isAdmin(String email);
}
