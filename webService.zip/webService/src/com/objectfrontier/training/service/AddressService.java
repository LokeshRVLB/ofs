package com.objectfrontier.training.service;

import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.service.DAO.AddressDAO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.helper.AddressMySQLManager;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.Error;

/**
 * @author Lokesh.
 * @since Oct 12, 2018
 */
public class AddressService {

    private AddressDAO addressDBManager;

    public AddressService() {
        addressDBManager = new AddressMySQLManager();
    }

    public Address create(Address address) {
        validateAddress(address);
        return addressDBManager.create(address);
    }

    public Address update(Address address) {

        try {
            validateAddress(address);
            validateAddressId(address.getId());
        } catch (AppException e) {
            
            if (e.getErrorCode() == Error.INVALID_ADDRESS_REQUEST.getErrorCode()) {
                
                throw new AppException(new Error[] { Error.INVALID_ADDRESS_REQUEST },
                                                     Error.ADDRESS_VALIDATION_ERROR);
            }
            
            try {
                validateAddressId(address.getId());
            } catch (AppException e2) {
                
                Error[] errors = e.getAssociatedErrors();
                Error[] newErrors = new Error[errors.length + 1];
                System.arraycopy(errors, 0, newErrors, 0, errors.length);
                
                newErrors[errors.length] = Error.INVALID_ADDRESS_REQUEST;
                
                throw new AppException(newErrors, Error.ADDRESS_VALIDATION_ERROR);
            }
        }
        return addressDBManager.update(address);
    }

    private void validateAddress(Address address) {
        ArrayList<Error> errors = new ArrayList<>();
        
        if (address.getStreet() == null || address.getStreet().isEmpty()) {
            errors.add(Error.STREET_NULL_VALUE_ERROR);
        }

        if (address.getCity() == null || address.getCity().isEmpty()) {
            errors.add(Error.CITY_NULL_VALUE_ERROR);
        }

        long postalCode = address.getPostalCode();
        if (postalCode == 0) {
            errors.add(Error.POSTAL_CODE_NULL_VALUE_ERROR);
        }

        if (errors.size() > 0) {
            throw new AppException(errors.toArray(new Error[errors.size()]),
                                                  Error.ADDRESS_VALIDATION_ERROR);
        }
    }

    public Address read(long l) {

        validateAddressId(l);
        return addressDBManager.read(l);
    }

    public Address delete(Address address) { 
        
        validateAddressId(address.getId());
        return addressDBManager.delete(address);
    }

    public List<Address> readAll() { return addressDBManager.readAll(); }

    public List<Address> readAll(int limit, int offset) {
        return addressDBManager.readAll(limit, offset);
    }

    private void validateAddressId(long id) {
        
        if (id <= 0) {  throw new AppException(Error.INVALID_ADDRESS_ID);    }    

        if (! addressDBManager.isPresent("id", "id", Long.toString(id))) {
            throw new AppException(Error.INVALID_ADDRESS_REQUEST);
        }
    }

    public List<Address> search(String[] fields, String searchText) {
        return addressDBManager.search(fields, searchText);
    }
}
