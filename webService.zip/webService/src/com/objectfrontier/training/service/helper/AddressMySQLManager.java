package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.service.DAO.AddressDAO;
import com.objectfrontier.training.service.entity.POJO.Address;

/**
 * @author Lokesh.
 * @since Oct 12, 2018
 */
public class AddressMySQLManager implements AddressDAO {

    @Override
    public List<Address> readAll() {

        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());

            while (resultSet.next()) {
                Address address = new Address(resultSet.getString("street"),
                                              resultSet.getString("city"),
                                              resultSet.getLong("postal_code"));
                address.setId(resultSet.getLong("id"));
                addresses.add(address);
            }
            return addresses;
        };

        try {
            return readAll.applyOn(AddressQuery.readAll, null, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public List<Address> readAll(int limit, int offset) {

        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());

            while (resultSet.next()) {
                Address address = new Address(resultSet.getString(AddressFields.street),
                                              resultSet.getString(AddressFields.city),
                                              resultSet.getLong(AddressFields.postalCode));
                address.setId(resultSet.getLong("id"));
                addresses.add(address);
            }
            return addresses;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, limit);
            parameters.add(1, offset);
            return readAll.applyOn(AddressQuery.readAllWithOffset, parameters, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Address read(long id) {

        ResultSetProcessor<Address, ResultSet> read = (resultSet) -> {
            if (resultSet.next()) {
                Address address = new Address(resultSet.getString(AddressFields.street),
                                              resultSet.getString(AddressFields.city),
                                              resultSet.getLong(AddressFields.postalCode));
                address.setId(resultSet.getLong(AddressFields.Id));
                return address;
            }
            return null;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, id);
            return read.applyOn(AddressQuery.read, parameters, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Address update(Address address) {

        ResultSetProcessor<Integer, Integer> update = (updatedCount) -> {
            return updatedCount;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getStreet());
            parameters.add(1, address.getCity());
            parameters.add(2, address.getPostalCode());
            parameters.add(3, address.getId());
            update.applyOn(AddressQuery.update, parameters, true, 0);
            return address;
        } catch (Exception e) {
            throw new AppException(Error.SQL_UPDATE_ERROR, e);
        }
    }

    @Override
    public Address delete(Address address) {

        ResultSetProcessor<Integer, Integer> delete = (deletedCount) -> {
            return deletedCount;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getId());
            int deletedCount = delete.applyOn(AddressQuery.delete, parameters,true, 0);
            if (deletedCount == 1) {
                return address;
            }
            return null;
        } catch (Exception e) {
            throw new AppException(Error.SQL_DELETE_ERROR, e);
        }
    }

    @Override
    public Address create(Address address) {

        ResultSetProcessor<Long, ResultSet> insertAddress = (resultSet) -> {
            resultSet.next();
            return resultSet.getLong(1);
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getStreet());
            parameters.add(1, address.getCity());
            parameters.add(2, address.getPostalCode());
            long addressId = insertAddress.applyOn(AddressQuery.create, parameters, true,
                    Statement.RETURN_GENERATED_KEYS);
            address.setId(addressId);
            return address;
        } catch (Exception e) {
            throw new AppException(Error.SQL_INSERT_ERROR, e);
        }
    }

    @Override
    public <V> boolean isPresent(String checkField, String conditionField, V value) {

        String getFieldQuery = MessageFormat.format("SELECT count({0}) FROM scv_address WHERE {1} = {2}",
                                                    checkField,
                                                    conditionField,
                                                    value);
        boolean result = true;

        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };

        try {
            result = isPresent.applyOn(getFieldQuery, null, false, 0).booleanValue();
        } catch (Exception e) {
            new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

    @Override
    public List<Address> search(String[] fields, String searchText) {

        String query = String.format("SELECT id, street, city, postal_code FROM scv_address WHERE %s ",
                        constructSearchCondition(fields, searchText));
        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());

            while (resultSet.next()) {
                Address address = new Address(resultSet.getString(AddressFields.street),
                                              resultSet.getString(AddressFields.city),
                                              resultSet.getLong(AddressFields.postalCode));
                address.setId(resultSet.getLong(AddressFields.Id));
                addresses.add(address);
            }
            return addresses;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            for (int i = 0; i < fields.length; i++) {
                parameters.add(i, searchText);
            }
            return readAll.applyOn(query, parameters, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    private String constructSearchCondition(String[] fields, String searchText) {

        String[] constantFields = new String[] { "city", "postal_code", "street" };
        int count = 0;
        for (int i = 0; i < fields.length; i++) {
            for (int j = 0; j < constantFields.length ; j++) {
                if (fields[i].equals(constantFields[j])) {
                    count++;
                }
            }
        }
        if (count != fields.length) {
            throw new AppException(Error.INVALID_SEARCH_FIELDS);
        }
        if (searchText.equals("%%")) {
            throw new AppException(Error.EMPTY_SEARCH_TEXT);
        }
        StringBuilder sBuilder = new StringBuilder();
        for (String field : fields) {
            sBuilder.append(String.format(" %s LIKE ? OR ", field));
            
        }
        return sBuilder.substring(0, sBuilder.length() - 3);
    }
}
