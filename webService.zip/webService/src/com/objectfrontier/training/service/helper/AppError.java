package com.objectfrontier.training.service.helper;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

@JsonSerialize(using = ErrorSerializer.class)
public class AppError {

    int errorCause;
    List<Integer> associatedErrorCodes = new ArrayList<>();
    
    public AppError() {
        super();
    }

    public AppError(AppException e) {
        this.errorCause = e.getErrorCode();
        for (Error error : e.getAssociatedErrors()) {
            System.out.println("error is: " + error.getErrorCode());
            this.associatedErrorCodes.add(new Integer(error.getErrorCode()));
        }
    }
    
    public AppError(Integer errCode) {
        this.errorCause = errCode;
    }

    @Override
    public String toString() {
        return new StringBuilder(errorCause).append(associatedErrorCodes.toString()).toString();
    }
    

}
