package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.service.DAO.AuthenticationDAO;
import com.objectfrontier.training.service.entity.POJO.PersonDTO;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class AuthenticationDBManager implements AuthenticationDAO {

    private ConnectionManager connectionManager;

    public AuthenticationDBManager(ConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public PersonDTO getCredentials(String email) {
        String query = new StringBuilder().append("SELECT pass                   ")
                                          .append("FROM person_credentials        ")
                                          .append("WHERE email = ?                ")
                                          .toString();
        ResultSetProcessor<PersonDTO, ResultSet> readCredentials = (resultSet) -> {

            PersonDTO personDTO = PersonDTO.create();
            while (resultSet.next()) {
                personDTO = personDTO.setPassword(resultSet.getString("pass"));
            }
            return personDTO.setEmail(email).setAdmin(isAdmin(email));
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, email);
            return readCredentials.applyOn(query, parameters, connectionManager, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public boolean isAdmin(String email) {

        String query = new StringBuilder().append("SELECT count(email)              ")
                                          .append("FROM person_admin                ")
                                          .append("WHERE email = ?                  ")
                                          .toString();
        ResultSetProcessor<Boolean, ResultSet> adminCheck = (resultSet) -> {

            while (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return true;
                }
            }
            return false;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, email);
            return adminCheck.applyOn(query, parameters, connectionManager, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }
}
