package com.objectfrontier.training.service.helper;

import java.net.URI;
import java.net.URL;

import org.eclipse.jetty.server.Server;
import org.eclipse.jetty.util.resource.Resource;
import org.eclipse.jetty.webapp.WebAppContext;
import org.testng.Assert;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;

import com.objectfrontier.training.service.entity.POJO.Result;


public class TestBaseServlet {

    private static Server server;
    private RequestHelper requestHelper;
    protected RequestHelper login(String url) throws Exception {

        RequestHelper helper = RequestHelper.create();
        String response = helper.setMethod(HttpMethod.POST).requestString(url);
        log(response);
        Result<String> result = JsonUtil.toObject(response, Result.class);
        Assert.assertEquals(result.getStatusCode(), 201);
        this.requestHelper = helper;
        return helper;
        
    }

    protected void logout(String url) throws Exception {

        String response = requestHelper.setMethod(HttpMethod.GET).requestString(url);
        log(response);
        Result<String> result = JsonUtil.toObject(response, Result.class);
        Assert.assertEquals(result.getStatusCode(), 201);
        
    }



    @BeforeSuite
    protected void initServer() throws Exception {

        server = new Server(8080);

        URL webXmlResource = server.getClass().getClassLoader().getResource("WEB-INF/web.xml");
        URI webResourceBase = webXmlResource.toURI().resolve("..").normalize();

        log("Using BaseResource: " + webResourceBase);
        WebAppContext context = new WebAppContext();
        context.setBaseResource(Resource.newResource(webResourceBase));

        context.setContextPath("/ws");
        context.setParentLoaderPriority(true);
        server.setHandler(context);
        log("Starting the server");
        server.start();

    }

    @AfterSuite
    protected void stopServer() throws Exception {
        
        server.stop();
    }
    
    void log(String message) {
    	System.out.println(message);
    }
 } 
