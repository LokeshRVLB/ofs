package com.objectfrontier.training.service.helper;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.Properties;
import java.util.Set;

import javax.json.Json;
import javax.json.JsonObjectBuilder;

public class JSONMapper {

    private Object object;
    private Properties propsFile;
    private JsonObjectBuilder objectBuilder = Json.createObjectBuilder();;

    public JSONMapper(Object object, Properties propsfile) {
        super();
        this.object = object;
        this.propsFile = propsfile;
    }

    public void prepareJSONString() throws NoSuchMethodException, SecurityException {
        Set<String> propParameters = propsFile.stringPropertyNames();
        propParameters.stream()
                      .forEach(property -> {
                          try {
                            Method  method = object.getClass().getMethod(propsFile.getProperty(property));
                            try {
                                objectBuilder.add(property, String.valueOf(method.invoke(object)));
                            } catch (IllegalAccessException | IllegalArgumentException | InvocationTargetException e) {
                                throw new RuntimeException("Unable to create json data");
                            }
                        } catch (NoSuchMethodException | SecurityException e) {
                            throw new RuntimeException(String.format("Error getting data : %s : %s", property, e));
                        }
                      });

    }   

    public JsonObjectBuilder getObjectBuilder() {
        return objectBuilder;
    }

    public void attach(String key, String value) {
        objectBuilder.add(key, value);
    }

    public void attach(String key, JsonObjectBuilder value) {
        objectBuilder.add(key, value);
    }

    public String getJSONString() {
        return objectBuilder.build().toString();
    }
}
