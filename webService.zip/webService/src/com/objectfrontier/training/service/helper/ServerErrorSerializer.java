package com.objectfrontier.training.service.helper;

import java.io.IOException;

import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.SerializerProvider;
import com.fasterxml.jackson.databind.ser.std.StdSerializer;

/**
 * @author Lokesh.
 * @since Nov 16, 2018
 */
public class ServerErrorSerializer extends StdSerializer<ServerError> {

    public ServerErrorSerializer() {
        super(ServerError.class);
    }


    @Override
    public void serialize(ServerError serverError, JsonGenerator jGen, SerializerProvider sPr) throws IOException {
        jGen.writeStartObject();
        jGen.writeNumberField("responseCode", serverError.getErrorCode());
        jGen.writeStringField("requestedURI", serverError.getRequestedURL());
        jGen.writeEndObject();
    }
}
