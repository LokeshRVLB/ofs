package com.objectfrontier.training.service.helper;

/**
 * @author Lokesh.
 * @since Nov 26, 2018
 */
public interface QueryProcessor {

    
}
