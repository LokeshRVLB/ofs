package com.objectfrontier.training.service.helper;

/**
 * @author Lokesh.
 * @since Nov 15, 2018
 */
public interface AddressFields {

    String Id = "id";
    String street = "street";
    String city = "City";
    String postalCode = "postal_code";
}
