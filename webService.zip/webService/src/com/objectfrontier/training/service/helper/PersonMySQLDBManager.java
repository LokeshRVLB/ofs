package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import com.objectfrontier.training.service.DAO.PersonDAO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public class PersonMySQLDBManager implements PersonDAO {

    @Override
    public List<Person> readAll(){

        ResultSetProcessor<List<Person>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Person> persons = new ArrayList<>(resultSet.getFetchSize());
            while (resultSet.next()) {
                Person person = new Person();
                constructPerson(resultSet, person);
                persons.add(person);
            }
            return persons;
        };

        try {
            return readAll.applyOn(PersonQuery.readAll, null, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public List<Person> readAll(int limit, int offset) {

        ResultSetProcessor<List<Person>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Person> persons = new ArrayList<>(resultSet.getFetchSize());
            while (resultSet.next()) {
                Person person = new Person();
                constructPerson(resultSet, person);
                persons.add(person);
            }
            return persons;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, limit);
            parameters.add(1, offset);
            return readAll.applyOn(PersonQuery.readAllWithOffset, parameters, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    private void constructPerson(ResultSet resultSet, Person person) throws SQLException {
        Address address;
        person.setId(resultSet.getLong(PersonFields.id));
        person.setFirstName(resultSet.getString(PersonFields.fname));
        person.setLastName(resultSet.getString(PersonFields.lname));
        person.setEmail(resultSet.getString(PersonFields.email));
        person.setBirthDate(resultSet.getDate(PersonFields.dob).toLocalDate());
        address = new Address();
        address.setId(resultSet.getLong(PersonFields.addressId));
        person.setAddress(address);
    }

    @Override
    public Person read(long id) {

        ResultSetProcessor<Person, ResultSet> read = (resultSet) -> {
            Person person = new Person();
            while (resultSet.next()) {
                constructPerson(resultSet, person);
            }
            return person;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, id);
            return read.applyOn(PersonQuery.read, parameters, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Person read(long id, boolean includeAddress) {

        if (includeAddress) {
            return read(id);
        }

        ResultSetProcessor<Person, ResultSet> read = (resultSet) -> {
            Person person = new Person();
            while (resultSet.next()) {
                person.setId(resultSet.getLong(PersonFields.id));
                person.setFirstName(resultSet.getString(PersonFields.fname));
                person.setLastName(resultSet.getString(PersonFields.lname));
                person.setEmail(resultSet.getString(PersonFields.email));
                person.setBirthDate(resultSet.getDate(PersonFields.dob).toLocalDate());
            }
            return person;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, id);
            return read.applyOn(PersonQuery.readWithoutAddress, parameters, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Person update(Person person) {

        ResultSetProcessor<Integer, Integer> update = (updatedCount) -> {
            return updatedCount;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, person.getFirstName());
            parameters.add(1, person.getLastName());
            parameters.add(2, person.getBirthDate());
            parameters.add(3, person.getId());
            update.applyOn(PersonQuery.update, parameters, true, 0);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_UPDATE_ERROR, e);
        }
    }

    @Override
    public Person delete(Person person) {

        ResultSetProcessor<Integer, Integer> delete = (deletedCount) -> {
            return deletedCount;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, person.getId());
            delete.applyOn(PersonQuery.delete, parameters, true, 0);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_DELETE_ERROR, e);
        }
    }

    @Override
    public Person create(Person person) {

        ResultSetProcessor<Long, ResultSet> insertPerson = (resultSet) -> {
            resultSet.next();
            return resultSet.getLong(1);
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, person.getFirstName());
            parameters.add(1, person.getLastName());
            parameters.add(2, person.getEmail());
            parameters.add(3, java.sql.Date.valueOf(person.getBirthDate()));
            parameters.add(4, person.getAddress().getId());

            long personId = insertPerson.applyOn(PersonQuery.create, parameters, true,
                    Statement.RETURN_GENERATED_KEYS);
            person.setId(personId);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_INSERT_ERROR, e);
        }
    }

    @Override
    public <V> boolean isPresent(String checkField, String conditionField, V value) {

        String getFieldQuery = String.format("SELECT count(%s) FROM scv_person WHERE %s = %s",
                                                    checkField,
                                                    conditionField,
                                                    value);
        boolean result = true;

        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };

        try {
            result = isPresent.applyOn(getFieldQuery, null, false, 0).booleanValue();
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

    @Override
    public <V> boolean isPresent(String checkField, String conditionalField, V value, String neglectRowWithField,
            String neglectRowWithValue) {

        String getFieldQuery = String.format("SELECT count(%s) FROM scv_person WHERE %s = \"%s\" AND %s != %s",
                                                    checkField,
                                                    conditionalField,
                                                    value,
                                                    neglectRowWithField,
                                                    neglectRowWithValue);
        boolean result = true;
        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };
        try {
            result = isPresent.applyOn(getFieldQuery, null, false, 0).booleanValue();
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

    @Override
    public List<Person> searchByAddressId(Long[] addressIds) {
        StringBuilder sBuilder = new StringBuilder();
        for (Long data : addressIds) {
            sBuilder.append("?");
            sBuilder.append(", ");
        }
        if (sBuilder.length() == 0) {
            return null;
        }
        String listOfIds = (String) sBuilder.subSequence(0, sBuilder.length() - 2);
        String query = new StringBuilder().append("SELECT scv_person.id                ")
                                          .append("      ,scv_person.first_name        ")
                                          .append("      ,scv_person.last_name         ")
                                          .append("      ,scv_person.email             ")
                                          .append("      ,scv_person.dob               ")
                                          .append("      ,scv_person.address_id        ")
                                          .append("FROM scv_person                     ")
                                          .append("WHERE scv_person.address_id IN (    ")
                                          .append(listOfIds)
                                          .append(" )                                  ")
                                          .toString();

        ResultSetProcessor<List<Person>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Person> persons = new ArrayList<>();
            while (resultSet.next()) {
                Person person = new Person();
                constructPerson(resultSet, person);
                persons.add(person);
            }
            return persons;
        };

        try {
            List<Object> parameters = new ArrayList<>(Arrays.asList(addressIds));
            return readAll.applyOn(query, parameters, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }
}
