package com.objectfrontier.training.service.helper;

import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * @author Lokesh.
 * @since Nov 14, 2018
 */
public class DataSource {

    private static HikariConfig config = new HikariConfig("resources/mysqlCredentials.properties");
    private static HikariDataSource ds;
 
    static {
        ds = new HikariDataSource( config );
    }
 
    private DataSource() {}
 
    public static Connection getConnection() throws SQLException {
        return ds.getConnection();
    }
}
