package com.objectfrontier.training.service.helper;

import java.sql.Connection;
import java.sql.SQLException;

import com.zaxxer.hikari.HikariConfig;
import com.zaxxer.hikari.HikariDataSource;

/**
 * @author Lokesh.
 * @since Nov 14, 2018
 */
public class DataSource {

    private static HikariConfig config = new HikariConfig("resources/mysqlCredentials.properties");
    private static HikariDataSource ds;
 
    static {
        ds = new HikariDataSource( config );
    }
 
    private DataSource() {}
 
    public static Connection getConnection(){
        try {
            return ds.getConnection();
        } catch (SQLException e) {
            throw new AppException(Error.SQL_CONNECTION_ERROR, e);
        }
    }
}
