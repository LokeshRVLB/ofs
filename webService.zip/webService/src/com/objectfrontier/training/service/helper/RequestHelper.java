/**
 * This file is subject to the terms and conditions defined in
 * file 'LICENSE.txt', which is part of this source code package.
 */
package com.objectfrontier.training.service.helper;

import java.io.IOException;
import java.util.List;
import java.util.Map;

import org.apache.http.Header;
import org.apache.http.HttpEntity;
import org.apache.http.HttpEntityEnclosingRequest;
import org.apache.http.HttpResponse;
import org.apache.http.ParseException;
import org.apache.http.client.methods.HttpUriRequest;
import org.apache.http.cookie.SetCookie;
import org.apache.http.entity.ContentType;
import org.apache.http.entity.StringEntity;
import org.apache.http.impl.client.HttpClientBuilder;
import org.apache.http.util.EntityUtils;
import com.objectfrontier.training.service.helper.Error;
import com.objectfrontier.training.service.helper.HttpMethod;
import com.objectfrontier.training.service.helper.AppException;

/**
 * @author Lokesh.
 * @since Nov 12, 2018
 */
public class RequestHelper {

    public static RequestHelper create() { return new RequestHelper(); }

    private String uri;
    private HttpMethod method = HttpMethod.GET;
    private Map<String, String> headers;
    private String input;
    private String sessionID;

    public RequestHelper setUri	   (String 			    uri	   ) { this.uri 	= uri;     return this; }
    public RequestHelper setMethod (HttpMethod 			method ) { this.method  = method;  return this; }
    public RequestHelper setHeaders(Map<String, String> headers) { this.headers = headers; return this; }
    public RequestHelper setInput  (String 			    input  ) { this.input   = input;   return this; }

    private void setSessionId(String             sessionID) { this.sessionID = sessionID; }

    public HttpUriRequest build(String uri) throws Exception { this.uri = uri; return build(); }
    public HttpUriRequest build() throws Exception {

        HttpUriRequest request = method.build(uri);

        if (headers != null) {
            headers.forEach((k, v) -> request.addHeader(k, v));
        }

        if (input != null) {
            StringEntity inputEntity = new StringEntity(input);
            inputEntity.setContentType(ContentType.APPLICATION_JSON.getMimeType());
            HttpEntityEnclosingRequest entityRequest = (HttpEntityEnclosingRequest) request;
            entityRequest.setEntity(inputEntity);
        }

        request.addHeader("Cookie", "JSESSIONID="+ sessionID);
        return request;
    }

    public HttpEntity requestRaw() throws Exception {
        HttpUriRequest request = build();
        HttpResponse response = HttpClientBuilder.create().build().execute(request);
        HttpEntity responseEntity = handleResponse(response);
        return responseEntity;
    }

    private HttpEntity handleResponse(HttpResponse response) throws ParseException, IOException {

        int responseStatusCode = response.getStatusLine().getStatusCode();
        HttpEntity entity = response.getEntity();
        if (responseStatusCode < 300) {
            Header[] headers = response.getHeaders("Set-Cookie");
            for(Header head : headers) {
//                System.out.println(head);
                String cookie = head.getValue();
                if (cookie.indexOf("JSESSIONID=") > -1) {
                    int start = cookie.indexOf("JSESSIONID=") + 11;
                    int end   = cookie.indexOf(";", start);
                    setSessionId(cookie.substring(start, end));
                }
            }
           
//            System.out.println(sessionID);
        }
        return entity;
    }

    public String requestString(String uri) throws Exception { this.uri = uri; return requestString(); }
    public String requestString() throws Exception { return EntityUtils.toString(requestRaw()); }

    public <T> T requestObject(String uri, Class<? extends T> type) throws Exception { this.uri = uri; return requestObject(type); }
    public <T> T requestObject(Class<? extends T> type) throws Exception {
        return JsonUtil.toObject(EntityUtils.toString(requestRaw()), type);
    }
}
