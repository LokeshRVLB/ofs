package com.objectfrontier.training.service.entity.POJO;

import com.objectfrontier.training.service.helper.AppStatusCode;
import com.objectfrontier.training.service.helper.JsonUtil;

public class Result<T> {

    private int statusCode;
    private String result;
    public int getStatusCode() {
        return statusCode;
    }
    public void setStatusCode(AppStatusCode statusCode) {
        this.statusCode = statusCode.getStatusCode();
    }
    public void setStatusCode(int statusCode) {
        this.statusCode = statusCode;
    }
    public String getResult() {
        return result;
    }
    public void setResult(T result) {
        this.result = JsonUtil.toJson(result);
    }
}
