package com.objectfrontier.training.filters;

import java.io.IOException;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.helper.Logger;

public class SessionManager extends BaseFilter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        preFilter(req, res);
        chain.doFilter(req, res);
        postFilter(req, res);
        
    }

    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        HttpSession session = request.getSession();
        Logger.log("Session Detected : %s%n", session.getId());
        Duration createdTime = Duration.ofMillis(session.getCreationTime());
        Duration presentTime = Duration.ofMillis(System.currentTimeMillis());
        if (presentTime.minus(createdTime).toHours() > 5) {
            Logger.log("Session Expired directing to Login Page%n");
            session.invalidate();
            request.getRequestDispatcher("login").forward(request, response);
        }
    }

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response) {

        if (request.getRequestURI().endsWith("logout.html")) {
            HttpSession session = request.getSession();
            if (Objects.nonNull(session)) {
                session.invalidate();
            }
        }

    }

}
