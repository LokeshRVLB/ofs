package com.objectfrontier.training.filters;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;



public abstract class BaseFilter implements Filter {

    private Logger log = Logger.getLogger(BaseFilter.class);

    protected FilterConfig filterConfig;

    protected abstract void preFilter(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException ;

    protected abstract void postFilter(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException ;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("Initialize filter: " + getClass().getSimpleName());
        this.filterConfig = filterConfig;
    }

    @Override
    public void destroy() {
        log.info("Destroy filter: " + getClass().getSimpleName());
    }
    
    protected void initLog(Class<?> clazz) {
        this.log = Logger.getLogger(clazz);
    }

    public void log(String data) {
        log.info(data);
    }

    public void log(String data, String logType) {

        if (logType.equals("error")) {
            log.error(data);
            return;
        }
        log.info(data);
    }

    public void log(StackTraceElement[] stackTraceElements) {
        StringBuilder sBuilder = new StringBuilder();
        Arrays.stream(stackTraceElements)
              .forEach(stackTraceElement -> sBuilder.append(stackTraceElement.toString()).append("\r\n"));

        log(sBuilder.toString(), "error");
    }
}
