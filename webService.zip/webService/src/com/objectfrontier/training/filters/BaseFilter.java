package com.objectfrontier.training.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public abstract class BaseFilter implements Filter {

    private Logger log = LoggerFactory.getLogger(BaseFilter.class);
    
    protected FilterConfig filterConfig;

    protected abstract void preFilter(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException ;
       
    protected abstract void postFilter(HttpServletRequest request,
            HttpServletResponse response) throws ServletException, IOException ;

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        log.info("Initialize filter: {}", getClass().getSimpleName());
        this.filterConfig = filterConfig;
    }
 
    @Override
    public void destroy() {
        log.info("Destroy filter: {}", getClass().getSimpleName());
    }
}
