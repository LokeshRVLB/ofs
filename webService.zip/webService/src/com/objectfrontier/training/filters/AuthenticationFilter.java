package com.objectfrontier.training.filters;

import java.io.IOException;
import java.util.Objects;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.helper.Logger;
/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class AuthenticationFilter extends BaseFilter {


    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        Logger.log("Authentication filter%n");
        HttpServletRequest req = (HttpServletRequest) request;
        String uri = req.getRequestURI();
        
        HttpSession session = req.getSession(false);
        if (Objects.isNull(session)|| uri.endsWith("login.html")) {
            Logger.log("Redirecting to Login page%n");
            request.getRequestDispatcher("login").forward(request, response);
        } else if (Objects.isNull(session.getAttribute("userDetails"))) {
            Logger.log("Redirecting to Login page%n");
            request.getRequestDispatcher("login").forward(request, response);
        } else {
            chain.doFilter(request, response);
        }
    }


    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response) {}

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response) {}
    
}
