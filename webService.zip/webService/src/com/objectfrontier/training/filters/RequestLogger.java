package com.objectfrontier.training.filters;

import java.io.IOException;
import java.util.Optional;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.entity.POJO.PersonDTO;
import com.objectfrontier.training.service.helper.Logger;

public class RequestLogger extends BaseFilter{


    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;

        preFilter(req, res);
        chain.doFilter(request, response);
        postFilter(req, res);
       
        
    }

    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response) {

        Logger.log("Request Log - before Request processing%n");
        HttpSession session = request.getSession();
        PersonDTO personDTO = null;
        String email = null;
        if (session != null) {
            personDTO = (PersonDTO) session.getAttribute("userDetails");
            if (personDTO != null) { email = personDTO.getEmail(); }
        }
        email = Optional.ofNullable(email).orElse("UNKNOWN USER");
        Logger.log(
          "Request from %s : '%s@%s'%n",
          email, 
          request.getRemoteAddr(),
          request.getRequestURI());
    }

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response) {

//        Logger.log("Request Log - after Request processing%n");
//        HttpSession session = request.getSession();
//        PersonDTO personDTO = null;
//        String email = null;
//        if (session != null) {
//            personDTO = (PersonDTO) session.getAttribute("userDetails");
//            if (personDTO != null) { email = personDTO.getEmail(); }
//        }
//        email = Optional.ofNullable(email).orElse("UNKNOWN USER");
//        Logger.log(
//          "Request from %s : '%s@%s'%n",
//          email, 
//          request.getRemoteAddr(),
//          request.getRequestURI());
    }

}
