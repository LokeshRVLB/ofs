package com.objectfrontier.training.filters;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.util.Logger;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */

public class PerformanceMeasureFilter extends BaseFilter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        super.init(filterConfig);
        initLog(getClass());
    }

    @Override
    public void doFilter(ServletRequest req, ServletResponse res, FilterChain chain)
            throws IOException, ServletException {
        long start = System.currentTimeMillis();
        log(String.format("Execution Start time : %d ms%n", start));
        chain.doFilter(req, res);
        long stop = System.currentTimeMillis();
        log(String.format("Execution End time : %d ms%n", stop));
        log(String.format("Total Execution Time : %d ms%n", stop - start));
    }

    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }
}
