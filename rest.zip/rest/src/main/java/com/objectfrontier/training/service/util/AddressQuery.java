package com.objectfrontier.training.service.util;

/**
 * @author Lokesh.
 * @since Nov 22, 2018
 */
public interface AddressQuery {

    String readAll = new StringBuilder().append("SELECT scv_address.id            ")
                                        .append("      ,scv_address.street        ")
                                        .append("      ,scv_address.city          ")
                                        .append("      ,scv_address.postal_code   ")
                                        .append("FROM scv_address                 ")
                                        .toString();

    String readAllWithOffset = new StringBuilder().append("SELECT scv_address.id            ")
                                                  .append("      ,scv_address.street        ")
                                                  .append("      ,scv_address.city          ")
                                                  .append("      ,scv_address.postal_code   ")
                                                  .append("FROM scv_address LIMIT ? OFFSET ?")
                                                  .toString();

    String read = new StringBuilder().append("SELECT scv_address.id            ")
                                     .append("      ,scv_address.street        ")
                                     .append("      ,scv_address.city          ")
                                     .append("      ,scv_address.postal_code   ")
                                     .append("FROM scv_address WHERE id = ?    ")
                                     .toString();

    String update = new StringBuilder().append("UPDATE scv_address                ")
                                       .append("SET scv_address.street = ?        ")
                                       .append("   ,scv_address.city = ?          ")
                                       .append("   ,scv_address.postal_code = ?   ")
                                       .append("WHERE scv_address.id = ?;         ")
                                       .toString();

    String delete = new StringBuilder().append("DELETE FROM scv_address ")
                                       .append("WHERE scv_address.id = ?")
                                       .toString();

    String create = new StringBuilder().append("INSERT INTO scv_address (scv_address.street      ")
                                       .append("                        ,scv_address.city        ")
                                       .append("                        ,scv_address.postal_code)")
                                       .append("VALUES (?, ?, ?)                                 ")
                                       .toString();
}
