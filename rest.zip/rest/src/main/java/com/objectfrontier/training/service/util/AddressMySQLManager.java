package com.objectfrontier.training.service.util;

import java.sql.ResultSet;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.hibernate.engine.jdbc.spi.ResultSetReturn;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.objectfrontier.training.service.DAO.AddressDAO;
import com.objectfrontier.training.service.entity.model.Address;
import com.objectfrontier.training.service.entity.model.Person;

/**
 * @author Lokesh.
 * @since Oct 12, 2018
 */

@Repository
public class AddressMySQLManager implements AddressDAO {

    @Autowired
    private SessionFactory sessionFactory;
    
    public AddressMySQLManager() {}

    @SuppressWarnings("unchecked")
    @Override
    public List<Address> readAll() {
        return (List<Address>)getSessionFactory().getCurrentSession()
                                                 .createQuery("from Address")
                                                 .list();
        
    }
    @Override
    public Address read(long id) {
        return getSessionFactory().getCurrentSession()
                                  .load(Address.class, new Long(id));
    }

    @Override
    public Address update(Address address) {

        getSessionFactory().getCurrentSession()
                           .update(address);
        return address;
    }

    @Override
    public Address delete(Address address) {

        getSessionFactory().getCurrentSession()
                               .delete(address);
        return address;
        
    }

    @Override
    public Address create(Address address) {

        getSessionFactory().getCurrentSession()
                           .persist(address);
        return address;
    }

    @Override
    public <V> boolean isPresent(String checkField, String conditionField, V value) {

        String getFieldQuery = MessageFormat.format("SELECT count({0}) FROM scv_address WHERE {1} = {2}",
                                                    checkField,
                                                    conditionField,
                                                    value);
        boolean result = true;

        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (resultSet.getInt(1) > 0) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };

        try {
            result = isPresent.applyOn(getFieldQuery, null, false, 0).booleanValue();
        } catch (Exception e) {
            new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

    @Override
    public List<Address> search(String[] fields, String searchText) {

        String query = String.format("SELECT id, street, city, postal_code FROM scv_address WHERE %s ",
                        constructSearchCondition(fields, searchText));
        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());

            while (resultSet.next()) {
                Address address = new Address(resultSet.getString(AddressFields.street),
                                              resultSet.getString(AddressFields.city),
                                              resultSet.getLong(AddressFields.postalCode));
                address.setId(resultSet.getLong(AddressFields.Id));
                addresses.add(address);
            }
            return addresses;
        };

        try {
            List<Object> parameters = new ArrayList<>();
            for (int i = 0; i < fields.length; i++) {
                parameters.add(i, searchText);
            }
            return readAll.applyOn(query, parameters, false, 0);
        } catch (Exception e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    private String constructSearchCondition(String[] fields, String searchText) {

        String[] constantFields = new String[] { "city", "postal_code", "street" };
        int count = 0;
        for (int i = 0; i < fields.length; i++) {
            for (int j = 0; j < constantFields.length ; j++) {
                if (fields[i].equals(constantFields[j])) {
                    count++;
                }
            }
        }
        if (count != fields.length) {
            throw new AppException(Error.INVALID_SEARCH_FIELDS);
        }
        if (searchText.equals("%%")) {
            throw new AppException(Error.EMPTY_SEARCH_TEXT);
        }
        StringBuilder sBuilder = new StringBuilder();
        for (String field : fields) {
            sBuilder.append(String.format(" %s LIKE ? OR ", field));
            
        }
        return sBuilder.substring(0, sBuilder.length() - 3);
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }

    @Override
    public List<Address> readAll(int limit, int offset) {
        // TODO Auto-generated method stub
        return null;
    }
}
