package com.objectfrontier.training.service.util;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;


/**
 * @author Lokesh.
 * @since Dec 31, 2018
 */
public class Validator implements ConstraintValidator<Validate, String> {

    @Override
    public void initialize(Validate validate) { }  
    
    @Override
    public boolean isValid(String value, ConstraintValidatorContext cxt) {

        if(value == null || value.isEmpty()) {
            return false;
        }
        return true;
    }
}
