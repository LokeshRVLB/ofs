package com.objectfrontier.training.service.util;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.stream.Collectors;

public class AppException extends RuntimeException {

    private static final long serialVersionUID = 8064232198790181877L;
    protected Error error;
    protected int errorCode;
    private ArrayList<Error> associatedErrors;

    public AppException(Error[] errors, Error error) {
        this(error); 
        if ( associatedErrors == null) {
            this.associatedErrors = Arrays.stream(errors).collect(Collectors.toCollection(ArrayList::new));
        } else {
            associatedErrors.addAll(Arrays.asList(errors));
        }
    }

    public AppException() {
        super();
    }
    
    public AppException(Exception e) {
        super(e);
    }

    public AppException(Error error) {
        super(error.getMessage());
        this.error = error;
        this.errorCode = error.getErrorCode();
    }
    public AppException(Error[] errors) {
        setErrorCodes(errors);
    }

    public AppException(Error error, Exception cause) {
        super(error.getMessage(), cause);
        this.error = error;
        this.errorCode = error.getErrorCode();
    }
    
    public Error[] getAssociatedErrors() {
        if (associatedErrors == null) {
            return new Error[] { };
        } else {
            return associatedErrors.toArray(new Error[associatedErrors.size()]);
        }
    }

    public void setErrorCodes(Error[] errors) {
        if ( associatedErrors == null) {
            this.associatedErrors = Arrays.stream(errors).collect(Collectors.toCollection(ArrayList::new));
        } else {
            associatedErrors.addAll(Arrays.asList(errors));
        }
    }

    public int getErrorCode() {
        return errorCode;
    }

    public Error getError() {
        return error;
    }

}
