package com.objectfrontier.training.service.DAO;

import java.util.List;

import com.objectfrontier.training.service.entity.model.Person;

/**
 * @author Lokesh.
 * @since Sep 27, 2018
 */
public interface PersonDAO {

    List<Person> readAll();

    List<Person> readAll(int limit, int offset);

    Person read(long id);

    Person read(long id, boolean includeAddress);

    Person update(Person person);

    Person delete(Person person);

    Person create(Person person);

    <V> boolean isPresent(String checkField, String conditionalField, V value);

    <V> boolean isPresent(String checkField, String conditionalField, V value, String neglectRowWithField,
            String neglectRowWithValue);

    List<Person> searchByAddressId(Long[] addressIds);
}
