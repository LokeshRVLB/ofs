package com.objectfrontier.training.filters;

import java.io.IOException;
import java.util.Objects;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.objectfrontier.training.service.util.AppException;
import com.objectfrontier.training.service.util.Error;
/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
public class AuthenticationFilter extends BaseFilter {

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        super.init(filterConfig);
        initLog(getClass());
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        log("Authorising the request");
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
        String uri = req.getRequestURI();
        HttpSession session = req.getSession(false);

        if (uri.endsWith("login")) {
            redirect(req, res);
        } else if (Objects.isNull(session)|| Objects.isNull(session.getAttribute("userDetails"))) {
            log("No user credentials for login. Log in failed. Terminating request", "error");
            throw new AppException(Error.NO_LOGIN_SESSION);
        } else {
            chain.doFilter(request, response);
        }
    }


    private void redirect(HttpServletRequest req, HttpServletResponse res) throws IOException, ServletException {

        log("Redirecting to Login page%n");
        req.getServletContext().getRequestDispatcher("/login").forward(req, res);

    }


    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response) {}

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response) {}

}
