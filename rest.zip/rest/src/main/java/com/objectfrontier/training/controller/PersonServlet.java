package com.objectfrontier.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.model.Person;
import com.objectfrontier.training.service.util.BeanUtil;

/**
 * Servlet implementation class PersonServlet
 * @author Lokesh.
 * @since Nov 2, 2018
 */

@Controller
@RequestMapping("/person")
public class PersonServlet extends BaseServlet {
    
    @Autowired
    @Qualifier("personService")
    PersonService personService;
    
    public PersonServlet() {
        super();
    }

    {
        initLog(getClass());
    }

    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action=read"},
            produces = "application/json"
            )
    @ResponseBody Person read(@RequestParam("id") long id,
                              @RequestParam("addStatus") boolean status) {
        personService = BeanUtil.getBean(PersonService.class);
        return personService.read(id, status);
    }
    
    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action=search"}
            )
    @ResponseBody List<Person> search(@RequestParam("searchFields") String searchFields,
                                       @RequestParam("searchText") String searchText) {
        personService = BeanUtil.getBean(PersonService.class);
        String[] fields = searchFields.split(",");
        return personService.searchPersonByAddress(fields, searchText);
    }
    
    @RequestMapping(
            method = RequestMethod.GET,
            params = { "action=readAll" },
            produces = "application/json"
            )
    @ResponseBody List<Person> readAll() {
        personService = BeanUtil.getBean(PersonService.class);
        log("entered readAll");
        List<Person> persons = personService.readAll();
        return persons;
    }
    
    @RequestMapping(
            method = RequestMethod.POST
            )
    @ResponseBody Person doPost(@RequestParam("action") String action,
                                @RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        if (action.equals("update")) { return personService.update(person); }
        return personService.delete(person);
    }
    
    @RequestMapping(
            method = RequestMethod.PUT
            )
    @ResponseBody Person doPut(@RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        return personService.create(person);
    }
    
}
