package com.objectfrontier.training.service.util;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;

@Transactional
public class GenericDAO<E> {
    private Class<E> entityClass;
    
    @Autowired
    private SessionFactory sessionFactory;

    public GenericDAO(Class<E> entityClass) {
        this.entityClass = entityClass;
    }
 
    @SuppressWarnings("unchecked")
    public List<E> findAll() {
        return getSessionFactory().openSession()
                                  .createQuery("from " + entityClass.getSimpleName())
                                  .list();
    }
 
    public E persist(E toPersist) {
        getSessionFactory().openSession().persist(toPersist);
        return toPersist;
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
}
