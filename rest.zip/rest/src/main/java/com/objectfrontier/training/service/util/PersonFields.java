package com.objectfrontier.training.service.util;

public interface PersonFields {

    String id = "id";
    String fname = "first_name";
    String lname = "last_name";
    String email = "email";
    String dob = "dob";
    String addressId = "address_id";
}
