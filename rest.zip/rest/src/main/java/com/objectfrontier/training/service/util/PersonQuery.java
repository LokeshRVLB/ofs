package com.objectfrontier.training.service.util;

public interface PersonQuery {
    
    String readAll = new StringBuilder().append("SELECT scv_person.id         ")
                                        .append("      ,scv_person.first_name ")
                                        .append("      ,scv_person.last_name  ")
                                        .append("      ,scv_person.email      ")
                                        .append("      ,scv_person.dob        ")
                                        .append("      ,scv_person.address_id ")
                                        .append("FROM scv_person              ")
                                        .toString();

    String readAllWithOffset = new StringBuilder().append("SELECT scv_person.id             ")
                                                  .append("      ,scv_person.first_name     ")
                                                  .append("      ,scv_person.last_name      ")
                                                  .append("      ,scv_person.email          ")
                                                  .append("      ,scv_person.dob            ")
                                                  .append("      ,scv_person.address_id     ")
                                                  .append("FROM scv_person LIMIT ? OFFSET ? ")
                                                  .toString();

    String read = new StringBuilder().append("SELECT scv_person.id         ")
                                     .append("      ,scv_person.first_name ")
                                     .append("      ,scv_person.last_name  ")
                                     .append("      ,scv_person.email      ")
                                     .append("      ,scv_person.dob        ")
                                     .append("      ,scv_person.address_id ")
                                     .append("FROM scv_person              ")
                                     .append("WHERE scv_person.id = ?      ")
                                     .toString();

    String readWithoutAddress = new StringBuilder().append("SELECT scv_person.id                   ")
                                                   .append("      ,scv_person.first_name           ")
                                                   .append("      ,scv_person.last_name            ")
                                                   .append("      ,scv_person.email                ")
                                                   .append("      ,scv_person.dob                  ")
                                                   .append("FROM scv_person WHERE scv_person.id = ?")
                                                   .toString();

    String update = new StringBuilder().append("UPDATE scv_person            ")
                                       .append("SET scv_person.first_name = ?")
                                       .append("   ,scv_person.last_name = ? ")
                                       .append("   ,scv_person.dob = ?       ")
                                       .append("WHERE scv_person.id = ?;     ")
                                       .toString();

    String delete = new StringBuilder().append("DELETE FROM scv_person ")
                                       .append("WHERE scv_person.id = ?")
                                       .toString();

    String create = new StringBuilder().append("INSERT INTO scv_person ( scv_person.first_name")
                                       .append("                    ,scv_person.last_name     ")
                                       .append("                    ,scv_person.email         ")
                                       .append("                    ,scv_person.dob           ")
                                       .append("                    ,scv_person.address_id)   ")
                                       .append("VALUES (?, ?, ?, ?, ?)                        ")
                                       .toString();
}
