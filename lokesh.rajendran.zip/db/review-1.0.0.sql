CREATE DATABASE car_dealer;
USE car_dealer;
SHOW TABLES;
CREATE TABLE sc_car ( id INT PRIMARY KEY
							,model_name VARCHAR(30) NOT NULL
							,color	VARCHAR(10) NOT NULL
							,cost		FLOAT NOT NULL);
							
CREATE TABLE sc_customer ( id INT PRIMARY KEY
								,customer_name VARCHAR(30)
								,customer_address VARCHAR(40)
								);

ALTER TABLE sc_car MODIFY id INT AUTO_INCREMENT;
ALTER TABLE sc_customer MODIFY id INT AUTO_INCREMENT;
INSERT INTO sc_car(model_name,color,cost) VALUES
 ("ASDS","BLUE",2323)
,("SDsD","RED",3432) 							 
INSERT INTO sc_customer(customer_name,customer_address) VALUES
 ("ljens","chennai")
,("SDsD","vellore") 						

ALTER TABLE sc_customer ADD car_id INT;	 

ALTER TABLE sc_customer ADD CONSTRAINT customer_car_fk FOREIGN KEY(car_id) REFERENCES sc_car(id);

UPDATE sc_customer 
SET car_id =(SELECT id FROM sc_car WHERE model_name = "ASDS" LIMIT 1)
WHERE customer_name = "ljens";

SELECT sc_car.modeL_name FROM sc_car WHERE id IN ( SELECT car_id FROM sc_customer WHERE car_id IS NOT NULL);
