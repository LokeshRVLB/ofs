-- making product,sutomer id of orders table as foreign key to products,customers table id field
ALTER TABLE sc_orders 
ADD FOREIGN KEY (product_id) 
REFERENCES sc_products (id),							
ADD FOREIGN KEY (customer_id) 
REFERENCES sc_customers (id);	

ALTER TABLE sc_products 
ADD noof_items_in_stock INT;
-- adding primary  key via alter command
ALTER TABLE sc_test_entity 
ADD PRIMARY KEY(id);

-- changing a column via alter command
ALTER TABLE sc_test_entity	
CHANGE field_to_be_changed  field_changed INT ;

-- droping a column via alter command
ALTER TABLE sc_test_entity 
DROP COLUMN field_to_be_dropped;

CREATE INDEX sc_index_products ON sc_products(id DESC);
/*
ALTER TABLE sc_student RENAME TO sc_students;
ALTER TABLE sc_students RENAME TO sc_student;
*/
/*
CREATE TABLE sc_test (
								id INT
							,  item VARCHAR(30)
							,  roll INT);

CREATE TABLE sc_test (
								id INT
							,  item VARCHAR(30)
							,  rolls INT);								
SHOW TABLES;
ALTER TABLE sc_test_copy ADD PRIMARY KEY(rolls);
ALTER TABLE sc_test ADD CONSTRAINT fk_id FOREIGN KEY(roll) REFERENCES sc_test_copy(rolls) ON DELETE NO ACTION ON UPDATE NO ACTION;
ALTER TABLE sc_test_copy DROP COLUMN id;
ALTER TABLE sc_test_copy ADD id INT;  
ALTER TABLE sc_test_copy DROP id;
ALTER TABLE sc_test_copy MODIFY id INT;  
ALTER TABLE sc_test_copy CHANGE COLUMN id  ids INT;
ALTER TABLE sc_test_copy CHANGE COLUMN ids  id INT;
EXPLAIN sc_test;
INSERT INTO sc_test  (id,item) VALUES (1,'sd')
												  ,(2,'dd')
												  ,(3,'as')
												  ,(4,'ad'); 

INSERT INTO sc_test (id,roll) VALUES 
(1,1),
(2,2),
(3,3),
(4,4)
ON DUPLICATE KEY UPDATE roll=VALUES(roll);
DROP TABLE sc_test,sc_test_copy;
*/