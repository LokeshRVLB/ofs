SELECT * FROM 	sc_vendors;
SELECT * FROM 	sc_products;
SELECT * FROM 	sc_customers;
SELECT * FROM 	sc_orders;
SELECT * FROM 	sc_teacher;
SELECT * FROM 	sc_student;

SELECT * FROM sc_student,sc_teacher;		/*See correlation*/

/*Demonstrating Like and Regex in SQL */
SELECT * FROM sc_teacher WHERE teacher_name LIKE "K%_i%";

/* Demonstrating GROUP BY,COUNT,HAVING in sql */
SELECT COUNT(id) AS noof_students_with_same_name,student_name FROM sc_student
GROUP BY student_name
HAVING noof_students_with_same_name>1;