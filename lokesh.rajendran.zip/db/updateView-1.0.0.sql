CREATE OR REPLACE VIEW sc_view_right AS
SELECT teacher_name,student_name FROM sc_student
LEFT JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
SELECT * FROM sc_view_right;
DROP VIEW sc_view_right;