/* checkout view is created joining orders, customers , products and vendors table. This view is used in billing, transaction and shipping process */
CREATE VIEW sc_view_checkout AS
SELECT sc_orders.date_time
		, sc_products.id AS product_id
		, sc_products.product
		, sc_products.cost
		, SUM(quantity) AS total_quantity
		, SUM(quantity*cost) AS total_cost
		, sc_customers.id AS customer_id
		, sc_customers.customer
		, sc_customers.email_id AS customer_email_id
		, sc_customers.phone AS customer_phone
		, sc_customers.address AS customer_address
		, sc_vendors.id AS vendor_id 
		, sc_vendors.brand
		, sc_vendors.vendor_address
FROM sc_orders
INNER JOIN sc_customers ON sc_orders.customer_id = sc_customers.id
INNER JOIN sc_products ON sc_orders.product_id = sc_products.id
INNER JOIN sc_vendors ON sc_products.vendor_id = sc_vendors.id
GROUP BY product,customer_address;


-- explaining joins in teacher students table
CREATE VIEW sc_view_inner AS
SELECT teacher_name,student_name
FROM sc_student
INNER JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
CREATE VIEW sc_view_left AS
SELECT teacher_name,student_name
FROM sc_student
LEFT JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
CREATE VIEW sc_view_right AS
SELECT teacher_name,student_name
FROM sc_student
RIGHT JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
CREATE VIEW sc_view_cross AS
SELECT teacher_name,student_name
FROM sc_student CROSS
JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
CREATE VIEW sc_view_cross_two AS
SELECT teacher_name,student_name
FROM sc_teacher CROSS
JOIN sc_student;
CREATE VIEW sc_view_join AS
SELECT teacher_name,student_name
FROM sc_student
JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;


/* Implementing outer join with UNION */
CREATE VIEW sc_view_outer AS
SELECT *
FROM sc_view_left UNION
SELECT *
FROM sc_view_right;





