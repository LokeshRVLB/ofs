

/* inserting vendor details into vendor table*/
INSERT INTO sc_vendors VALUES
 (1,"Apple","20,Khan,Banglore - 400011")
,(2,"Dell","13,Himalayan,Mumbai - 300181")
,(3,"Lenovo","23,North,Chennai- -600011")
,(4,"Titan","21,India, Hyderabad - 500127");

/* inserting products details into products details */
INSERT INTO sc_products (id,product,cost,vendor_id) VALUES
(1,"Titan Watch",800,4)
,(2,"Apple iphone X",102000,1)
,(3,"Lenovo yoga Laptop",45400,3)
,(4,"Dell PC",23000,2)
,(5,"Apple Ipad",76000,4)
,(6,"Lenovo 30-50",40000,3)
,(7,"Lenovo Vibe mobile",10000,3)
,(8,"Dell Laptop",50000,2);


INSERT INTO sc_products (noof_items_in_stock) VALUES (20);
UPDATE sc_products 
SET noof_items_in_stock = 20 
WHERE id > 0;

/* inserting customer details into customer table*/
INSERT INTO sc_customers (customer,email_id,phone,address) VALUES
("Lokesh","lokesh@gmail.com","9160164239","20-313,Hassan,Chittoor,Andhra Pradesh -517001")
,("Chandu","chandu@gmail.com","9821293343","12-232,North, chennai- 600011")
,("Vijaya","vijaya@gmail.com","9019182373","20,Himalayan,Mumbai-400128")
,("Boovan" ,"Boovan@gmail.com","783838034","20,Indian corner,Hyderabad-510002");


/*Inserting data into orders table*/
INSERT INTO sc_orders VALUES (1,NOW(),4,1,1)
									  ,(2,NOW(),2,1,2)
									  ,(3,NOW(),1,2,1)
							   	  ,(4,NOW(),3,1,3)
						           ,(5,NOW(),2,3,4)
									  ,(6,NOW(),3,1,1)
									  ,(7,NOW(),2,2,2)
								     ,(8,NOW(),1,1,1);
/* inserting data into teachers table*/
INSERT INTO sc_teacher (id , teacher_name) VALUES
							  (1,"Yamini")
							 ,(2,"Chandu")
							 ,(3,"Kokila");
							 
/*inserting data into students table*/
INSERT INTO sc_student (id , student_name, teacher_id) VALUES
							  (1,"Balaji",1)
							 ,(2,"Chandu",1)
							 ,(3,"Kokila",3)
							 ,(4,"Chandu",6)
							 ,(5,"Kokila",8);							 