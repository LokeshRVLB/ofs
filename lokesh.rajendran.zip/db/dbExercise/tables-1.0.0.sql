--university table is created to store the university details
CREATE TABLE eds_university( univ_code CHAR(4)  
									,university_name VARCHAR(100) NOT NULL
									,PRIMARY KEY(univ_code));
									
--designation table stores available designations
CREATE TABLE eds_designation(id INT 						AUTO_INCREMENT
									,desi_name VARCHAR(30) 		NOT NULL UNIQUE
									,rank	CHAR(1) 					NOT NULL 
									,PRIMARY KEY(id));
			
CREATE TABLE eds_department(dept_code CHAR(4) 	
									,univ_code CHAR(4) 			NOT NULL 
									,dept_name VARCHAR(50) 		NOT NULL UNIQUE
									,PRIMARY KEY(dept_code)
									,CONSTRAINT fk__department_university 
									 FOREIGN KEY (univ_code)
									 REFERENCES eds_university (univ_code)
									 ON DELETE NO ACTION ON UPDATE NO ACTION);


CREATE TABLE eds_college(id INT 							AUTO_INCREMENT
							  ,univ_code CHAR(4)				NOT NULL
							  ,clg_code CHAR(4) 				NOT NULL UNIQUE 
							  ,clg_name VARCHAR(100) 		NOT NULL
							  ,city VARCHAR(50) 				NOT NULL
							  ,state VARCHAR(50) 			NOT NULL
							  ,year_opened YEAR(4) 			NOT NULL
							  ,PRIMARY KEY(id)
							  ,CONSTRAINT fk__college_department
								FOREIGN KEY (univ_code)
								REFERENCES eds_university (univ_code)
								ON DELETE NO ACTION ON UPDATE NO ACTION);
								
CREATE TABLE eds_college_department(cdept_id INT 		AUTO_INCREMENT
											 ,udept_code CHAR(4) 	NOT NULL
											 ,college_id INT 			NOT NULL
											 ,PRIMARY KEY(cdept_id)
											 ,CONSTRAINT fk__collegedepartment_department
												FOREIGN KEY (udept_code)
												REFERENCES eds_department (dept_code)
												ON DELETE NO ACTION ON UPDATE NO ACTION
											,CONSTRAINT fk__collegedepartment_college
												FOREIGN KEY (college_id)
												REFERENCES eds_college (id)
												ON DELETE NO ACTION ON UPDATE NO ACTION);
		
CREATE TABLE eds_syllabus(id INT 					AUTO_INCREMENT
                        ,cdept_id INT 				NOT NULL UNIQUE
                        ,syllabus_code CHAR(4) 	NOT NULL UNIQUE
                        ,syllabus_name VARCHAR(100) NOT NULL UNIQUE
                        ,PRIMARY KEY(id)
                        ,CONSTRAINT fk__syllbaus_collegedepartment
								FOREIGN KEY (cdept_id)
								REFERENCES eds_college_department (cdept_id)
								ON DELETE NO ACTION ON UPDATE NO ACTION);
							
								
CREATE TABLE eds_syllabus(id INT AUTO_INCREMENT
                        ,cdept_id INT NOT NULL 
                        ,syllabus_code CHAR(4) NOT NULL UNIQUE
                        ,syllabus_name VARCHAR(100) NOT NULL UNIQUE
                        ,PRIMARY KEY(id)
                        ,CONSTRAINT fk__sylbaus_college_department
								FOREIGN KEY (cdept_id)
								REFERENCES eds_college_department (cdept_id)
								ON DELETE NO ACTION ON UPDATE NO ACTION);
ALTER TABLE eds_syllabus DROP INDEX syllabus_name;
								
								
CREATE TABLE eds_employee(id INT AUTO_INCREMENT
								 ,college_id INT NOT NULL 
								 ,cdept_id  INT 
								 ,desig_id  INT
								 ,emp_name VARCHAR(100) NOT NULL
								 ,dob		DATE NOT NULL
								 ,email	VARCHAR(100) NOT NULL UNIQUE
								 ,phone	BIGINT NOT NULL UNIQUE
								 ,PRIMARY KEY(id)
								 ,CONSTRAINT fk__employee_college
								   FOREIGN KEY (college_id)
									REFERENCES eds_college (id)
									ON DELETE NO ACTION ON UPDATE NO ACTION
								 ,CONSTRAINT fk__employee_collegedepartment
									FOREIGN KEY (cdept_id)
									REFERENCES eds_college_department(cdept_id)
									ON DELETE NO ACTION ON UPDATE NO ACTION
								 ,CONSTRAINT fk__employee_designation
									FOREIGN KEY (desig_id)
									REFERENCES eds_designation(id)
									ON DELETE NO ACTION ON UPDATE NO ACTION);
							
			
CREATE TABLE eds_profesor_syllabus(emp_id INT NOT NULL
												,syllabus_id INT NOT NULL
												,semester TINYINT
												,CONSTRAINT fk__profesorsyllabus_employee 
												 FOREIGN KEY(emp_id)
												 REFERENCES eds_employee(id)
												 ON DELETE NO ACTION ON UPDATE NO ACTION
												,CONSTRAINT fk__profesorsyllabus_syllabus
												 FOREIGN KEY(syllabus_id)
												 REFERENCES eds_syllabus(id)
												 ON DELETE NO ACTION ON UPDATE NO ACTION);
									
CREATE TABLE eds_student(id INT AUTO_INCREMENT
								,cdept_id INT
								,college_id  INT
								,stu_name VARCHAR(100) NOT NULL
 								,roll_no  CHAR(8) NOT NULL
 								,dob DATE NOT NULL
 								,gender CHAR(1) NOT NULL
 								,email VARCHAR(50)
 								,phone BIGINT NOT NULL
 								,address VARCHAR(200) NOT NULL
 								,academic_year YEAR(4) NOT NULL
 								,PRIMARY KEY(id)
 								,CONSTRAINT fk__student_college
								   FOREIGN KEY (college_id)
									REFERENCES eds_college (id)
									ON DELETE NO ACTION ON UPDATE NO ACTION
								,CONSTRAINT fk__student_collegedepartment
									FOREIGN KEY (cdept_id)
									REFERENCES eds_college_department(cdept_id)
									ON DELETE NO ACTION ON UPDATE NO ACTION);
									
CREATE TABLE eds_address(id INT PRIMARY KEY AUTO_INCREMENT
								,dno INT NOT NULL
								,street VARCHAR(40) NOT NULL
								,city VARCHAR(40) NOT NULL
								,state VARCHAR(40) NOT NULL
								)
								
ALTER TABLE eds_student ADD COLUMN address INT;



CREATE TABLE eds_semester_fee(stu_id INT NOT NULL
									  ,cdept_id INT NOT NULL
									  ,semester TINYINT NOT NULL
									  ,amount 	DOUBLE(18,2)
									  ,paid_year YEAR(4)
									  ,paid_status VARCHAR(10) NOT NULL
									  ,CONSTRAINT fk__semesterfee_student
									  	FOREIGN KEY(stu_id) 
									  	REFERENCES eds_student(id)
									  	ON DELETE NO ACTION ON UPDATE NO ACTION
									  ,CONSTRAINT fk__semesterfee_collegedepartment
									  	FOREIGN KEY(cdept_id)
									  	REFERENCES eds_college_department(cdept_id)
									  	ON DELETE NO ACTION ON UPDATE NO ACTION);
								
CREATE TABLE eds_semesters_result(stu_id INT NOT NULL
											,syllabus_id INT NOT NULL
											,semester TINYINT NOT NULL
											,grade VARCHAR(2) NOT NULL
											,credits FLOAT NOT NULL
											,result_date DATE NOT NULL
											,CONSTRAINT fk__semestersresult_student
											  	FOREIGN KEY(stu_id) 
											  	REFERENCES eds_student(id)
											  	ON DELETE NO ACTION ON UPDATE NO ACTION
											,CONSTRAINT fk__semestersresult_syllabus
												 FOREIGN KEY(syllabus_id)
												 REFERENCES eds_syllabus(id)
												 ON DELETE NO ACTION ON UPDATE NO ACTION);
												 
												 
												 
