


-- new table is created to save next semester fee details
CREATE TABLE eds_new_semester_fee(stu_id INT NOT NULL
									  ,cdept_id INT NOT NULL
									  ,semester TINYINT NOT NULL
									  ,amount 	DOUBLE(18,2) DEFAULT 22000
									  ,paid_year YEAR(4)  DEFAULT NULL
									  ,paid_status VARCHAR(10) DEFAULT "UNPAID" 
									  ,CONSTRAINT fk_new_semesterfee_student
									  	FOREIGN KEY(stu_id) 
									  	REFERENCES eds_student(id)
									  	ON DELETE NO ACTION ON UPDATE NO ACTION
									  ,CONSTRAINT fk_new_semesterfee_collegedepartment
									  	FOREIGN KEY(cdept_id)
									  	REFERENCES eds_college_department(cdept_id)
									  	ON DELETE NO ACTION ON UPDATE NO ACTION);
								

--Data from the view created is transfered from 
INSERT INTO eds_new_semester_fee (stu_id,cdept_id,semester)
SELECT sid
		,new_semester
		,cdept_id
FROM 

(SELECT id AS sid
		,semester+1 AS new_semester
		,eds_student.cdept_id
FROM eds_semester_fee
JOIN eds_student
ON eds_semester_fee.stu_id = eds_student.id)
AS eds_View_q5_fee_student

WHERE new_semester<9;

SELECT * FROM eds_new_semester_fee;
