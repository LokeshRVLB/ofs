SELECT roll_no
		,stu_name AS student_name
		,dob
		,gender
		,email
		,phone
		,address
		,academic_year
		,clg_name AS college_name
		,university_name  
FROM eds_student
INNER JOIN 
(SELECT id AS clg_id
		,clg_name
		,university_name
FROM eds_university 
JOIN eds_college
ON eds_college.univ_code=eds_university.univ_code) 
AS eds_view_q2_clg_univ

ON eds_view_q2_clg_univ.clg_id = eds_student.college_id
WHERE id IN (SELECT stu_id 
				 FROM  eds_Semester_fee 
				 WHERE semester = 4) 
AND
college_id IN (SELECT eds_college.id 
               FROM eds_college 
					WHERE 
					eds_College.univ_code = ( SELECT eds_university.univ_code 
													  FROM eds_university 
								 					  WHERE eds_university.university_name="Jawaharlal Nehru University"));
