SELECT emp_name AS employee_name
		,email
		,rank
		,dept_name AS department_name
		,clg_name AS college_name
FROM

(SELECT eds_designation.rank
		,eds_employee.id AS eid
		,emp_name
		,email
		,college_id
		,cdept_id
FROM eds_designation
JOIN eds_employee
ON  eds_designation.id=eds_employee.desig_id)
AS eds_view_q4_emp_des

INNER JOIN 
(SELECT * FROM 
(SELECT id AS clg_id
				,clg_name
				,university_name
FROM eds_university 
JOIN eds_college
ON eds_college.univ_code = eds_university.univ_code) 
AS eds_view_Q4_dep_clg 

INNER JOIN 

(SELECT college_id
		,cdept_id
		,dept_name
FROM eds_college_department
JOIN eds_department
ON eds_College_Department.udept_code = eds_department.dept_code)
AS eds_view_q4_clgdep

ON eds_view_q4_clgdep.college_id = eds_view_Q4_dep_clg.clg_id)
AS eds_view_q4_clgdep_dep_clg


ON eds_view_q4_clgdep_dep_clg.college_id = eds_view_q4_emp_des.college_id
ORDER BY rank,college_name;
