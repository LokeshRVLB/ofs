SELECT stu_name AS studnet_name
		,grade
		,credits
		,semester
		,SUM(credits/2) AS GPA
		,clg_name AS college_name
		,university_name
FROM 

(SELECT id AS sid
		,roll_no
		,stu_name
		,college_id
		,semester
		,grade
		,credits
FROM eds_semesters_result
JOIN eds_student
ON eds_semesters_result.stu_id = eds_student.id)
AS eds_View_q6_result_studnet

JOIN 

(SELECT id AS clg_id
				,clg_name
				,university_name
FROM eds_university 
JOIN eds_college
ON eds_college.univ_code=eds_university.univ_code) 
AS eds_view_q5_dep_clg

ON eds_View_q6_result_studnet.college_id=eds_view_q5_dep_clg.clg_id
GROUP BY stu_name,semester,college_name
LIMIT 10
OFFSET 0;

