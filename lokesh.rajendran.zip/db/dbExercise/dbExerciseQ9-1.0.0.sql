SELECT  semester
		 ,amount AS amount_collected
		 ,uncollected_amount
		 ,paid_year
		 ,paid_status
		 ,clg_name
		 ,university_name 
FROM (SELECT eds_semester_fee_clone.cdept_id
		 ,college_id
		 ,semester
		 ,SUM(amount) AS amount
		 ,((SELECT SUM(amount) 
		  FROM eds_semester_fee AS eds_Semester_fee_second 
		  WHERE eds_Semester_fee_second.cdept_id=eds_semester_fee_clone.cdept_id AND
		  eds_Semester_fee_second.semester=eds_semester_fee_clone.semester
		  AND eds_semester_fee_second.paid_Status= "UNPAID"
		  ) - eds_semester_fee_clone.amount) AS uncollected_amount
		 ,paid_year
		 ,paid_Status 
FROM eds_semester_fee AS eds_semester_fee_clone 
JOIN eds_college_department 
ON  eds_semester_fee_clone.cdept_id=eds_college_department.cdept_id
WHERE eds_semester_fee_clone.paid_status = "PAID" AND eds_semester_fee_clone.paid_year=2018
GROUP BY eds_semester_fee_clone.cdept_id,eds_semester_fee_clone.semester)
AS eds_view_q9_sem_clgdep 

JOIN (SELECT id AS clg_id
				,clg_name
				,university_name
FROM eds_university 
JOIN eds_college
ON eds_college.univ_code=eds_university.univ_code)
AS eds_view_q9_clg_univ

ON eds_view_q9_sem_clgdep.cdept_id = eds_view_q9_clg_univ.clg_id
ORDER BY clg_name,semester;


--b
SELECT  semester
		 ,SUM(amount) AS amount
		 ,paid_year
		 ,paid_status
		 ,clg_name
		 ,university_name 
FROM (SELECT eds_semester_fee_clone.cdept_id
		 ,college_id
		 ,semester
		 ,SUM(amount) AS amount
		 ,((SELECT SUM(amount) 
		  FROM eds_semester_fee AS eds_Semester_fee_second 
		  WHERE eds_Semester_fee_second.cdept_id=eds_semester_fee_clone.cdept_id AND
		  eds_Semester_fee_second.semester=eds_semester_fee_clone.semester
		  AND eds_semester_fee_second.paid_Status= "UNPAID"
		  ) - eds_semester_fee_clone.amount) AS uncollected_amount
		 ,paid_year
		 ,paid_Status 
FROM eds_semester_fee AS eds_semester_fee_clone 
JOIN eds_college_department 
ON  eds_semester_fee_clone.cdept_id=eds_college_department.cdept_id
WHERE eds_semester_fee_clone.paid_status = "PAID" AND eds_semester_fee_clone.paid_year=2018
GROUP BY eds_semester_fee_clone.cdept_id,eds_semester_fee_clone.semester)
AS eds_view_q9_sem_clgdep
JOIN eds_view_q9_clg_univ
ON eds_view_q9_sem_clgdep.cdept_id = eds_view_q9_clg_univ.clg_id
WHERE paid_status = "PAID"
GROUP BY university_name
ORDER BY clg_name,semester;

