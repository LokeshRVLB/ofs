SELECT  id AS syllabus_id
		 ,eds_vacancy.cdept_id AS college_department_id
		 ,syllabus_code
		 ,syllabus_name
		 ,clg_name
		 ,dept_name
		 ,university_name			
FROM 

(SELECT * FROM eds_profesor_syllabus 
RIGHT JOIN eds_syllabus
ON eds_profesor_syllabus.syllabus_id = eds_syllabus.id
WHERE eds_profesor_syllabus.emp_id IS NULL) 
AS  eds_vacancy

JOIN 

(SELECT * FROM 

(SELECT college_id
		,cdept_id
		,dept_name
FROM eds_college_department
INNER JOIN eds_department
ON eds_College_Department.udept_code=eds_department.dept_code)
AS eds_view_clgdep

JOIN 

(SELECT id AS clg_id
				,clg_name
				,university_name
FROM eds_university 
INNER JOIN eds_college
ON eds_college.univ_code=eds_university.univ_code)
AS eds_view_dep_clg

ON eds_view_clgdep.college_id = eds_view_dep_clg.clg_id)
AS eds_clgdep_depclg

ON eds_vacancy.cdept_id=eds_clgdep_depclg.cdept_id;

--HOD and Principal vacancy 

--hod vacany
SELECT clg_name AS college_name
		,dept_name AS department_name
		,university_name
FROM (SELECT * FROM 
(SELECT college_id
		,cdept_id
		,dept_name
FROM eds_college_department
INNER JOIN eds_department
ON eds_College_Department.udept_code=eds_department.dept_code)
AS eds_view_clgdep
 
INNER JOIN 
(SELECT id AS clg_id
				,clg_name
				,university_name
FROM eds_university 
INNER JOIN eds_college
ON eds_college.univ_code=eds_university.univ_code)
AS eds_view_dep_clg
ON eds_view_clgdep.college_id = eds_view_dep_clg.clg_id)
AS eds_clgdep_depclg
WHERE cdept_id IN (SELECT cdept_id FROM eds_college_department WHERE cdept_id NOT IN(SELECT cdept_id FROM eds_employee WHERE desig_id=1));



--principal vacacny
SELECT DISTINCT clg_name AS college_name
				,university_name
FROM (SELECT * FROM 
(SELECT college_id
		,cdept_id
		,dept_name
FROM eds_college_department
INNER JOIN eds_department
ON eds_College_Department.udept_code=eds_department.dept_code)
AS eds_view_clgdep

JOIN 
(SELECT id AS clg_id
				,clg_name
				,university_name
FROM eds_university 
INNER JOIN eds_college
ON eds_college.univ_code=eds_university.univ_code)
AS eds_view_dep_clg

ON eds_view_clgdep.college_id = eds_view_dep_clg.clg_id)
AS eds_clgdep_depclg
WHERE college_id NOT IN  (SELECT college_id FROM eds_employee WHERE desig_id=4);
