UPDATE eds_semester_fee 
SET paid_status = "PAID",
    paid_year = now()
WHERE stu_id = ( SELECT id FROM eds_student WHERE roll_no = "1475101");

UPDATE eds_semester_fee 
SET paid_status = "PAID",
    paid_year = now()
WHERE stu_id IN ( SELECT id FROM eds_student WHERE roll_no IN ("1575101","1575102","1575103"));


