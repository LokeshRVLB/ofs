CREATE VIEW eds_view_q10_dep_clg AS
SELECT id AS clg_id,clg_name,university_name
FROM eds_university 
JOIN eds_college
ON eds_college.univ_code=eds_university.univ_code;


CREATE VIEW eds_View_q10_result_studnet AS
SELECT id AS sid
		,roll_no
		,stu_name
		,college_id
		,semester
		,grade
		,credits
FROM eds_semesters_result
JOIN eds_student
ON eds_semesters_result.stu_id = eds_student.id;


CREATE VIEW eds_gpa_q10 AS
SELECT stu_name AS studnet_name
		,grade
		,credits
		,semester
		,SUM(credits/2) AS GPA
		,clg_name AS college_name
		,university_name
FROM eds_View_q6_result_studnet
JOIN eds_view_q5_dep_clg 
ON eds_View_q6_result_studnet.college_id=eds_view_q5_dep_clg.clg_id
GROUP BY stu_name,semester,college_name;


SELECT * FROM eds_gpa_q10 
WHERE (GPA>8 OR GPA<5) AND semester=1  
ORDER BY GPA ;