SELECT clg_code
		,clg_name
		,university_name
		,city
		,state
		,year_opened
		,dept_name
		,emp_name AS HOD_name 
FROM 
(SELECT college_id
		,dept_name
		,cdept_id 
FROM eds_college_department 
INNER JOIN eds_department ON 
eds_college_department.udept_code = eds_department.dept_code
WHERE dept_code LIKE 'CS%' OR dept_code LIKE 'IT%') 
AS eds_dep_clgdep

INNER JOIN 

(SELECT clg_name
		 ,clg_code
		 ,city
		 ,state
		 ,year_opened
		 ,id
		 ,university_name 
FROM 	eds_college 
JOIN eds_university
ON eds_university.univ_code=eds_college.univ_code
WHERE eds_College.id IN (SELECT college_id FROM (SELECT college_id
		,dept_name
		,cdept_id 
FROM eds_college_department 
INNER JOIN eds_department ON 
eds_college_department.udept_code = eds_department.dept_code
WHERE dept_code LIKE 'CS%' OR dept_code LIKE 'IT%') 
AS eds_dep_clgdep)) 
AS eds_clg_univ 

ON eds_dep_clgdep.college_id=eds_clg_univ.id
INNER JOIN 

(SELECT emp_name
		,college_id 
FROM eds_employee 
INNER JOIN eds_designation
ON eds_designation.id = eds_employee.desig_id
WHERE eds_designation.rank='b' and cdept_id IN (SELECT cdept_id FROM eds_dep_clgdep)) 
AS eds_emp_des

ON eds_dep_clgdep.college_id = eds_emp_des.college_id;
