DROP TABLE sc_orders;
DROP TABLE sc_products;
DROP TABLE sc_vendors;
DROP TABLE sc_customers;
DROP TABLE sc_student;
DROP TABLE sc_teacher;
DROP TABLE sc_test_entity;
