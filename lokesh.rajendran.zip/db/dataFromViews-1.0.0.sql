SELECT * FROM sc_view_checkout;
SELECT * FROM sc_view_inner;
SELECT * FROM sc_view_left;
SELECT * FROM sc_view_outer;
SELECT * FROM sc_view_cross;
SELECT * FROM sc_view_cross_two;
SELECT * FROM sc_view_right;
SELECT * FROM sc_view_join;