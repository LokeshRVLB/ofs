DROP VIEW sc_view_checkout;
DROP VIEW sc_view_cross;
DROP VIEW sc_view_cross_two;
DROP VIEW sc_view_inner;
DROP VIEW sc_view_join;
DROP VIEW sc_view_left;
DROP VIEW sc_view_outer;
DROP VIEW sc_view_right;
