/* orders table holds all the details of the order made by teh customer */
	CREATE TABLE sc_orders ( id 			  INT AUTO_INCREMENT
									,date_time    DATETIME
									,quantity	  INT
									,product_id   INT 
									,customer_id  INT
									,PRIMARY KEY (id) );
									
	INSERT INTO sc_orders VALUES (1,NOW(),4,1,1)
									  ,(2,NOW(),2,1,2)
									  ,(3,NOW(),1,2,1)
							   	  ,(4,NOW(),3,1,3)
						           ,(5,NOW(),2,3,4)
									  ,(6,NOW(),3,1,1)
									  ,(7,NOW(),2,2,2)
								     ,(8,NOW(),1,1,1);

/* Vendor table holds the details of the product vendors */
CREATE TABLE sc_vendors(id INT AUTO_INCREMENT
								,brand VARCHAR(20)	
								,vendor_address VARCHAR(30)
								,PRIMARY KEY(id));
								
INSERT INTO sc_vendors VALUES
 (1,"Apple","20,Khan,Banglore - 400011")
,(2,"Dell","13,Himalayan,Mumbai - 300181")
,(3,"Lenovo","23,North,Chennai- -600011")
,(4,"Titan","21,India, Hyderabad - 500127");

/* Products table holds the details of the products  sold on the site and vendor_id field of products table acts as foreign key for vendor table */
CREATE TABLE sc_products(id INT AUTO_INCREMENT
							,product VARCHAR(20) 
							,cost		FLOAT
							,vendor_id INT
							,key vendor_table_id (`vendor_id`) 
							,CONSTRAINT product_vendor_fk FOREIGN KEY (vendor_id) REFERENCES `sc_vendors` (id) ON DELETE NO ACTION ON UPDATE NO ACTION
							,PRIMARY KEY(id));

INSERT INTO sc_products VALUES
(1,"Titan Watch",800,4)
,(2,"Apple iphone X",102000,1)
,(3,"Lenovo yoga Laptop",45400,3)
,(4,"Dell PC",23000,2)
,(5,"Apple Ipad",76000,4)
,(6,"Lenovo 30-50",40000,3)
,(7,"Lenovo Vibe mobile",10000,3)
,(8,"Dell Laptop",50000,2);

/* Customers table is created to store the Customers detials */
CREATE TABLE sc_customers(id INT AUTO_INCREMENT
							,customer VARCHAR(20)
							,email_id	VARCHAR(25)
							,phone  VARCHAR(10)
							,address VARCHAR(50)
							,PRIMARY KEY (id) );

INSERT INTO sc_customers (customer,email_id,phone,address) VALUES
("Lokesh","lokesh@gmail.com","9160164239","20-313,Hassan,Chittoor,Andhra Pradesh -517001")
,("Chandu","chandu@gmail.com","9821293343","12-232,North, chennai- 600011")
,("Vijaya","vijaya@gmail.com","9019182373","20,Himalayan,Mumbai-400128")
,("Boovan" ,"Boovan@gmail.com","783838034","20,Indian corner,Hyderabad-510002");

/* customer_id and vendor_id of orders table is made as foreign key for customer and products table */
ALTER TABLE sc_orders 
ADD FOREIGN KEY (product_id) 
REFERENCES sc_products (id),							
ADD FOREIGN KEY (customer_id) 
REFERENCES sc_customers (id);							
						
/* checkout view is created joining orders, customers , products and vendors table. This view is used in billing, transaction and shipping process */
CREATE VIEW sc_view_checkout AS
SELECT sc_orders.date_time
		, sc_products.id AS product_id
		, sc_products.product
		, sc_products.cost
		,SUM(quantity) as total_quantity
		,SUM(quantity*cost) as total_cost
		, sc_customers.id AS customer_id
		, sc_customers.customer
		, sc_customers.email_id AS customer_email_id
		, sc_customers.phone AS customer_phone
		, sc_customers.address AS customer_address
		, sc_vendors.id AS vendor_id 
		, sc_vendors.brand
		, sc_vendors.vendor_address
FROM sc_orders INNER
JOIN sc_customers ON sc_orders.customer_id = sc_customers.id INNER
JOIN sc_products ON sc_orders.product_id = sc_products.id INNER
JOIN sc_vendors ON sc_products.vendor_id = sc_vendors.id
GROUP BY product,customer_address;

SELECT * FROM 	sc_view_checkout;


DROP VIEW sc_view_checkout;
/* noof_items_in_stock field is added to products table which keeps track of the available count on the product */
ALTER TABLE sc_products ADD noof_items_in_stock INT;
EXPLAIN sc_products;
INSERT INTO sc_products (noof_items_in_stock) VALUES (20);
SELECT * FROM sc_products;
UPDATE sc_products 
SET noof_items_in_stock = 20 
WHERE id > 0;

/* code demonstrating ALTER commands*/
CREATE TABLE sc_test_entity( id INT
									, test_name VARCHAR(40)
									, field_to_be_dropped VARCHAR(40)
									, field_to_be_changed VARCHAR(20)); 
ALTER TABLE sc_test_entity ADD PRIMARY KEY(id);
ALTER TABLE sc_test_entity	CHANGE field_to_be_changed  field_changed INT ;
EXPLAIN sc_test_entity;
ALTER TABLE sc_test_entity DROP COLUMN field_to_be_dropped;

DROP TABLE sc_test_entity;


/* code demonstraiting Joins in db */
CREATE TABLE sc_teacher( id INT
								, teacher_name VARCHAR(20)
								, PRIMARY KEY(id));

INSERT INTO sc_teacher (id , teacher_name) VALUES
							  (1,"Yamini")
							 ,(2,"Chandu")
							 ,(3,"Kokila");

CREATE TABLE sc_student( id INT
								, student_name VARCHAR(20)
								, teacher_id INT
								, PRIMARY KEY(id));

INSERT INTO sc_student (id , student_name, teacher_id) VALUES
							  (1,"Balaji",1)
							 ,(2,"Chandu",1)
							 ,(3,"Kokila",3)
							 ,(4,"Chandu",6)
							 ,(5,"Kokila",8);

SELECT * FROM sc_student;							 
SELECT * FROM sc_teacher;
SELECT * FROM sc_student,sc_teacher;		/*See correlation*/
CREATE VIEW sc_view_inner AS SELECT teacher_name,student_name FROM sc_student
INNER JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
SELECT * FROM sc_view_inner;

CREATE VIEW sc_view_left AS SELECT teacher_name,student_name FROM sc_student
LEFT JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
SELECT * FROM sc_view_left;

CREATE VIEW sc_view_right AS SELECT teacher_name,student_name FROM sc_student
RIGHT JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
SELECT * FROM sc_view_right;

CREATE VIEW sc_view_cross AS SELECT teacher_name,student_name FROM sc_student
CROSS JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
SELECT * FROM sc_view_cross;

CREATE VIEW sc_view_cross_two AS SELECT teacher_name,student_name FROM sc_teacher
CROSS JOIN sc_student ON sc_student.teacher_id = sc_teacher.id;
SELECT * FROM sc_view_cross_two;

CREATE VIEW sc_view_join AS SELECT teacher_name,student_name FROM sc_student
JOIN sc_teacher ON sc_student.teacher_id = sc_teacher.id;
SELECT * FROM sc_view_join;

/* Implementing outer join with UNION */
CREATE VIEW sc_view_outer AS 
SELECT * FROM sc_view_left UNION SELECT * FROM sc_view_right;
SELECT * FROM sc_view_outer;


/*Demonstrating Like and Regex in SQL */
SELECT * FROM sc_teacher WHERE teacher_name LIKE "K%_i%";

/* Demonstrating GROUP BY,COUNT,HAVING in sql */
SELECT COUNT(id) AS noof_students_with_same_name,student_name FROM sc_student
GROUP BY student_name
HAVING noof_students_with_same_name>1;

