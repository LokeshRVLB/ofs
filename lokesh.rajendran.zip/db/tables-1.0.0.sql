/* orders table holds all the details of the order made by teh customer */
CREATE TABLE sc_orders ( id 			  INT AUTO_INCREMENT
									,date_time    DATETIME
									,quantity	  INT
									,product_id   INT 
									,customer_id  INT
									,PRIMARY KEY (id) );
									

/* Vendor table holds the details of the product vendors */
CREATE TABLE sc_vendors(id INT AUTO_INCREMENT
								,brand VARCHAR(20)	
								,vendor_address VARCHAR(30)
								,PRIMARY KEY(id));
								

/* Products table holds the details of the products  sold on the site and
 vendor_id field of products table acts as foreign key for vendor table */
CREATE TABLE sc_products(id INT AUTO_INCREMENT
							,product VARCHAR(20) 
							,cost		FLOAT
							,vendor_id INT
							,key vendor_table_id (`vendor_id`) 
							,CONSTRAINT product_vendor_fk FOREIGN KEY (vendor_id) 
							 REFERENCES `sc_vendors` (id) 
							 ON DELETE NO ACTION ON UPDATE NO ACTION
							,PRIMARY KEY(id));


/* Customers table is created to store the Customers detials */
CREATE TABLE sc_customers(id INT AUTO_INCREMENT
							,customer VARCHAR(20)
							,email_id	VARCHAR(25)
							,phone  VARCHAR(10)
							,address VARCHAR(50)
							,PRIMARY KEY (id) );


							
						
/* test table created to demonstrate alter commnads*/
CREATE TABLE sc_test_entity( id INT
									, test_name VARCHAR(40)
									, field_to_be_dropped VARCHAR(40)
									, field_to_be_changed VARCHAR(20)); 
									
									
/*tables created to display joins in db*/
CREATE TABLE sc_teacher( id INT
								, teacher_name VARCHAR(20)
								, PRIMARY KEY(id));			
								
CREATE TABLE sc_student( id INT
								, student_name VARCHAR(20)
								, teacher_id INT
								, PRIMARY KEY(id));														