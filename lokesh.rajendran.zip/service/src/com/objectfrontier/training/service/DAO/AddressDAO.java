package com.objectfrontier.training.service.DAO;

import java.util.List;

import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public interface AddressDAO {

    List<Address> readAll();
    Address read(long id);
    Address update(Address address);
    Address delete(Address address);
    Address insert(Address address);
    <V> boolean isPresent(String field, V value);
    <V> boolean isPresent(String field, V value, String neglectRowWithField, String neglectRowWithValue);
}
