package com.objectfrontier.training.service.helper;

import java.util.ArrayDeque;
import java.util.Arrays;
import java.util.Enumeration;
import java.util.stream.Collectors;

public class AppException extends RuntimeException implements Enumeration<Error> {

    protected Error error;
    protected int errorCode;
    protected ArrayDeque<Error> associatedErrors = new ArrayDeque<>();

    public AppException(Error[] errors, Error error) {
        this(error); 
        associatedErrors.addAll(Arrays.asList(errors));
    }

    public AppException() {
        super();
    }

    public AppException(Error error) {
        super(error.getMessage());
        this.error = error;
        this.errorCode = error.getErrorCode();
    }

    public AppException(Error error, Exception cause) {
        super(error.getMessage(), cause);
        this.error = error;
        this.errorCode = error.getErrorCode();
    }
    
    public Error[] getAssociatedErrors() {
        return associatedErrors.toArray(new Error[associatedErrors.size()]);
    }

    public void setErrorCodes(Error[] errors) {
        this. associatedErrors.addAll(Arrays.asList(errors));
    }

    public int getErrorCode() {
        return errorCode;
    }

    public Error getError() {
        return error;
    }

    @Override
    public boolean hasMoreElements() {
        return (associatedErrors.size() > 0 ? true : false);
    }

    @Override
    public Error nextElement() {
        return associatedErrors.pop();
    }
}
