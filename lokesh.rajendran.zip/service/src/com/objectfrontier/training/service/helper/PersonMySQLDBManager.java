package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.service.DAO.PersonDAO;
import com.objectfrontier.training.service.entity.DTO.PersonDTO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public class PersonMySQLDBManager implements PersonDAO {

    ConnectionManager connectionManager;

    public PersonMySQLDBManager(ConnectionManager connectionManager) {
        this.connectionManager = connectionManager;
    }

    @Override
    public List<Person> readAll(){
        String query = new StringBuilder().append("SELECT scv_person.id")
                                          .append("      ,scv_person.first_name")
                                          .append("      ,scv_person.last_name")
                                          .append("      ,scv_person.email")
                                          .append("      ,scv_person.dob")
                                          .append("      ,scv_person.address_id ")
                                          .append("FROM scv_person").toString();
        ResultSetProcessor<List<Person>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Person> persons = new ArrayList<>(resultSet.getFetchSize());
            while (resultSet.next()) {
                Person person = new Person();
                Address address;
                person.setId(resultSet.getLong(1));
                person.setFirstName(resultSet.getString(2));
                person.setLastName(resultSet.getString(3));
                person.setEmail(resultSet.getString(4));
                person.setBirthDate(resultSet.getDate(5).toLocalDate());
                address = new Address();
                address.setId(resultSet.getLong(6));
                person.setAddress(address);
                persons.add(person);
            }
            return persons;
        };
        try {
            return readAll.applyOn(query, null, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

	@Override
	public Person read(long id) {
        String query = new StringBuilder().append("SELECT scv_person.id")
                                          .append("      ,scv_person.first_name")
                                          .append("      ,scv_person.last_name")
                                          .append("      ,scv_person.email")
                                          .append("      ,scv_person.dob")
                                          .append("      ,scv_person.address_id ")
                                          .append("FROM scv_person ")
                                          .append("WHERE scv_person.id = ?").toString();
        ResultSetProcessor<Person, ResultSet> read = (resultSet) -> {
            Person person = new Person();
            Address address;
            while (resultSet.next()) {
                person.setId(resultSet.getLong(1));
                person.setFirstName(resultSet.getString(2));
                person.setLastName(resultSet.getString(3));
                person.setEmail(resultSet.getString(4));
                person.setBirthDate(resultSet.getDate(5).toLocalDate());
                address = new Address();
                address.setId(resultSet.getLong(6));
                person.setAddress(address);
            }
            return person;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, id);
            return read.applyOn(query, parameters, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Person read(long id, boolean includeAddress) {

        if (!includeAddress) {
            String query = new StringBuilder().append("SELECT scv_person.id")
                                              .append("      ,scv_person.first_name")
                                              .append("      ,scv_person.last_name")
                                              .append("      ,scv_person.email")
                                              .append("      ,scv_person.dob ")
                                              .append("FROM scv_person WHERE scv_person.id = ?").toString();

            ResultSetProcessor<Person, ResultSet> read = (resultSet) -> {
                Person person = new Person();
                while (resultSet.next()) {
                    person.setId(resultSet.getLong(1));
                    person.setFirstName(resultSet.getString(2));
                    person.setLastName(resultSet.getString(3));
                    person.setEmail(resultSet.getString(4));
                    person.setBirthDate(resultSet.getDate(5).toLocalDate());
                }
                return person;
            };
            try {
                List<Object> parameters = new ArrayList<>();
                parameters.add(0, id);
                return read.applyOn(query, parameters, connectionManager, false, 0);
            } catch (SQLException e) {
                throw new AppException(Error.SQL_READ_ERROR, e);
            }
        }

        return read(id);
    }

    @Override
    public Person update(Person person) {
        String query = new StringBuilder().append("UPDATE scv_person ")
                                          .append("SET scv_person.first_name = ?")
                                          .append("   ,scv_person.last_name = ?")
                                          .append("   ,scv_person.dob = ? ")
                                          .append("WHERE scv_person.id = ?;").toString();
        ResultSetProcessor<Integer, Integer> update = (updatedCount) -> {
            return updatedCount;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, person.getFirstName());
            parameters.add(1, person.getLastName());
            parameters.add(2, person.getBirthDate());
            parameters.add(3, person.getId());
            update.applyOn(query, parameters, connectionManager, true, 0);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_UPDATE_ERROR, e);
        }
    }

    @Override
    public Person delete(Person person) {
        String query = new StringBuilder().append("DELETE FROM scv_person ")
                                          .append("WHERE scv_person.id = ?").toString();
        ResultSetProcessor<Integer, Integer> delete = (deletedCount) -> {
            return deletedCount;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, person.getId());
            int deletedCount = delete.applyOn(query, parameters, connectionManager, true, 0);
            System.out.println(deletedCount);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_DELETE_ERROR, e);
        }
    }

    @Override
    public Person insert(Person person) {

        String insertPersonQuery = new StringBuilder().append("INSERT INTO scv_person ( scv_person.first_name")
                                                      .append("                    ,scv_person.last_name")
                                                      .append("                    ,scv_person.email")
                                                      .append("                    ,scv_person.dob")
                                                      .append("                    ,scv_person.address_id) ")
                                                      .append("VALUES (?, ?, ?, ?, ?)").toString();
        ResultSetProcessor<Long, ResultSet> insertPerson = (resultSet) -> {
            resultSet.next();
            return resultSet.getLong(1);
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, person.getFirstName());
            parameters.add(1, person.getLastName());
            parameters.add(2, person.getEmail());
            parameters.add(3, java.sql.Date.valueOf(person.getBirthDate()));
            parameters.add(4, person.getAddress().getId());

            long personId = insertPerson.applyOn(insertPersonQuery, parameters, connectionManager, true,
                    Statement.RETURN_GENERATED_KEYS);
            person.setId(personId);
            return person;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_INSERT_ERROR, e);
        }
    }

    @Override
    public <T> boolean isPresent(String field, T value) {
        String getFieldQuery = MessageFormat.format("SELECT {0} FROM scv_person", field);
        boolean result = true;
        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (value.equals(resultSet.getObject(1))) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };
        try {
            result = isPresent.applyOn(getFieldQuery, null, connectionManager, false, 0).booleanValue();
        } catch (SQLException e) {
            new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

    @Override
    public <V> boolean isPresent(String field, V value, String neglectRowWithField, String neglectRowWithValue) {
        String getFieldQuery = MessageFormat.format("SELECT {0} FROM scv_person WHERE {1} != {2}",
                                                     field,
                                                     neglectRowWithField,
                                                     neglectRowWithValue);
        boolean result = true;
        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (value.equals(resultSet.getObject(1))) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };
        try {
            result = isPresent.applyOn(getFieldQuery, null, connectionManager, false, 0).booleanValue();
        } catch (SQLException e) {
            new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

}
