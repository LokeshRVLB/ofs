package com.objectfrontier.training.service.test;

import java.io.IOException;
import java.sql.SQLException;
import java.text.MessageFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.DTO.PersonDTO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.Error;

public class PersonServiceTest {

    PersonService personService;
    ConnectionManager connectionManager;
    @BeforeClass
    private void initClass() throws IOException, SQLException {

        connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                                                  "mysqlCredentials.txt");
        connectionManager.getConnection();
        personService = new PersonService(connectionManager);
    }

    @Test (dataProvider = "insertTest_positiveDP")
    private void insertTest_positive(Person person) throws SQLException {

        Person actualResult = null;
        Person expectedResult = person;
        try {
            connectionManager.autoCommit(false);
            actualResult = personService.insert(person);
            connectionManager.commit();
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            connectionManager.rollBack();
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, person));
        }
    }

    @DataProvider
    private Object[][] insertTest_positiveDP() {
        Address address = new Address("Boovan street", "Banglore", 600123);
        Person person = new Person("Lokesh3",
                                   "Balaji3",
                                   "lokeshbalaji683@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(4);
        return new Object[][] {
            {person}
        };
    }

    @Test (dataProvider = "insertTest_negativeDP")
    private void insertTest_negative(Person person, AppException expectedResult) throws SQLException {
        try {
            connectionManager.autoCommit(false);
            personService.insert(person);
            connectionManager.commit();
            Assert.fail(MessageFormat.format("Expected an Exception for {0}", person));
        } catch (AppException e) {
            connectionManager.rollBack();
            Error[] caught = e.getAssociatedErrors();
            Error[] expected = expectedResult.getAssociatedErrors();
            for (int i = 0; i < caught.length; i++) {
                Assert.assertEquals(caught[i].getErrorCode(),
                       expected[i].getErrorCode());
            }
        }
    }

    @DataProvider
    private Object[][] insertTest_negativeDP() {
        Address address = new Address("Boovan street", "Banglore", 600123);
        Person person = new Person("Lokesh3",
                                   "Lokesh3",
                                   "lokeshbalaji68@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        Error[] errorsOne = { Error.DATA_FIRST_LAST_NAME_DUPLICATION_ERROR, Error.EMAIL_DUPLICATION_ERROR};
        return new Object[][] {
            {person, new AppException(errorsOne, Error.DATA_VALIDATION_ERROR)}
        };
    }

    @Test (dataProvider = "readTest_positiveDP")
    private void readTest_positive(Person expectedResult, boolean includeAddress, int id) {
        Person actualResult;
        try {
            actualResult = personService.read(id, includeAddress);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, id));
        }
    }

    @DataProvider
    private Object[][] readTest_positiveDP() {
        Address address = new Address("Ragava street", "chennai", 600113);
        address.setId(2);
        Person person = new Person("Lokesh2",
                                   "Balaji2",
                                   "lokeshbalaji682@gmail.com",
                                   address,
                                   LocalDate.parse("06-08-1996",DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(2);
        return new Object[][] {
            {person, true, 2}
        };
    }

    @Test (dataProvider = "readTest_negativeDP")
    private void readTest_negative(int id, boolean includeAddress, AppException expectedResult) {
        try {
            personService.read(id, includeAddress);
            Assert.fail(MessageFormat.format("Expected an Exception for {0}", id));
        } catch (AppException e) {
            Assert.assertEquals(e.getMessage(),
                                expectedResult.getMessage());
        }
    }

    @DataProvider
    private Object[][] readTest_negativeDP() {
        return new Object[][] {
            {10, true, new AppException(Error.INVALID_PERSON_REQUEST)}
        };
    }

    @Test (dataProvider = "updateTest_positiveDP")
    private void updateTest_postive(Person person) {
        Person expectedResult = person;
        try {
            Person actualResult = personService.update(person);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, person));
        }
    }

    @DataProvider
    private Object[][] updateTest_positiveDP() {
        Address address = new Address("Ragava street", "chennai", 600113);
        address.setId(1);
        Person person = new Person("LokeshUpdated",
                                   "BalajiUpdated",
                                   "lokeshbalaji68@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(1);
        return new Object[][] {
            {person}
        };
    }

    @Test (dataProvider = "updateTest_negativeDP")
    private void updateTest_negative(Person person, AppException expectedException) {
        try {
            personService.update(person);
            Assert.fail("Expected an AppException");
        } catch (AppException e) {
            if (e.getAssociatedErrors() != null) {
                Error[] caught = e.getAssociatedErrors();
                Error[] expected = expectedException.getAssociatedErrors();
                for (int i = 0; i < caught.length; i++) {
                    Assert.assertEquals(caught[i].getErrorCode(),
                            expected[i].getErrorCode());
                }
            }
        }
    }

    @DataProvider
    private Object[][] updateTest_negativeDP() {
        Address address = new Address("Boovan street", "Banglore", 600123);
        address.setId(9);
        Person person = new Person("Lokesh3",
                                   "Lokesh3",
                                   "lokeshbalaji68@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(8);
        Error[] errorsOne = { Error.INVALID_ADDRESS_REQUEST,
                              Error.DATA_FIRST_LAST_NAME_DUPLICATION_ERROR,
                              Error.EMAIL_DUPLICATION_ERROR,
                              Error.INVALID_PERSON_REQUEST};
        return new Object[][] {
            {person, new AppException(errorsOne, Error.DATA_VALIDATION_ERROR)}
        };
    }

    @Test (dataProvider = "deleteTest_positiveDP")
    private void deleteTest_positive(Person person) {
        Person expectedResult = person;
        try {
            Person actualResult = personService.delete(person);
            Assert.assertEquals(actualResult.toString(), expectedResult.toString());
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e, person));
        }
    }

    @DataProvider
    private Object[][] deleteTest_positiveDP() {
        Address address = new Address("Rajendran street", "chennai", 600114);
        address.setId(3);
        Person person = new Person("Lokesh4",
                                   "Balaji4",
                                   "lokeshbalaji684@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(3);
        return new Object[][] {
            {person}
        };
    }

    @Test (dataProvider = "deleteTest_negativeDP")
    private void deleteTest_negative(Person person, AppException expectedException) {
        try {
            personService.delete(person);
            Assert.fail("Expected an AppException");
        } catch (AppException e) {
            Assert.assertEquals(e.getErrorCode(), expectedException.getErrorCode());
        }
    }

    @DataProvider
    private Object[][] deleteTest_negativeDP() {
        Address address = new Address("Boovan street", "Banglore", 600123);
        Person person = new Person("Lokesh4",
                                   "Lokesh4",
                                   "lokeshbalaji684@gmail.com",
                                   address,
                                   LocalDate.parse("09-08-1996", DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        person.setId(8);
        return new Object[][] {
            {person, new AppException(Error.INVALID_PERSON_REQUEST)}
        };
    }

    @AfterClass
    private void afterClass() throws SQLException {
        connectionManager.close();
    }
}
