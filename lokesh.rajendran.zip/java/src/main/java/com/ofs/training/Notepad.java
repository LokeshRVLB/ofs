package com.ofs.training;

import java.io.IOException;
import java.io.File;

// class Notepad {
public class Notepad {

    // void open(String absoluteFilePath) {
    public void open(String absoluteFilePath) {

        // ....
        Runtime runtime =  Runtime.getRuntime();
        try {
            Process process = runtime.exec("D:\\tools\\Notepad++\\notepad++.exe " + absoluteFilePath);
        } catch (IOException e) {
            System.out.println("there is something wrong with Notepad++");
        }
    }
}