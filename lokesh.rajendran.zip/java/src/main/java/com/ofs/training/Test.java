package com.ofs.training;

public class Test {

    public static void main(String[] args) {

        Test obj = new Test();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

    }

    private static void log(Throwable t) {

        t.printStackTrace(System.err);
    }

    private static void log(String format, String... vals) {

        System.out.format(format, vals);
    }
}
