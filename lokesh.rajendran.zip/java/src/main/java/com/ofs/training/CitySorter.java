package com.ofs.training;

import java.util.Arrays;

/**
 * @author Lokesh.
 * @since Aug 31, 2018
 */
public class CitySorter {

    public static void main(String[] args) {

        CitySorter obj = new CitySorter();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log("%s", t.getMessage());
        }
    }

    private void run(String[] args) {

        String[] cities = { "Madurai",
                            "Thanjavur",
                            "TRICHY",
                            "Karur",
                            "Erode",
                            "trichy",
                            "Salem" };

        sortIgnoringCases(cities);
        log("%s%n", "Sorted array");
        displayCities(cities);

        covertEvenIndexedToUpper(cities);
        log("%s%n", "after coverting even indexed elements to upper case");
        displayCities(cities);
    }

    private void displayCities(String[] cities) {
        for (String city : cities) {
            log("%s%n", city);
        }
    }

    public void covertEvenIndexedToUpper(String[] cities) {
        for (int index = 0; index < cities.length; index += 2) {
            cities[index] = cities[index].toUpperCase();
        }
    }

    public void sortIgnoringCases(String[] cities) {
        Arrays.sort(cities, String.CASE_INSENSITIVE_ORDER);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}