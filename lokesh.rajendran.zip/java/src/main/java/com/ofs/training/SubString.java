package com.ofs.training;

/**
 * @author Lokesh.
 * @since Sep 3, 2018
 */
public class SubString {

    public static void main(String[] args) {

        SubString obj = new SubString();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {
        String subString;
        String givenString = "Was it a car or a cat I saw?";
        log("Substring is: %s\n", subString = getSubString(givenString, 9, 12));
        log("Substring Length is: %s\n", getSubStringLength(subString));
    }

    public String getSubString(String givenString, int startIndex, int endIndex) {

        if (givenString.length() < startIndex) {
            throw new RuntimeException("start index out of bound exception");
        }

        if (givenString.length() < endIndex) {
            throw new RuntimeException("end index out of bound exception");
        }

        return givenString.substring(startIndex, endIndex);
    }

    public int getSubStringLength(String subString) {
        return subString.length();
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... i) {
        System.out.format(format, i);
    }
}
