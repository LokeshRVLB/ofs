package com.ofs.training;

/**
 * @author Lokesh.
 * @since Aug 31, 2018
 */
public class TypeFinder {

    public static void main(String[] args) {

        TypeFinder obj = new TypeFinder();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log("%s", t.getMessage());
        }
    }

    private void run(String[] args) {
        log("%s\n", getType(100 / 24));
        log("%s\n", getType(100.10 / 10));
        log("%s\n", getType('z' / 2));
        log("%s\n", getType(12.4 % 5.5));
        log("%s\n", getType(100 % 56));
        log("%s", getType(100.0 % 56));
    }

    public String getType(Object i) {

        return i.getClass().getSimpleName();
    }

    private static void log(String format, String... vals) {

        System.out.format(format, vals);
    }
}
