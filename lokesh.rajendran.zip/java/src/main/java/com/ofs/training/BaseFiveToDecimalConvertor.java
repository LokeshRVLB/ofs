package com.ofs.training;

/**
 * @author Lokesh.
 * @since Aug 30, 2018
 */
public class BaseFiveToDecimalConvertor {

    public static void main(String[] args) {

        BaseFiveToDecimalConvertor obj = new BaseFiveToDecimalConvertor();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {
        int baseFiveNumber = 230;
        int decimalNumber = 0;

        for (int positioner = 0; baseFiveNumber != 0; positioner++) {
            decimalNumber += (baseFiveNumber % 10) * Math.pow(5, positioner);
            baseFiveNumber = baseFiveNumber / 10;
        }
        System.out.println("Decimal equivalent is : " + decimalNumber);
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
