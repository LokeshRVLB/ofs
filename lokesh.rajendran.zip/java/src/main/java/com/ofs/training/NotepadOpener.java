package com.ofs.training;

import java.io.File;

public class NotepadOpener {

    // static void execute() {
    public static void main(String[] args) {

        // NotepadOpener notepadOpener = getCurrentClass();
        NotepadOpener notepadOpener = new NotepadOpener();

        // Class currentClass = notepadOpener.getClass();
        Class currentClass = notepadOpener.getClass();

        // File currentSourceFile = currentClass.getSourceFile();
        // String absoluteFilePath = currentSourceFile.getAbsoluteFilePath();
        String absoluteFilePath = currentClass.getProtectionDomain()
                                              .getCodeSource()
                                              .getLocation()
                                              .getFile() + currentClass.getName() + ".java";

        // FileSystem fileSystem = absoluteFilePath.getFileSystem();
        File fileSystem = new File(absoluteFilePath);

        // if (! fileSystem.validateSourceFile(absoluteFilePath)) {
        if (! fileSystem.exists()) {

            // Console console = notepadOpener.getConsole();
            // console.print("Error opening file : No file found");
            System.out.println("Error opening file : No file found in " + absoluteFilePath);

            // return
            return;
        }

        // absoluteFilePath = fileSystem.getAbsolutePathWithoutPartition();
        absoluteFilePath = fileSystem.getAbsolutePath();

        // Notepad notepad = notepadOpener.getNotepadProcess();
        // notepad.open(absolutePath);
        Notepad notepad = new Notepad();
        notepad.open(absoluteFilePath);
    }
}
