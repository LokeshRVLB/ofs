package com.ofs.training;

public class FibanociiPrinter {

//    static void execute() {
    public static void main(String[] args) {

        int limitOfSeries = 10;

        // FibanociiPrinter fibanociiPrinter = getCurrentProgram();
        FibanociiPrinter fibanociiPrinter = new FibanociiPrinter();

        // fibanociiPrinter.printSeriesUsingFor(limitOfSeries);
        fibanociiPrinter.printSeriesUsingFor(limitOfSeries);

        // fibanociiPrinter.printSeriesUsingWhile(limitOfSeries);
        fibanociiPrinter.printSeriesUsingWhile(limitOfSeries);

        // fibanociiPrinter.printSeriesUsingRecursion(limitOfSeries);
        fibanociiPrinter.printSeriesUsingRecursion(limitOfSeries);
    }

    // void printSeriesUsingFor(int limitOfSeries) {
    void printSeriesUsingFor(int limitOfSeries) {

        // ...
        int preceder = 0;
        int succesor = 1;
        System.out.printf("%d\t%d\t", preceder, succesor);
        for (int count = 0; count < limitOfSeries - 2; count++) {
            System.out.print((succesor = preceder + succesor) + "\t");
            preceder = succesor - preceder;
        }
        System.out.println();
    }

    // void printSeriesUsingWhile(int limitOfSeries) {
    void printSeriesUsingWhile(int limitOfSeries) {

        // ...
        int preceder = 0;
        int succesor = 1;
        int localLimit = limitOfSeries;
        System.out.printf("%d\t%d\t", preceder, succesor);
        while (( localLimit - 2 ) > 0) {
            System.out.print((succesor = preceder + succesor) + "\t");
            preceder = succesor - preceder;
            localLimit--;
        }
        System.out.println();

    }

    static int preceder = 0;
    static int succesor = 1;

    // void printSeriesUsingRecursion(int limitOfSeries) {
    void printSeriesUsingRecursion(int limitOfSeries) {

        // ...
        System.out.printf("%d\t%d\t", preceder, succesor);
        fibanocii(new Integer(limitOfSeries - 2));
        preceder = 0;
        succesor = 1;
        System.out.println();

    }

    private void fibanocii(int start) {
        if (start == 1) {
            System.out.print( preceder + succesor );
            return;
        }
        System.out.print((succesor = preceder + succesor) + "\t");
        preceder = succesor - preceder;
        fibanocii(start = start - 1);
    }
}
