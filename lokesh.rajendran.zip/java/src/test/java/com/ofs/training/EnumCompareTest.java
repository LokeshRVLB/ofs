package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.EnumComparator.Places;

/**
 * @author Lokesh.
 * @since Sep 3, 2018
 */
public class EnumCompareTest {

    private EnumComparator enumComparator;
    @BeforeClass
    private void initClass() {

        enumComparator = new EnumComparator();
    }

    @Test(dataProvider = "positiveCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equals_positive(Places placeOne, Places placeTwo, boolean expectedResult) {

        boolean actualResult;
        try {
            actualResult = enumComparator.isInSameLocation_equals(placeOne, placeTwo);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("UnExpected result for "
                        + placeOne
                        + " and "
                        + placeTwo
                        + "Expected result is "
                        + expectedResult
                        + "But actual result is "
                        + ! expectedResult);
        }
    }

    @Test(dataProvider = "positiveCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equalTo_positive(Places placeOne, Places placeTwo, boolean expectedResult) {

        boolean actualResult;
        try {
            actualResult = enumComparator.isInSameLocation_equals(placeOne, placeTwo);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("UnExpected result for "
                        + placeOne
                        + " and "
                        + placeTwo
                        + "Expected result is "
                        + expectedResult
                        + "But actual result is "
                        + ! expectedResult);
        }
    }

    @Test(dataProvider = "negativeCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equals_negative(Places placeOne, Places placeTwo, String expectedResult) {

        try {
            enumComparator.isInSameLocation_equals(placeOne, placeTwo);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expectedResult);
        }
    }

    @Test(dataProvider = "negativeCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equalTo_negative(Places placeOne, Places placeTwo, String expectedResult) {

        try {
            enumComparator.isInSameLocation_equalTo(placeOne, placeTwo);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expectedResult);
        }
    }

    @DataProvider(name = "positiveCase_isInSameLocation_equals_==_Case")
    private Object[][] testIsInSameLocation_equals_positiveDP() {

        return new Object[][] {
            {Places.adayar, Places.adayar, true},
            {Places.selam, Places.adayar, false}
        };

    }

    @DataProvider(name = "negativeCase_isInSameLocation_equals_==_Case")
    private Object[][] testIsInSameLocation_equals_negativeDP() {

        return new Object[][] {
            {null, Places.adayar, "Null value found in given values"},
            {Places.selam, null, "Null value found in given values"},
            {null, null, "Null value found in given values"}
        };

    }

    @AfterClass
    private void afterClass() {

    }
}
