package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author Lokesh.
 * @since Sep 3, 2018
 */
public class BooleanRetriverTest {

    private BooleanRetriver booleanRetriver;

    @BeforeClass
    private void initClass() {

        booleanRetriver = new BooleanRetriver();
    }

    @Test (dataProvider = "positiveCase_isMarried")
    private void testIsMarried_positive(boolean result, int userId) {

        try {
            boolean actualResult = booleanRetriver.isMarried(userId);
            Assert.assertEquals(actualResult, result);
        } catch (Exception e) {
            Assert.fail("UnExpected result for "
                        + userId
                        + "Expected result is "
                        + result
                        + "But actual result is "
                        + ! result);
        }
    }

    @DataProvider (name = "positiveCase_isMarried")
    private Object[][] testIsMarried_positiveDP() {

        return new Object[][] {
            {true, 1},
            {false, 2},
            {true, 3}
        };
    }

    @AfterClass
    private void afterClass() {

    }
}
