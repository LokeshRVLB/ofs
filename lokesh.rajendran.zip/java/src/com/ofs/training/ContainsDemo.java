package com.ofs.training;

import java.time.chrono.IsoChronology;
import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 11, 2018
 */
public class ContainsDemo {

    public static void main(String[] args) {
        ContainsDemo obj = new ContainsDemo();
        obj.run();
    }

    private void run() {

        Person person = new Person("Bob",
                                   IsoChronology.INSTANCE.date(2000, 9, 12),
                                   Person.Sex.MALE,
                                   "bob@example.com");

        List<Person> persons = Person.createRoster();

        if ( ! persons.contains(person)) {
            log("%s is not in the roster", person.getName());
            return;
        }
        log("%s is in the roster", person.getName());
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
