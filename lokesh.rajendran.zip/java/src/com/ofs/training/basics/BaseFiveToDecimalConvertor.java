package com.ofs.training.basics;

/**
 * @author Lokesh.
 * @since Aug 30, 2018
 */
public class BaseFiveToDecimalConvertor {

    public static void main(String[] args) {
        BaseFiveToDecimalConvertor obj = new BaseFiveToDecimalConvertor();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {
        int decimalNumber = getBaseFiveEquivalent(230);
        log("Decimal equivalent is : %d%n", decimalNumber);
    }

    private int getBaseFiveEquivalent(int baseFiveNumber) {
        int decimalNumber = 0;

        for (int positioner = 0; baseFiveNumber != 0; positioner++) {
            decimalNumber += (baseFiveNumber % 10) * Math.pow(5, positioner);
            baseFiveNumber = baseFiveNumber / 10;
        }
        return decimalNumber;
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
