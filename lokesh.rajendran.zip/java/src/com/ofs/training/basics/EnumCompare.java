package com.ofs.training.basics;

public class EnumCompare {

    enum Places {
        selam,
        adayar,
        poonamalli,
        taramani;

        int objectCounter = 0;

        void getValue() {
            this.objectCounter = this.objectCounter + 1;
            System.out.println(objectCounter);
        }
    }

    public static void main(String[] args) {

        Places adayarShoppingMall = Places.selam;
        Places vishnuTemple = Places.adayar;
        Places superMarket = Places.selam;
        Places indianVegHotel = Places.taramani;
        Places busStand = Places.poonamalli;

        System.out.println(adayarShoppingMall == superMarket);
        System.out.println(adayarShoppingMall.equals(superMarket));
        System.out.println(adayarShoppingMall == indianVegHotel);
        System.out.println(adayarShoppingMall.equals(indianVegHotel));

        System.out.println(adayarShoppingMall.compareTo(superMarket));
        System.out.println(adayarShoppingMall.compareTo(indianVegHotel));
        System.out.println(adayarShoppingMall.ordinal() - indianVegHotel.ordinal());

        adayarShoppingMall.getValue();
        superMarket.getValue();
    }
}
