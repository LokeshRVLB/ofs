package com.ofs.training.basics;

/**
 * @author Lokesh.
 * @since Aug 30, 2018
 */
public class InitialComputer {

    public static void main(String[] args) {
        InitialComputer obj = new InitialComputer();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log("%s", t.getMessage());
        }
    }

    public void run(String[] nameParts) {
        log("%s", getInitial(nameParts));
    }

    public String getInitial(String[] nameParts) {

        if (nameParts.length == 0) {
            throw new RuntimeException("No Name given");
        }
        StringBuilder sb = new StringBuilder();

        for (String namePart : nameParts) {
            sb.append(namePart.charAt(0));
        }
        return sb.toString();
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }

}
