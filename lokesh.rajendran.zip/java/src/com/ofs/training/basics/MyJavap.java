package com.ofs.training.basics;

import java.lang.reflect.Method;
import java.lang.reflect.TypeVariable;
import java.lang.reflect.Modifier;
import java.lang.reflect.Constructor;

//class MyJavap {
public class MyJavap {

    // public static execute() {
    public static void main(String[] args) {

        // Myjavap myJavap = getCurrentProgram();
        // Console console = myJavap.getConsole();
        MyJavap myJavap = new MyJavap();

        // if (argument.isEmpty()) {
        //     console.print("No class file name given");
        //     return
        // }
        if (args.length == 0) {
            System.out.println("No class file name given");
            return;
        }

        // if (argument.isOutOfBound()) {
        //     console.print("Single class can only be executed");
        //     return
        // }
        if (! (args.length == 1)) {
            System.out.println("Single class can only be executed");
            return;
        }

        // if (! argument.ClassExists()) {
        //     console.print("Class does not exists");
        //     return
        // }
        // Class classToBeExecuted = argument.getClass()
        Class classToBeExecuted = myJavap.getClassHeaderDetails(args[0]);

        System.out.println(" {");

        // Constructor[] constructorsDefined = classToBeExecuted.getDefinedConstructors();
        Constructor[] constructors = classToBeExecuted.getDeclaredConstructors();

        // for (constructor in ConstructorsDefined) {
        //     console.print(constructor.getModifiers())
        //     console.print(constructor.getName())
        //     console.print(constructor.getParameters())
        // }
        for (Constructor constructor : constructors) {
            System.out.println("\t" 
                                + myJavap.getModifiers(constructor.getModifiers())
                                + " "
                                + constructor.getName()
                                + "("
                                + myJavap.getParameters(constructor)
                                + ")"
                                + myJavap.getExceptions(constructor)
                                + ";");
        }

        // Method[] methodsDefined = classToBeExecuted.getDefinedMethods();
        Method[] methodsDefined = classToBeExecuted.getDeclaredMethods();

        // for (method in methodsDefined) {
        //     console.print(method.getModifiers())
        //     console.print(method.getReturnType())
        //     console.print(method.getName())
        //     console.print(method.getParameters())
        //     console.print(method.getExceptions())
        // }
        for (Method method : methodsDefined) {
            System.out.println("\t" 
                                + myJavap.getModifiers(method.getModifiers())
                                + " "
                                + method.getReturnType().getTypeName()
                                + " "
                                + method.getName()
                                + "("
                                + myJavap.getParameters(method)
                                + ")"
                                + myJavap.getExceptions(method)
                                + ";");
        }

        System.out.println("}");

    }

    private Class getClassHeaderDetails(String className) {
        Class classToBeExecuted = null;

        try {
            classToBeExecuted = Class.forName(className);
        } catch (ClassNotFoundException e) {
            System.out.println("Class doesnot exists");
        }

        // console.print(classToBeExecuted.getModifier();
        System.out.print(getModifiers(classToBeExecuted.getModifiers()) + " ");

        // console.print(classToBeExecuted.getName());
        System.out.print("class " + classToBeExecuted.getName());

        // Interface[] interfaces = classToBeExecuted.getInterfaces();
        Class[] interfaces = classToBeExecuted.getInterfaces();

        // if (interfaces.length > 0) {
        //     console.print(interfaces)
        // }
        if (interfaces.length > 0) {
            System.out.print(" implements ");
            for (int index = 0; index < interfaces.length; index++) {
                System.out.print(interfaces[index].getName());
                if (index + 1 != interfaces.length) {
                    System.out.print(", ");
                }
            }
        }

        // SuperClass superClass = classToBeExecuted.getSuperClass();
        Class superClass = classToBeExecuted.getSuperclass();

        // if (superClass.exists) {
        //     console.print(superClass)
        // }
        if (superClass != null) {
            System.out.print(" extends " + superClass.getName());
        }
        return classToBeExecuted;
    }

    private String getModifiers(int modifier) {

        StringBuilder sb = new StringBuilder();

        if (Modifier.isPrivate(modifier)) { sb.append("private "); }
        if (Modifier.isPublic(modifier)) { sb.append("public "); }
        if (Modifier.isAbstract(modifier)) { sb.append("abstract "); }
        if (Modifier.isFinal(modifier) ) { sb.append("final "); }
        if (Modifier.isNative(modifier)) { sb.append("native "); }
        if (Modifier.isStatic(modifier)) { sb.append("static "); }
        if (Modifier.isVolatile(modifier)) { sb.append("volatile "); }

        return sb.toString();
    }

    private String getParameters(Method method) {

        StringBuilder sb = new StringBuilder();
        Class[] types = method.getParameterTypes();

        for (Class clazz : types) {
            sb.append(clazz.getTypeName());
            sb.append(", ");
        }
        if(sb.length() > 0) { return sb.substring(0, sb.length() - 2); }
        return "";
    }

    private String getParameters(Constructor constructor) {

        StringBuilder sb = new StringBuilder();
        Class[] types = constructor.getParameterTypes();
        for (Class clazz : types) {
            sb.append(clazz.getTypeName());
            sb.append(", ");
        }
        if(sb.length() > 0) { return sb.substring(0, sb.length() - 2); }
        return "";

    }


    private String getExceptions(Constructor constructor) {

        StringBuilder sb = new StringBuilder();
        Class[] exceptionz = constructor.getExceptionTypes();

        for (Class exception : exceptionz) {
            sb.append(exception.getName());
            sb.append(", ");
        }

        if (exceptionz.length > 0) {
            return " throws " + sb.substring(0, sb.length() - 2);
        }
        return "";
    }

    private String getExceptions(Method method) {

        StringBuilder sb = new StringBuilder();
        Class[] exceptionz = method.getExceptionTypes();

        for (Class exception : exceptionz) {
            sb.append(exception.getName());
            sb.append(", ");
        }

        if (exceptionz.length > 0) {
            return " throws " + sb.substring(0, sb.length() - 2);
        }
        return "";
    }
}
