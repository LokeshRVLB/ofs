package com.ofs.training.basics;

public class VarargsDemonstrator {

    public static void main(String[] args) {

        VarargsDemonstrator varargsDemonstrator = new VarargsDemonstrator();
        // varargsDemonstrator.showLength(); ambiguous condition
        varargsDemonstrator.showLength(1, 2, 3, 4);
        varargsDemonstrator.showLength(5, 6, 7);
        varargsDemonstrator.showLength(true, false, true, false);
        varargsDemonstrator.showLength(true, false, true);
    }

    void showLength(int... arguments) {
        System.out.println("argument length is: " + arguments.length);

        for (int index : arguments) {
            System.out.println(index);
        }
    }
    void showLength(boolean... arguments) {
        System.out.println("argument length is: " + arguments.length);

        for (boolean index : arguments) {
            System.out.println(index);
        }
    }
}
