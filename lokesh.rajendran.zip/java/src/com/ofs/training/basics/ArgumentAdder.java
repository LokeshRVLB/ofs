package com.ofs.training.basics;

/**
 * @author Lokesh.
 * @since Aug 31, 2018
 */
public class ArgumentAdder {

    public static void main(String[] args) {

        ArgumentAdder obj = new ArgumentAdder();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log("%s", t.getMessage());
        }
    }

    private void run(String[] args) {
        log("%d", addArguments(args));
    }

    public int addArguments(String[] args) {
        int result = 0;

        if (args.length < 2) {
            throw new RuntimeException("Atlease two arguments are required for the program");
        }

        for (String number : args) {
            result += Integer.parseInt(number);
        }
        return result;
    }


    private static void log(String format, Object... i) {
        System.out.format(format, i);
    }
}
