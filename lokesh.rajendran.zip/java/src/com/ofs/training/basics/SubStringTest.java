package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class SubStringTest {

    private SubString subString;

    @BeforeClass
    private void initClass() {

        subString = new SubString();
    }

    @Test(dataProvider = "positiveCase_getSubString")
    private void testGetSubString_positive(String givenString, int startIndex, int endIndex, String expectedResult) {

        String actualResult = null;
        try {
            actualResult = subString.getSubString(givenString, startIndex, endIndex);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("UnExpected result for "
                        + givenString
                        + "Expected result is "
                        + expectedResult
                        + "But actual result is "
                        + actualResult);
        }
    }

    @Test(dataProvider = "positiveCase_getSubStringLength")
    private void testGetSubStringLength_positive(String givenSubString, int expectedResult) {

        int actualResult = 0;
        try {
            actualResult = subString.getSubStringLength(givenSubString);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("UnExpected result for "
                        + givenSubString
                        + "Expected result is "
                        + expectedResult
                        + "But actual result is "
                        + actualResult);
        }
    }

    @Test(dataProvider = "negativeCase_getSubString_startIndexOutOfBound")
    private void testGetSubString_negative(String givenString, int startIndex, int endIndex, String expectedResult) {

        try {
            subString.getSubString(givenString, startIndex, endIndex);
            Assert.fail("Expected an Exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "start index out of bound exception");
        }
    }

    @Test(dataProvider = "negativeCase_getSubString_endIndexOutOfBound")
    private void testGetSubString_negative1(String givenString, int startIndex, int endIndex, String expectedResult) {

        try {
            subString.getSubString(givenString, startIndex, endIndex);
            Assert.fail("Expected an Exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), "end index out of bound exception");
        }
    }

    @DataProvider(name = "positiveCase_getSubString")
    private Object[][] testGetSubString_positiveDP() {

        return new Object[][] {
            {"Lokesh", 2, 4, "ke"},
            {"Boovan", 2, 5, "ova"},
            {"Vijaya", 1, 3, "ij"}
        };
    }

    @DataProvider(name = "positiveCase_getSubStringLength")
    private Object[][] testGetSubStringLength_positiveDP() {

        return new Object[][] {
            {"ke", 2},
            {"ova", 3},
            {"ij", 2}
        };
    }

    @DataProvider(name = "negativeCase_getSubString_startIndexOutOfBound")
    private Object[][] testGetSubString_negativeDP() {

        return new Object[][] {
            {"L", 2, 4, "start index out of bound exception"},
            {"", 2, 5, "start index out of bound exception"},
        };
    }

    @DataProvider(name = "negativeCase_getSubString_endIndexOutOfBound")
    private Object[][] testGetSubString_negativeDP1() {

        return new Object[][] {
            {"L", 0, 4, "end index out of bound exception"},
            {"", 0, 5, "end index out of bound exception"},
        };
    }

    @AfterClass
    private void afterClass() {

    }
}
