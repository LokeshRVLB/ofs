package com.ofs.training.basics;

public class FileNotFoundException extends Exception {

    public String getMessage() {

        return ("The file you requested is not in the server");
    }

    public String toString() {

        return ("File is not present");
    }
}
