package com.ofs.training.basics;

import java.io.File;

public class Server {

    void getHTML(String fileName) throws HTTPException {

        File fileOpening = new File(fileName);

        if(! fileOpening.isFile()) {
            HTTPException httpException = new HTTPException(404);
            httpException.initCause(new FileNotFoundException());
            throw httpException;
        }
    }
}
