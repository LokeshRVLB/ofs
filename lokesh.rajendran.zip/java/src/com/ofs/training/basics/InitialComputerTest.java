package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author Lokesh.
 * @since Aug 30, 2018
 */
@Test
public class InitialComputerTest {

    private InitialComputer initialComputer;

    @BeforeClass
    private void initClass() {

        initialComputer = new InitialComputer();
    }

    @Test(dataProvider = "testGetInitial_positiveDP")
    private void testGetInitial_positive(String[] nameParts, String result) {

        String expectedResult = result;
        String actualResult = null;
        try {
            actualResult = initialComputer.getInitial(nameParts);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            StringBuilder sBuilder = new StringBuilder();
            for (String name : nameParts) {
                sBuilder.append(name);
            }
            Assert.fail("Unexpected result for "
                        + sBuilder.toString()
                        + "expected result is "
                        + expectedResult
                        + " But actual result is "
                        + actualResult
                        , e);
        }
    }

    @Test(dataProvider = "negativeCase_getInitial")
    private void testGetInitial_negative(String expected, String[] nameParts) {

        try {
            initialComputer.getInitial(nameParts);
            Assert.fail("Execpted " + expected + "Exception But no Exception found");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expected);
        }
    }

    @DataProvider
    private Object[][] testGetInitial_positiveDP() {

        return new Object[][] {
            {new String[] {"Lokesh", "Balaji"}, "LB"},
            {new String[] {"Vijaya", "Rajendran"}, "VR"},
            {new String[] {"Boovan", "Naik"}, "BN"}
        };
    }

    @DataProvider(name = "negativeCase_getInitial")
    private Object[][] testGetInitial_negativeDP() {

        return new Object[][] {
            {"No Name given", new String[] {}},
        };
    }

    @AfterClass
    private void afterClass() {

    }
}
