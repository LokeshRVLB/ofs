package com.ofs.training.basics;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import com.ofs.training.basics.EnumComparator.Place;

/**
 * @author Lokesh.
 * @since Sep 3, 2018
 */
public class EnumCompareTest {

    private EnumComparator enumComparator;
    @BeforeClass
    private void initClass() {

        enumComparator = new EnumComparator();
    }

    @Test(dataProvider = "positiveCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equals_positive(Place placeOne, Place placeTwo, boolean expectedResult) {

        boolean actualResult;
        try {
            actualResult = enumComparator.isInSameLocation_equals(placeOne, placeTwo);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("UnExpected result for "
                        + placeOne
                        + " and "
                        + placeTwo
                        + "Expected result is "
                        + expectedResult
                        + "But actual result is "
                        + ! expectedResult);
        }
    }

    @Test(dataProvider = "positiveCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equalTo_positive(Place placeOne, Place placeTwo, boolean expectedResult) {

        boolean actualResult;
        try {
            actualResult = enumComparator.isInSameLocation_equals(placeOne, placeTwo);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("UnExpected result for "
                        + placeOne
                        + " and "
                        + placeTwo
                        + "Expected result is "
                        + expectedResult
                        + "But actual result is "
                        + ! expectedResult);
        }
    }

    @Test(dataProvider = "negativeCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equals_negative(Place placeOne, Place placeTwo, String expectedResult) {

        try {
            enumComparator.isInSameLocation_equals(placeOne, placeTwo);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expectedResult);
        }
    }

    @Test(dataProvider = "negativeCase_isInSameLocation_equals_==_Case")
    private void testIsInSameLocation_equalTo_negative(Place placeOne, Place placeTwo, String expectedResult) {

        try {
            enumComparator.isInSameLocation_equalTo(placeOne, placeTwo);
            Assert.fail("Expected an exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expectedResult);
        }
    }

    @DataProvider(name = "positiveCase_isInSameLocation_equals_==_Case")
    private Object[][] testIsInSameLocation_equals_positiveDP() {

        return new Object[][] {
            {Place.ADAYAR, Place.ADAYAR, true},
            {Place.SELAM, Place.ADAYAR, false}
        };

    }

    @DataProvider(name = "negativeCase_isInSameLocation_equals_==_Case")
    private Object[][] testIsInSameLocation_equals_negativeDP() {

        return new Object[][] {
            {null, Place.ADAYAR, "Null value found in given values"},
            {Place.SELAM, null, "Null value found in given values"},
            {null, null, "Null value found in given values"}
        };

    }

    @AfterClass
    private void afterClass() {

    }
}
