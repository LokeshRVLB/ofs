package com.ofs.training.basics;

public class EqualsVersusEqualToDemonstrator {

    public static void main(String[] args) {

        String stringOne = "This is a String equality Test";
        String stringReference;
        String stringTwo = new String(stringOne);
        String stringThree = "This is a String inequality Test";
        stringReference = stringOne;

        System.out.println("Is stringOne and stringTwo hold the same data : " + stringOne.equals(stringTwo));
        System.out.println("Is stringOne and stringThree hold the same data : " + stringOne.equals(stringThree));
        System.out.println("Hashcode of StringOne : " + stringOne.hashCode());
        System.out.println("Hashcode of StringOne : " + stringThree.hashCode());
        System.out.println("Is StringOne and stringReference point to same object (String) : " + (stringOne == stringReference));
        System.out.println("Hashcode of StringOne : " + stringOne.hashCode());
        System.out.println("Hashcode of StringOne : " + stringReference.hashCode());
        System.out.println("Data in stringReference is :\" " + stringOne + "\"");
        System.out.println("Data in stringTwo is :\" " + stringTwo + "\"");
        System.out.println("Is stringTwo and stringReference point to same object (String) " + (stringTwo == stringReference));
        System.out.println("Is stringTwo and stringReference hold the same data " + stringOne.equals(stringTwo));
    }
}
