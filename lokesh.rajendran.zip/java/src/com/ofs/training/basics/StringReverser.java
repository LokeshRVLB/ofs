package com.ofs.training.basics;

/**
 * @author Lokesh.
 * @since Sep 5, 2018
 */
interface StrReverse {
    String reverseString();
}

public class StringReverser implements CharSequence{

    private char[] charOfString;

    private StringReverser(String str) {
        charOfString = str.toCharArray();
    }

    public static void main(String[] args) {
        StringReverser obj = new StringReverser("Lokesh Balaji");

        try {
            obj.run();
        } catch (Exception t) {
            log(t);
        }
    }

    private void run() {

        displayReversedString(() -> {

                                char[] newCharOfString = new char[length()];

                                for (int i = length() - 1, j = 0; i >= 0; i--, j++) {
                                    newCharOfString[j] = charAt(i);
                                }
                                charOfString = newCharOfString;
                                return toString();
                                });
    }

    private void displayReversedString(StrReverse strReverse) {
        log("%s", strReverse.reverseString());
    }

    private static void log(Exception t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }

    @Override
    public int length() {
        return charOfString.length;
    }

    @Override
    public char charAt(int index) {
        return charOfString[index];
    }

    @Override
    public String toString() {
        String result = "";

        for (int index = 0; index < length(); index++) {
            result += charAt(index);
        }
        return result;
    }

    @Override
    public CharSequence subSequence(int start, int end) {
        StringBuilder sbBuilder = new StringBuilder();

        for (int index = start; index < end; index++) {
            sbBuilder.append(charOfString[index]);
        }
        return new StringReverser(sbBuilder.toString());
    }
}
