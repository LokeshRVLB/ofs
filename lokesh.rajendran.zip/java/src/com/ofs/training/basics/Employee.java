package com.ofs.training.basics;

public class Employee {

    static int count = 0;

    int id;
    String name;

    public Employee(String name) {

        this.name = name;
        this.id = ++count;
    }

    public String toString() {

        return (this.name + ":" + this.id);
    }

    public static void main(String[] args) {

        Employee[] employee = new Employee[10];

        employee[0] = new Employee("Lokesh");
        employee[1] = new Employee("Balaji");
        employee[2] = new Employee("Vijaya");
        employee[3] = new Employee("Rajendran");
        employee[4] = new Employee("Boovan");
        employee[5] = new Employee("Hari");
        employee[6] = new Employee("Prasana");
        employee[7] = new Employee("Hameed");
        employee[8] = new Employee("Sruthi");
        employee[9] = new Employee("Keerthana");

        for (int i = 0; i < 10; i++) {
            System.out.println(employee[i]);
        }
    }
}
