package com.ofs.training.basics;

public class ChildClassToDemonstrateStaticOveriding extends StaticMethodOveridingDemo {

    public static void main(String[] args) {

        StaticMethodOveridingDemo staticMethodOveridingDemo = new ChildClassToDemonstrateStaticOveriding();
        ChildClassToDemonstrateStaticOveriding childStaticMethodOveridingDemo = new ChildClassToDemonstrateStaticOveriding();
        staticMethodOveridingDemo.methodOne();
        staticMethodOveridingDemo.methodTwo();
        staticMethodOveridingDemo.methodThree();
        staticMethodOveridingDemo.methodFour();
        childStaticMethodOveridingDemo.methodFour();
    }

    public void methodOne() {

        System.out.println("This is methodOne in child");
    }

    public void methodTwo() {

        System.out.println("This is methodTwo in child");
    }

    public void methodThree() {

        System.out.println("This is methodThree in child");
    }

    public static void methodFour() {

        System.out.println("This is methodFour in child");
    }
}
