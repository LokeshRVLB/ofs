package com.ofs.training.basics;

public class NotANumberDemo {

    public static void main(String[] args) {

        double aValidFloat = 0.0 / 0.0;
        System.out.println("is anvalidFloat Not a Number: " + Double.isNaN(aValidFloat));
        System.out.println("1.0 / 0.0 : " + 1.0 / 0.0);
    }
}
