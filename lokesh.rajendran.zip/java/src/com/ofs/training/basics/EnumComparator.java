package com.ofs.training.basics;

/**
 * @author Lokesh.
 * @since Sep 3, 2018
 */
public class EnumComparator {

    enum Place {

        SELAM,
        ADAYAR,
        POONAMALLI,
        TARAMANI;
    }

    public static void main(String[] args) {
        EnumComparator obj = new EnumComparator();

        try {
            obj.run();
        } catch (Exception t) {
            log(t);
        }
    }

    private void run() {
        Place adayarShoppingMall = Place.ADAYAR;
        Place vishnuTemple = Place.ADAYAR;
        Place superMarket = Place.SELAM;

        log("is adyar shopping mall and vishnu temple in same location : %b\n"
                , isInSameLocation_equals(adayarShoppingMall, vishnuTemple));
        log("is adayar shopping mall and vishnu temple in same location : %b\n"
                , isInSameLocation_equalTo(adayarShoppingMall, vishnuTemple));
        log("is adayar shopping mall and super market in same location : %b\n"
                , isInSameLocation_equals(adayarShoppingMall, superMarket));
        log("is adayar shopping mall and super market in same location : %b\n"
                , isInSameLocation_equalTo(adayarShoppingMall, superMarket));
    }

    private void validate(Place placeOne, Place placeTwo) {

        if (placeOne == null || placeTwo == null) {
            throw new RuntimeException("Null value found in given values");
        }
    }

    public boolean isInSameLocation_equalTo(Place placeOne, Place placeTwo) {
        validate(placeOne, placeTwo);
        return placeOne == placeTwo;
    }

    public boolean isInSameLocation_equals(Place placeOne, Place placeTwo) {
        validate(placeOne, placeTwo);
        return placeOne.equals(placeTwo);
    }

    private static void log(Exception t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
