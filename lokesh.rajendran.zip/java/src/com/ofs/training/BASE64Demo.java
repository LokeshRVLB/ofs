package com.ofs.training;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.URISyntaxException;
import java.net.URL;
import java.util.Base64;

public class BASE64Demo {


    public static void main(String[] args) {
        BASE64Demo obj = new BASE64Demo();
        try {
            obj.run();
        } catch (Exception e) {
            e.printStackTrace();
        }

    }

    private void run() throws URISyntaxException {

        URL resource = getClass().getResource("pass.txt");
        File file = new File(resource.toURI());

        try (OutputStream fileOutputStream = new FileOutputStream(file)){

            Base64.Encoder encoder = Base64.getEncoder();
            OutputStream passwordOutputStream = encoder.wrap(fileOutputStream);
            String password = "RVLBlokesh";
            byte[] pass = password.getBytes();
            passwordOutputStream.write(pass);
            passwordOutputStream.flush();
        } catch (Exception e) {
            throw new RuntimeException(e);
        }

        try (InputStream inputStream = getClass().getResourceAsStream("pass.txt")){
            Base64.Decoder decoder = Base64.getDecoder();
            InputStream passwordInputStream = decoder.wrap(inputStream);
            BufferedReader bufferedReader = new BufferedReader(new InputStreamReader(passwordInputStream));
            log("%s%n", bufferedReader.readLine());
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
