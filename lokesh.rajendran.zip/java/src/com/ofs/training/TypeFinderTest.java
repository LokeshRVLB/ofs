package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author Lokesh.
 * @since Aug 31, 2018
 */
@Test
public class TypeFinderTest {

    TypeFinder typeFinder;

    @BeforeClass
    private void initClass() {

        typeFinder = new TypeFinder();
    }

    @Test(dataProvider = "positiveCase_getType")
    private void testGetType_positive(Object expression, String result) {

        String expectedResult = result;
        String actualResult = null;
        try {
            actualResult = typeFinder.getType(expression);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail("Unexpected result "
                    + actualResult
                    + "expected result is "
                    + expectedResult
                    , e);
        }
    }

    @DataProvider(name = "positiveCase_getType")
    private Object[][] testGetType_positiveDP() {
        return new Object[][] {
                { 100 / 25, "Integer"},
                { 20.0 /30, "Double"},
                { "hello", "String"},
                { 'z' / 9, "Integer"},
                { 11.2f / 10, "Float"}
        };

    }

    @AfterClass
    private void afterClass() {

    }
}
