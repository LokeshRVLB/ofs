package com.ofs.training;

public class IntegerLongEqualsDemo {

    public static void main(String[] args) {

        System.out.println("Integer.valueOf(1).equals(Long.valueOf(1)): " + Integer.valueOf(1).equals(Long.valueOf(1)));
    }
}