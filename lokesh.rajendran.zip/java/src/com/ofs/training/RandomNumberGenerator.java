package com.ofs.training;

import java.util.Random;

public class RandomNumberGenerator {

    public static void main(String[] args) {
        RandomNumberGenerator obj = new RandomNumberGenerator();
        obj.run();

    }

    private void run() {

        Random randomGenerator = new Random();
        log("%f%n", randomGenerator.nextDouble());
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
