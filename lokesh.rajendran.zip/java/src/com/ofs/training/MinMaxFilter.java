package com.ofs.training;

import java.util.Arrays;
import java.util.List;
import java.util.OptionalInt;


/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class MinMaxFilter {

    public static void main(String[] args) {
        MinMaxFilter obj = new MinMaxFilter();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        List<Integer> randomNumbers = Arrays.asList(new Integer[] {1, 6, 10, 25, 78});
        int total = randomNumbers.stream()
                                 .mapToInt(Integer :: intValue)
                                 .sum();
        log("%d%n", total);

        OptionalInt minValue = randomNumbers.stream()
                                            .mapToInt(Integer :: intValue)
                                            .min();
        log("%d%n", minValue.getAsInt());

        OptionalInt maxValue = randomNumbers.stream()
                                            .mapToInt(Integer :: intValue)
                                            .max();
        log("%d%n", maxValue.getAsInt());

    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
