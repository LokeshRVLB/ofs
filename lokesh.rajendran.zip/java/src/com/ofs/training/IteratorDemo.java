package com.ofs.training;

import java.util.Iterator;
import java.util.List;
import java.util.Spliterator;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class IteratorDemo {

    public static void main(String[] args) {
        IteratorDemo iteratorDemo = new IteratorDemo();
        iteratorDemo.run();
    }

    private void run() {

        List<Person> persons = Person.createRoster();
        Iterator<Person> iterator = persons.iterator();

        iterator.forEachRemaining(person -> log("%s%n", person));
        while (iterator.hasNext()) {
            Person person = iterator.next();
            log("%s%n", person);
        }

        Spliterator<Person> spliterator = persons.spliterator();
        while (spliterator.tryAdvance(person -> log("%s%n", person)));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
