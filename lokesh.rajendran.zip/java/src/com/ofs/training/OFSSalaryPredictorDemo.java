package com.ofs.training;

import java.time.LocalDate;

public class OFSSalaryPredictorDemo {

    public static void main(String[] args) {
        OFSSalaryPredictorDemo obj = new OFSSalaryPredictorDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        LocalDate salaryDate = LocalDate.now().with(new OFSSalaryDatePredictor());
        log("%s%n%s%n", salaryDate, salaryDate.getDayOfWeek());
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
