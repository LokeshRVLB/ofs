package com.ofs.training;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

public class ISODateFormatter {

    public static void main(String[] args) {
        ISODateFormatter obj = new ISODateFormatter();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        LocalDate today = LocalDate.now();
        DateTimeFormatter basicFormatter = DateTimeFormatter.BASIC_ISO_DATE;
        System.out.println(basicFormatter.format(today));
        DateTimeFormatter seperatedFormatter = DateTimeFormatter.ISO_DATE;
        System.out.println(seperatedFormatter.format(today));
        DateTimeFormatter localFormatter = DateTimeFormatter.ISO_LOCAL_DATE;
        System.out.println(localFormatter.format(today));
        DateTimeFormatter ordinalFormatter = DateTimeFormatter.ISO_ORDINAL_DATE;
        System.out.println(ordinalFormatter.format(today));
        DateTimeFormatter weekFormatter = DateTimeFormatter.ISO_WEEK_DATE;
        System.out.println(weekFormatter.format(today));
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
