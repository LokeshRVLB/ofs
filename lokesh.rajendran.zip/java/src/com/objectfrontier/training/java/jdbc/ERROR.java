package com.objectfrontier.training.java.jdbc;

/**
 * @author Lokesh.
 * @since Sep 26, 2018
 */
public class ERROR {

    final static String SQL_USER_ERROR = "Person is not in record, check user credentials";
    final static String SQL_SYSTEM_ERROR = "DATABASE FAILURE";
    final static String SQL_DATA_ERROR = "check Person credentials, Duplocate email id and NULL values not allowed except for address";
}
