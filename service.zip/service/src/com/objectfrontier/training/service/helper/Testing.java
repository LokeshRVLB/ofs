package com.objectfrontier.training.service.helper;

import java.util.List;
import java.io.IOException;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.DTO.PersonDTO;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public class Testing {

    public static void main(String[] args) throws IOException, SQLException {
        ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                "mysqlCredentials.txt");
        connectionManager.getConnection();
//        PersonMySQLDBManager personManager = new PersonMySQLDBManager(connectionManager);
          PersonService personManager = new PersonService(connectionManager);
//        System.out.println(personManager.isPresent("email", "lokeshbalaji68@gmail.com"));
//        PersonService personService = new PersonService(connectionManager);
        Address address = new Address("Boovan street", "chennai" , 600113);
        Person person = new Person("lokesh", "balaji", "lokebalaji68@gmail.com", address, LocalDate.parse("09-08-1996",
                                                                               DateTimeFormatter.ofPattern("dd-MM-yyyy")));
        System.out.println(person.getBirthDate());
        person.setId(3);
        AddressService addressService = new AddressService(connectionManager);
        try {
//            List<Address> addresses = addressService.readAll();
            address.setId(3);
//            Address addrezz = addressService.delete(address);
            Person persan = personManager.delete(person);
            System.out.println(persan);
        } catch (AppException e) {
            System.out.println(e.getError());
            Error[] errors = e.getAssociatedErrors();
            for (Error error : errors) {
                System.out.println(error);
            }
        }
//        try {
//            Person personDTO = personManager.update(person);
//            System.out.println(personDTO.getFirstName() + " " + personDTO.getLastName() + " " + personDTO.getId());
//        } catch (AppException e) {
//            Error[] errors = e.getAssociatedErrors();
//            for (Error error : errors) {
//                System.out.println(error.getErrorCode() + " : " + error.getMessage());
//            }
//        }
    }

}
