package com.objectfrontier.training.service.helper;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.MessageFormat;
import java.util.ArrayList;
import java.util.List;

import com.objectfrontier.training.service.DAO.AddressDAO;
import com.objectfrontier.training.service.entity.POJO.Address;

/**
 * @author Lokesh.
 * @since Oct 12, 2018
 */
public class AddressMySQLManager implements AddressDAO{

    ConnectionManager connectionManager;

    public AddressMySQLManager(ConnectionManager connectionManager) {
        super();
        this.connectionManager = connectionManager;
    }

    @Override
    public List<Address> readAll() {
        String query = new StringBuilder().append("SELECT scv_address.id")
                                          .append("      ,scv_address.street")
                                          .append("      ,scv_address.city")
                                          .append("      ,scv_address.postal_code ")
                                          .append("FROM scv_address ").toString();
        ResultSetProcessor<List<Address>, ResultSet> readAll = (resultSet) -> {
            ArrayList<Address> addresses = new ArrayList<>(resultSet.getFetchSize());
            while (resultSet.next()) {
                Address address = new Address(resultSet.getString("street"),
                                              resultSet.getString("city"),
                                              resultSet.getLong("postal_code"));
                address.setId(resultSet.getLong("id"));
                addresses.add(address);
            }
            return addresses;
        };
        try {
            return readAll.applyOn(query, null, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Address read(long id) {
        String query = new StringBuilder().append("SELECT scv_address.id")
                                          .append("      ,scv_address.street")
                                          .append("      ,scv_address.city")
                                          .append("      ,scv_address.postal_code ")
                                          .append("FROM scv_address WHERE id = ?").toString();
        ResultSetProcessor<Address, ResultSet> read = (resultSet) -> {
            if (resultSet.next()) {
                Address address = new Address(resultSet.getString("street"),
                                              resultSet.getString("city"),
                                              resultSet.getLong("postal_code"));
                address.setId(resultSet.getLong("id"));
                return address;
            }
            return null;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, id);
            return read.applyOn(query, parameters, connectionManager, false, 0);
        } catch (SQLException e) {
            throw new AppException(Error.SQL_READ_ERROR, e);
        }
    }

    @Override
    public Address update(Address address) {
        String query = new StringBuilder().append("UPDATE scv_address ")
                                          .append("SET scv_address.street = ?")
                                          .append("   ,scv_address.city = ?")
                                          .append("   ,scv_address.postal_code = ? ")
                                          .append("WHERE scv_address.id = ?;").toString();
        ResultSetProcessor<Integer, Integer> update = (updatedCount) -> {
            return updatedCount;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getStreet());
            parameters.add(1, address.getCity());
            parameters.add(2, address.getPostalCode());
            parameters.add(3, address.getId());
            update.applyOn(query, parameters, connectionManager, true, 0);
            return address;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_UPDATE_ERROR, e);
        }
    }

    @Override
    public Address delete(Address address) {
        String query = new StringBuilder().append("DELETE FROM scv_address ")
                                          .append("WHERE scv_address.id = ?").toString();
        ResultSetProcessor<Integer, Integer> delete = (deletedCount) -> {
            return deletedCount;
        };
        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getId());
            int deletedCount = delete.applyOn(query, parameters, connectionManager, true, 0);
            if (deletedCount == 1) {
                return address;
            }
            return null;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_DELETE_ERROR, e);
        }
    }

    @Override
    public Address insert(Address address) {
        String insertAddressQuery = new StringBuilder().append("INSERT INTO scv_address (scv_address.street")
                                                       .append("                    ,scv_address.city")
                                                       .append("                    ,scv_address.postal_code) ")
                                                       .append("VALUES (?, ?, ?)").toString();

        ResultSetProcessor<Long, ResultSet> insertAddress = (resultSet) -> {
            resultSet.next();
            return resultSet.getLong(1);
        };

        try {
            List<Object> parameters = new ArrayList<>();
            parameters.add(0, address.getStreet());
            parameters.add(1, address.getCity());
            parameters.add(2, address.getPostalCode());
            long addressId = insertAddress.applyOn(insertAddressQuery, parameters, connectionManager, true,
                    Statement.RETURN_GENERATED_KEYS);
            address.setId(addressId);
            return address;
        } catch (SQLException e) {
            throw new AppException(Error.SQL_INSERT_ERROR, e);
        }
    }

    @Override
    public <V> boolean isPresent(String field, V value) {
        String getFieldQuery = MessageFormat.format("SELECT {0} FROM scv_address", field);
        boolean result = true;
        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (value.equals(resultSet.getObject(1))) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };
        try {
            result = isPresent.applyOn(getFieldQuery, null, connectionManager, false, 0).booleanValue();
        } catch (SQLException e) {
            new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

    @Override
    public <V> boolean isPresent(String field, V value, String neglectRowWithField, String neglectRowWithValue) {
        String getFieldQuery = MessageFormat.format("SELECT {0} FROM scv_address WHERE {1} != {2}",
                                                    field,
                                                    neglectRowWithField,
                                                    neglectRowWithValue);
        boolean result = true;
        ResultSetProcessor<Boolean, ResultSet> isPresent = (resultSet) -> {
            while (resultSet.next()) {
                if (value.equals(resultSet.getObject(1))) {
                    return Boolean.TRUE;
                }
            }
            return Boolean.FALSE;
        };
        try {
            result = isPresent.applyOn(getFieldQuery, null, connectionManager, false, 0).booleanValue();
        } catch (SQLException e) {
            new AppException(Error.SQL_READ_ERROR, e);
        }
        return result;
    }

    
}
