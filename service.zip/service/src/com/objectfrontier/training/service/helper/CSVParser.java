package com.objectfrontier.training.service.helper;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;
import java.util.ArrayDeque;
import java.util.Date;
import java.util.Deque;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;
import java.util.stream.Collectors;

import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

/**
 * @author Lokesh.
 * @since Oct 15, 2018
 */

public class CSVParser implements Enumeration<Person> {

    private String file;
    private Deque<Person> persons;
    private Map<Long, Address> addresses;

    public CSVParser() {
    }

    public CSVParser(String file) {
        this.file = file;
        this.addresses = csvToAddressMap();
        this.persons = csvToList();
    }

    private Map<Long, Address> csvToAddressMap() {
        try (InputStream fileStream = getClass().getResourceAsStream("addresses.csv")) {
            BufferedReader csvStream = new BufferedReader(new InputStreamReader(fileStream));
            HashMap<Long, Address> addressMap = new HashMap<>();
            csvStream.lines().map(this::addressMapper).forEach(address -> addressMap.put(address.getId(), address));
            return addressMap;
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Deque<Person> csvToList() {

        try (InputStream fileStream = getClass().getResourceAsStream(this.file)) {
            BufferedReader csvStream = new BufferedReader(new InputStreamReader(fileStream));
            return csvStream.lines().map(this::personMapper).collect(Collectors.toCollection(ArrayDeque::new));
        } catch (Exception e) {
            throw new RuntimeException(e);
        }
    }

    private Address addressMapper(String csvRecord) {
        StringTokenizer tokenizer = new StringTokenizer(csvRecord, ",");
        Address address = new Address();

        while (tokenizer.hasMoreTokens()) {
            address.setId(Long.parseLong(tokenizer.nextToken()));
            address.setStreet(tokenizer.nextToken());
            address.setCity(tokenizer.nextToken());
            address.setPostalCode(Long.parseLong(tokenizer.nextToken()));
        }
        return address;
    }

    private Person personMapper(String csvRecord) {
        StringTokenizer tokenizer = new StringTokenizer(csvRecord, ",");
        Person person = new Person();

        while (tokenizer.hasMoreTokens()) {
            if (tokenizer.countTokens() > 5) {
                person.setId(Long.parseLong(tokenizer.nextToken()));
            }
            person.setFirstName(tokenizer.nextToken());
            person.setLastName(tokenizer.nextToken());
            person.setEmail(tokenizer.nextToken());
            LocalDate date;
            date = LocalDate.parse(tokenizer.nextToken(), DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            person.setBirthDate(date);
            Long id = Long.parseLong(tokenizer.nextToken());
            if (addresses.containsKey(id)) {
                person.setAddress(addresses.get(id));
            }
        }
        return person;
    }

    public Deque<Person> getPersons() {
        return persons;
    }

    @Override
    public boolean hasMoreElements() {
        return (persons.size() > 0 ? true : false);
    }

    @Override
    public Person nextElement() {
        return persons.pop();
    }
}
