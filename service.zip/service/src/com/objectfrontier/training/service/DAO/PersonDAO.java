package com.objectfrontier.training.service.DAO;

import java.util.List;

import com.objectfrontier.training.service.entity.DTO.PersonDTO;
import com.objectfrontier.training.service.entity.POJO.Person;

/**
 * @author Lokesh.
 * @since Sep 27, 2018
 */
public interface PersonDAO {

    List<Person> readAll();
    Person read(long id);
    Person read(long id, boolean includeAddress);
    Person update(Person person);
    Person delete(Person person);
    Person insert(Person person);
    <V> boolean isPresent(String field, V value);
    <V> boolean isPresent(String field, V value, String neglect_row_with_field, String neglect_row_with_id);
}
