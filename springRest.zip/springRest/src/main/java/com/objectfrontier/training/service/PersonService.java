package com.objectfrontier.training.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.transaction.Transactional;

import com.objectfrontier.training.service.util.DataAccess;
import com.objectfrontier.training.service.util.GenericDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.objectfrontier.training.service.DAO.PersonDAO;
import com.objectfrontier.training.service.entity.model.Address;
import com.objectfrontier.training.service.entity.model.Person;
import com.objectfrontier.training.service.util.AppException;
import com.objectfrontier.training.service.util.Error;


@Service
@Transactional
public class PersonService {

    @DataAccess(entity = Person.class)
    GenericDAO<Person> personDBManager;

    @Autowired
    @Qualifier("addressService")
    private AddressService addressService;
    
    public PersonService() {
    }
    
    public PersonService(AddressService addressService) {
        this.addressService = addressService;
    }

    public Person create(Person person) {

        Address address = person.getAddress();
        AppException exception = new AppException(Error.DATA_VALIDATION_ERROR);

        try {
            person.setAddress(addressService.create(address));
        } catch (AppException e) {
            if (e.getErrorCode() == Error.ADDRESS_VALIDATION_ERROR.getErrorCode()) {
                exception.setErrorCodes(e.getAssociatedErrors());
            } else {
                throw e;
            }
        }

        try {
            validatePerson(person);
        } catch (AppException e) {
            if (e.getErrorCode() == Error.PERSON_VALIDATION_ERROR.getErrorCode()) {
                exception.setErrorCodes(e.getAssociatedErrors());
            } else {
                throw e;
            }
        }
        
        if (exception.getAssociatedErrors().length > 0) {
            throw exception;
        }
        return personDBManager.persist(person);
    }

    public Person read(long id, boolean includeAddress) {
        
        validatePersonId(id);
        Person person = personDBManager.find(id);
        
        if (includeAddress) {
            Address address = addressService.read(person.getAddress().getId());
            person.setAddress(address);
        }
        return person;
    }

    public Person update(Person person) {
        
        Address address = person.getAddress();
        AppException exceptions = new AppException(Error.DATA_VALIDATION_ERROR);
        try {
            person.setAddress(addressService.update(address));
        } catch (AppException e) {
            if (e.getErrorCode() == Error.ADDRESS_VALIDATION_ERROR.getErrorCode()) {
                exceptions.setErrorCodes(e.getAssociatedErrors());
            } else {
                throw e;
            }
        }
        
        try {
            validateUpdatedPerson(person);
        } catch (AppException e) {
            if (e.getErrorCode() == Error.PERSON_VALIDATION_ERROR.getErrorCode()) {
                exceptions.setErrorCodes(e.getAssociatedErrors());
            } else {
                throw e;
            }
        }
        if (exceptions.getAssociatedErrors().length > 0) {
            throw exceptions;
        }
        return personDBManager.update(person);
    }

    public void delete(Person person) {
        validatePersonId(person.getId());
        addressService.delete(person.getAddress());
        personDBManager.delete(person);
    }

    public List<Person> readAll() {
        List<Person> persons = personDBManager.findAll();
        Map<Long, Address> addresses = new HashMap<>(); 
        for (Address address : addressService.readAll()) {
            addresses.put(address.getId(), address);
        }
        persons.stream().forEach((perzon) -> {
            perzon.setAddress(addresses.get(perzon.getAddress().getId()));
        });
        return persons;
    }

    private void validatePerson(Person person) {
        ArrayList<Error> errors = new ArrayList<>();

        String firstName = person.getFirstName();
        String lastName = person.getLastName();

        if (firstName == null || firstName.isEmpty()) {
            errors.add(Error.FIRST_NAME_NULL_VALUE_ERROR);
        }
        if (lastName == null || lastName.isEmpty()) {
            errors.add(Error.LAST_NAME_NULL_VALUE_ERROR);
        }
        if (person.getBirthDate() == null) {
            errors.add(Error.DOB_NULL_VALUE_ERROR);
        }
        String email = person.getEmail();
        if (email == null || email.isEmpty() || email.indexOf("@") == -1) {
            errors.add(Error.EMAIL_NULL_VALUE_ERROR);
        }
        if (personDBManager.exists("email", email)) {
            errors.add(Error.EMAIL_DUPLICATION_ERROR);
        }
        if (errors.size() > 0) {
            throw new AppException(errors.toArray(new Error[errors.size()]), Error.PERSON_VALIDATION_ERROR);
        }
    }

    public void validatePersonId(long id) {
        if (id <= 0) {
            throw new AppException(Error.INVALID_PERSON_ID);
        }
        if (! personDBManager.exists("id", id)) {
            throw new AppException(Error.INVALID_PERSON_REQUEST);
        }
    }

    private void validateUpdatedPerson(Person person) {
        try {
            validatePerson(person);
            validatePersonId(person.getId());
        } catch (AppException e) {
            if (e.getErrorCode() == 209) {
                throw new AppException(new Error[] { Error.INVALID_PERSON_REQUEST }, Error.PERSON_VALIDATION_ERROR);
            }
            try {
                validatePersonId(person.getId());
            } catch (AppException e2) {
                Error[] errors = e.getAssociatedErrors();
                Error[] newErrors = new Error[errors.length + 1];
                System.arraycopy(errors, 0, newErrors, 0, errors.length);
                newErrors[errors.length] = Error.INVALID_PERSON_REQUEST;
                throw new AppException(newErrors, Error.PERSON_VALIDATION_ERROR);
            }
        }
    }

}
