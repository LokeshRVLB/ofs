package com.objectfrontier.training.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.entity.model.Address;
import com.objectfrontier.training.service.util.BeanUtil;

import javax.ws.rs.PathParam;

import static org.springframework.http.ResponseEntity.ok;

/**
 * @author Lokesh.
 * @since Dec 26, 2018
 */
@RestController
public class AddressController extends BaseContainer {
    
    @Autowired
    @Qualifier("addressService")
    AddressService addressService;

    { 
        initLog(getClass());
    }

    @RequestMapping(
            method = RequestMethod.GET,
            value = "address/{id}",
            produces = "application/json"
            )
    ResponseEntity<Address> read(@PathParam("id") long id) {
        addressService = BeanUtil.getBean(AddressService.class);
        Address address =  addressService.read(id);
        return ResponseEntity.ok().body(address);
    }
    
    @RequestMapping(value = "/address",
                    method = RequestMethod.GET,
                    produces = "application/json")
    ResponseEntity<List<Address>> readAll() {
        addressService = BeanUtil.getBean(AddressService.class);
        List<Address> addresses = addressService.readAll();
        return ResponseEntity.ok().body(addresses);
    }

    @RequestMapping(value = "/address",
                    method = RequestMethod.PUT,
                    produces = "application/json")
    ResponseEntity<Address> update(@RequestBody Address address) {
        addressService = BeanUtil.getBean(AddressService.class);
        addressService.update(address);
        return ResponseEntity.ok().body(address);
    }


    @RequestMapping(method = RequestMethod.POST,
                    value = "/address/{id}/delete"
    )
    ResponseEntity<Address> delete(@PathParam("id") long id, @RequestBody Address address) {
        addressService = BeanUtil.getBean(AddressService.class);
        addressService.delete(address);
        return new ResponseEntity(address, HttpStatus.valueOf(204));
    }
    
    @RequestMapping(value = "/address",
                    method = RequestMethod.POST,
                    produces = "application/json")
    ResponseEntity<Address> create(@RequestBody Address address) {
        addressService = BeanUtil.getBean(AddressService.class);
        addressService.create(address);
        return ResponseEntity.ok().body(address);
    }
}
