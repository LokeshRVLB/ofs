package com.objectfrontier.training.service.util;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.Date;

import sun.security.x509.AVA;

public class ObjectMapper {

    private Class<?> clazz;
    private Object mappedObject;

    public ObjectMapper(Class<?> clazz) throws NoSuchMethodException, SecurityException, InstantiationException,
                    IllegalAccessException, IllegalArgumentException, InvocationTargetException {
        super();
        this.clazz = clazz;
        this.mappedObject = clazz.getConstructor().newInstance();
    }

    public void setParameter(String parameter, String methodName, String parameterType) throws ClassNotFoundException,
                    ParseException {
        Method method = null;
        try {
            method = clazz.getMethod(methodName, Class.forName(parameterType));
        } catch (NoSuchMethodException e) {
            e.printStackTrace();
            throw new RuntimeException(e);
        } catch (SecurityException e) {
            e.printStackTrace();
        }
        try {
            method.invoke(mappedObject , getValue(parameter, Class.forName(parameterType)));
        } catch (IllegalAccessException e) {
            e.printStackTrace();
        } catch (IllegalArgumentException e) {
            e.printStackTrace();
        } catch (InvocationTargetException e) {
            e.printStackTrace();
        }
    }

    private Object getValue(String parameter, Class<?> parameterType) throws ParseException {
            if (parameterType == String.class) {
                return parameter;
            } else if (parameter == null || parameter.length() == 0) {
                return null;
            }else if (parameterType == boolean.class || parameterType == Boolean.class) {
                return "true".equals(parameter);
            } else if (parameterType == byte.class || parameterType == Byte.class) {
                return Byte.valueOf(parameter);
            } else if (parameterType == short.class || parameterType == Short.class) {
                return Short.valueOf(parameter);
            } else if (parameterType == int.class || parameterType == Integer.class) {
                return Integer.valueOf(parameter);
            } else if (parameterType == long.class || parameterType == Long.class) {
                return Long.valueOf(parameter);
            } else if (parameterType == float.class || parameterType == Float.class) {
                return Float.valueOf(parameter);
            } else if (parameterType == double.class || parameterType == Double.class) {
                return Double.valueOf(parameter);
            } else if (parameterType == java.time.LocalDate.class) {
                    return LocalDate.parse(parameter, DateTimeFormatter.ofPattern("dd-MM-yyyy"));
            } else {
                throw new RuntimeException("Cannot convert value of type " + parameterType);
            }
    }

    Object getMappedObject() {
        return mappedObject;
    }
}
