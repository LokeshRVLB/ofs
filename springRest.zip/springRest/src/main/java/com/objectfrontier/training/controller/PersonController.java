package com.objectfrontier.training.controller;

import java.util.List;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.entity.model.Address;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.model.Person;
import com.objectfrontier.training.service.util.BeanUtil;

import javax.ws.rs.PathParam;

/**
 * Servlet implementation class PersonController
 * @author Lokesh.
 * @since Nov 2, 2018
 */

@RestController
public class PersonController extends BaseContainer {
    
    @Autowired
    @Qualifier("personService")
    PersonService personService;
    
    public PersonController() {
        super();
    }

    {
        initLog(getClass());
    }

    @RequestMapping(
            value = "person/{id}",
            method = RequestMethod.GET,
            produces = "application/json"
            )
    ResponseEntity<Person> read(@PathParam("id") long id,
                                @RequestParam("includeAddress") boolean status) {
        personService = BeanUtil.getBean(PersonService.class);
        Person person =  personService.read(id, status);
        if (status) {
            person.setAddress(null);
        }
        return ResponseEntity.ok().body(person);
    }
    
    @RequestMapping(
            value = "/person",
            method = RequestMethod.GET,
            produces = "application/json"
            )
    ResponseEntity<List<Person>> readAll() {
        personService = BeanUtil.getBean(PersonService.class);
        log("entered readAll");
        List<Person> persons = personService.readAll();
        return ResponseEntity.ok().body(persons);
    }

    @RequestMapping(value = "/person",
                    method = RequestMethod.PUT,
                    produces = "application/json")
    ResponseEntity<Person> update(@RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        personService.update(person);
        return ResponseEntity.ok().body(person);
    }


    @RequestMapping(method = RequestMethod.POST,
                    value = "/person/{id}/delete"
    )
    ResponseEntity<Person> delete(@PathParam("id") long id, @RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        personService.delete(person);
        return new ResponseEntity(person, HttpStatus.valueOf(204));
    }

    @RequestMapping(value = "/person",
                    method = RequestMethod.POST,
                    produces = "application/json")
    ResponseEntity<Person> create(@RequestBody Person person) {
        personService = BeanUtil.getBean(PersonService.class);
        personService.create(person);
        return ResponseEntity.ok().body(person);
    }
}
