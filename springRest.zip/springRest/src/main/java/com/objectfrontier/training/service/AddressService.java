package com.objectfrontier.training.service;

import java.util.ArrayList;
import java.util.List;

import javax.transaction.Transactional;

import com.objectfrontier.training.service.entity.model.Person;
import com.objectfrontier.training.service.util.DataAccess;
import com.objectfrontier.training.service.util.GenericDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Service;

import com.objectfrontier.training.service.DAO.AddressDAO;
import com.objectfrontier.training.service.entity.model.Address;
import com.objectfrontier.training.service.util.AppException;
import com.objectfrontier.training.service.util.Error;

/**
 * @author Lokesh.
 * @since Oct 12, 2018
 */
@Service
@Transactional
public class AddressService {

    @DataAccess(entity = Address.class)
    GenericDAO<Address> addressDBManager;
    
    public AddressService() {}

    public Address create(Address address) {
        validateAddress(address);
        return addressDBManager.persist(address);
    }
    
    public Address update(Address address) {

        try {
            validateAddress(address);
            validateAddressId(address.getId());
        } catch (AppException e) {
            
            if (e.getErrorCode() == Error.INVALID_ADDRESS_REQUEST.getErrorCode()) {
                
                throw new AppException(new Error[] { Error.INVALID_ADDRESS_REQUEST },
                                                     Error.ADDRESS_VALIDATION_ERROR);
            }
            
            try {
                validateAddressId(address.getId());
            } catch (AppException e2) {
                
                Error[] errors = e.getAssociatedErrors();
                Error[] newErrors = new Error[errors.length + 1];
                System.arraycopy(errors, 0, newErrors, 0, errors.length);
                
                newErrors[errors.length] = Error.INVALID_ADDRESS_REQUEST;
                
                throw new AppException(newErrors, Error.ADDRESS_VALIDATION_ERROR);
            }
        }
        return addressDBManager.update(address);
    }

    private void validateAddress(Address address) {
        ArrayList<Error> errors = new ArrayList<>();
        
        if (address.getStreet() == null || address.getStreet().isEmpty()) {
            errors.add(Error.STREET_NULL_VALUE_ERROR);
        }

        if (address.getCity() == null || address.getCity().isEmpty()) {
            errors.add(Error.CITY_NULL_VALUE_ERROR);
        }

        long postalCode = address.getPostalCode();
        if (postalCode == 0) {
            errors.add(Error.POSTAL_CODE_NULL_VALUE_ERROR);
        }

        if (errors.size() > 0) {
            throw new AppException(errors.toArray(new Error[errors.size()]),
                                                  Error.ADDRESS_VALIDATION_ERROR);
        }
    }

    public Address read(long id) {

        validateAddressId(id);
        return addressDBManager.find(id);
    }

    public void delete(Address address) {
        
        validateAddressId(address.getId());
        addressDBManager.delete(address);
    }

    public List<Address> readAll() { return addressDBManager.findAll(); }

    private void validateAddressId(long id) {
        
        if (id <= 0) {  throw new AppException(Error.INVALID_ADDRESS_ID);    }    

        if (! addressDBManager.exists("id", id)) {
            throw new AppException(Error.INVALID_ADDRESS_REQUEST);
        }
    }

}
