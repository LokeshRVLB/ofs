package com.objectfrontier.training.service.util;

import java.util.HashSet;
import java.util.Set;


public class LoginTracker {

    private static Set<String> loggedIn = new HashSet<>();

    public static boolean LogIn(String sessionId) {
        if (loggedIn.add(sessionId)) {
            return false;
        }
        return true;
    }
}
