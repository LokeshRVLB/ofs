package com.objectfrontier.training.service;

import java.util.ArrayList;
import java.util.Objects;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import com.objectfrontier.training.service.DAO.AuthenticationDAO;
import com.objectfrontier.training.service.entity.model.LoginCredentials;
import com.objectfrontier.training.service.util.AppException;
import com.objectfrontier.training.service.util.AuthenticationDBManager;
import com.objectfrontier.training.service.util.BeanUtil;
import com.objectfrontier.training.service.util.Error;

/**
 * @author Lokesh.
 * @since Nov 19, 2018
 */
@Service
public class AuthenticationService {

    @Autowired
    @Qualifier("authenticationMysqlManager")
    AuthenticationDAO authenticationDBManager;
    
    public AuthenticationService() {
//        authenticationDBManager = BeanUtil.getBean(AuthenticationDAO.class);
    }

    public void setAuthenticationDBManager(AuthenticationDAO authenticationDAO) {
        this.authenticationDBManager = authenticationDAO;
    }
    
    public boolean authenticate(String email, String pass) {
        validate(email, pass);
        LoginCredentials personDTO = authenticationDBManager.getCredentials(email);
        if (Objects.isNull(personDTO.getPassword())) {
            throw new AppException(Error.UNREGISTERED_EMAIL_ID);
        }
        if(personDTO.getPassword().equals(pass)) {
            return true;
        }
        return false;
    }
    
    public LoginCredentials getCredentials(String email) {
        return authenticationDBManager.getCredentials(email);
    }

    private void validate(String email, String pass) {
        ArrayList<Error> errors = new ArrayList<>(); 
        if (Objects.isNull(email)) {
            errors.add(Error.EMAIL_NULL_VALUE_ERROR);
        }
        if (Objects.isNull(pass)) {
            errors.add(Error.PASSWORD_NULL_VALUE_ERROR);
        }
        if (email.indexOf("@") == -1) {
            errors.add(Error.INVALID_EMAIL_ID);
        }
        if (pass.length() < 6 || pass.length() > 15) {
            errors.add(Error.INVALID_PASS_LENGTH);
        }
        if (errors.size() > 0) {
            throw new AppException(errors.toArray(new Error[errors.size()]), Error.DATA_VALIDATION_ERROR);
        }
        
    }

    
}
