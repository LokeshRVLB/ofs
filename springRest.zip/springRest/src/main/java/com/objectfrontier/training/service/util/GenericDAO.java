package com.objectfrontier.training.service.util;

import java.util.List;

import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

@Repository
public class GenericDAO<E> {
    private Class<E> entityClass;
    
    @Autowired
    private SessionFactory sessionFactory;

    public GenericDAO(Class<E> entityClass) {
        this.entityClass = entityClass;
    }
 
    @SuppressWarnings("unchecked")
    public List<E> findAll() {
        return getSessionFactory().openSession()
                                  .createQuery("from " + entityClass.getSimpleName())
                                  .list();
    }
 
    public E persist(E toPersist) {
        getSessionFactory().openSession()
                           .persist(toPersist);
        return toPersist;
    }

    public E update(E toUpdate) {
        getSessionFactory().openSession()
                           .update(toUpdate);
        return toUpdate;
    }

    public E find(long id) {
        return getSessionFactory().getCurrentSession()
                                  .load(entityClass, new Long(id));
    }

    public void delete(E toDelete) {
        getSessionFactory().getCurrentSession()
                           .delete(toDelete);
    }

    public Boolean exists (String key, long value) {
        String query = "select 1 from " + entityClass.getSimpleName() + " t where t." + key +" = :value";
        Object result = getSessionFactory().openSession()
                                           .createQuery(query)
                                           .setLong("key", value).uniqueResult();
        return (result != null);
    }

    public Boolean exists (String key, String value) {
        String query = "select 1 from " + entityClass.getSimpleName() + " t where t." + key +" = :value";
        Object result = getSessionFactory().openSession()
                                           .createQuery(query)
                                           .setString("key", value).uniqueResult();
        return (result != null);
    }

    public SessionFactory getSessionFactory() {
        return sessionFactory;
    }

}
