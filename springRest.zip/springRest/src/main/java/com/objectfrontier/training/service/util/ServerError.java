package com.objectfrontier.training.service.util;

import com.fasterxml.jackson.databind.annotation.JsonSerialize;

/**
 * @author Lokesh.
 * @since Nov 16, 2018
 */
@JsonSerialize(using = ServerErrorSerializer.class)
public class ServerError {

    private int errorCode;
    private String requestedURL;
    
    public ServerError(int errCode, String url) {
        this.errorCode = errCode;
        this.requestedURL = url;
    }

    public int getErrorCode() {
        return errorCode;
    }

    public String getRequestedURL() {
        return requestedURL;
    }
    
    
}
