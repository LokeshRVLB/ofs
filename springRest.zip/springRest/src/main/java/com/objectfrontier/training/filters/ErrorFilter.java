package com.objectfrontier.training.filters;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Objects;
import java.util.Optional;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.util.AppError;
import com.objectfrontier.training.service.util.AppException;
import com.objectfrontier.training.service.util.AppStatusCode;
import com.objectfrontier.training.service.util.Error;
import com.objectfrontier.training.service.util.JsonUtil;

public class ErrorFilter extends BaseFilter {

    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        super.init(filterConfig);
        initLog(getClass());
    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse res = (HttpServletResponse) response;
//        Throwable exception = (Throwable) request.getAttribute("javax.servlet.error.exception");
//        Integer statusCode = (Integer) request.getAttribute("javax.servlet.error.status_code");
//        String servletName = (String) request.getAttribute("javax.servlet.error.servlet_name");
//        
//        if (Objects.nonNull(exception)) {
//            log(exception.getStackTrace());
//            res.setStatus(statusCode);
//            return;
//        }
        PrintWriter out = res.getWriter();
        try {
            preFilter(req, res);
            chain.doFilter(request, response);
        } catch (Exception e) {
//
//            if (servletName == null) {
//                servletName = "Unknown";
//            }
//
//            String requestUri = (String) request.getAttribute("javax.servlet.error.request_uri");
//
//            if (requestUri == null) {
//                requestUri = "Unknown";
//            }
            log(String.format("Error : %s", e.getMessage()));
            log(e.getStackTrace());
            e.printStackTrace();

            if (e instanceof AppException) {
                int errorCode = ((AppException) e).getErrorCode();

                if (errorCode < 200) {
                    internalError(out, res);
                } else if (errorCode == Error.NO_LOGIN_SESSION.getErrorCode()) {
                    res.setStatus(AppStatusCode.UNAUTHORIZED.getStatusCode());
                    out.write(JsonUtil.toJson(new AppError((AppException) e)));
                } else if (errorCode == Error.INVALID_OPERATION_REQUEST.getErrorCode()) {
                    res.setStatus(AppStatusCode.METHOD_NOT_ALLOWED.getStatusCode());
                    out.write(JsonUtil.toJson(new AppError((AppException) e)));
                } else if (errorCode == Error.JSON_LOAD_ERROR.getErrorCode()) {
                    res.setStatus(AppStatusCode.UNACCEPTED_MEDIA_TYPE.getStatusCode());
                    out.write(JsonUtil.toJson(new AppError((AppException) e)));
                } else {
                    res.setStatus(AppStatusCode.BAD_REQUEST.getStatusCode());
                    out.write(JsonUtil.toJson(new AppError((AppException) e)));
                }

            } else {
                internalError(out, res);
            }
        }

    }

    private void internalError(PrintWriter out, HttpServletResponse res) {
        res.setStatus(AppStatusCode.INTERNAL_SERVER_ERROR.getStatusCode());
        out.write(JsonUtil.toJson(new AppError(new AppException(Error.UNKOWN_ERROR))));
    }

    @Override
    protected void preFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

        String action = Optional.ofNullable(request.getParameter("action")).orElse("noAction");

        if (action.equals("read")) {
            try {
                Long.parseLong(request.getParameter("id"));
            } catch (NumberFormatException e) {
                throw new AppException(Error.INVALID_ID_REQUEST);
            }
        } else if (action.equals("indexedReadAll")) {
            try {
                Integer.parseInt(request.getParameter("lmt"));
                Integer.parseInt(request.getParameter("offst"));
            } catch (NumberFormatException e) {
                throw new AppException(Error.INVALID_LIMIT_OFFSET_PARAMETER);
            }
        }

    }

    @Override
    protected void postFilter(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {

    }

}
