package com.objectfrontier.training.service.util;

import java.util.List;

import javax.transaction.Transactional;

import org.springframework.stereotype.Service;

import com.objectfrontier.training.service.entity.model.Person;


@Service
@Transactional
public class TestService {
    
    @DataAccess(entity = Person.class)
    private GenericDAO<Person> personDAO;
    
    public List<Person> readAll() {
        return personDAO.findAll();
    }
}
