package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.Error;

/**
 * Servlet implementation class AddressServlet
 */
@WebServlet("/AddressServlet")
public class AddressServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AddressService addressService;
    private Properties addressProps;
    private Set<String> addressFields;
    ObjectMapper addressMapper = null;

    /**
     * @throws IOException 
     * @see HttpServlet#HttpServlet()
     */
    
    public AddressServlet(Connection addressConnection)  {
        super();
        
        this.addressService = new AddressService(new ConnectionManager(addressConnection));
        this.addressProps = new Properties();

        try {
            addressProps.load(getClass().getResourceAsStream("addressMapper.properties"));
        } catch (IOException e) {
            throw new AppException(Error.ERROR_MAPPING_RESOURCES);
        }

        addressFields = new HashSet<String>(addressProps.stringPropertyNames());
    }

    public AddressServlet() throws IOException {
        this(initiliseConnection());
    }

    static Connection initiliseConnection() {
        ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                "mysqlCredentials.txt");
        return connectionManager.getConnection();
    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        action(request.getParameter("action"), request, response);
    }

    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        action(req.getParameter("action"), req, resp);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        action(req.getParameter("action"), req, resp);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        action(req.getParameter("action"), req, resp);
    }

    void action(String action, HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();

        try {
            addressMapper = new ObjectMapper(Address.class);
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e1) {
            throw new AppException(Error.ERROR_MAPPING_RESOURCES);
        }

        Enumeration<String> parameters = request.getParameterNames();
        Collections.list(parameters)
                   .stream()
                   .filter(parameter -> request.getParameter(parameter) != null)
                   .forEach(parameter -> {
                       String methodAndPrameterType;
                       System.out.println(parameter);

                       if (addressFields.add(parameter) == false) {
                           methodAndPrameterType = addressProps.getProperty(parameter);
                           String[] params = methodAndPrameterType.split(",");
                           try {
                               addressMapper.setParameter(request.getParameter(parameter), params[0], params[1]);
                           } catch (ClassNotFoundException | ParseException e) {
                               throw new AppException(Error.ERROR_MAPPING_RESOURCES);
                           }
                       } else {
                           addressFields.remove(parameter);
                       }
                });

        Address address = (Address) addressMapper.getMappedObject();
        Properties addressProps = new Properties();
        addressProps.load(getClass().getResourceAsStream("addressGetterMapper.properties"));
        try {
            List<Address> result = new ArrayList<>();
            switch (action) {
                case "update":
                    result.add(addressService.update(address));
                    break;
                case "delete":
                    result.add(addressService.delete(address));
                    break;
                case "create":
                    result.add(addressService.create(address));
                    break;
                case "read":
                    result.add(addressService.read(address.getId()));
                    break;
                case "search":
                    String[] fields = request.getParameter("searchFields").split(",");
                    result = addressService.search(fields, "%"+request.getParameter("searchText")+"%");
                    break;
                case "readAll":
                    result = addressService.readAll();
                    break;
                case "indexedReadAll":
                    result = addressService.readAll(Integer.parseInt(request.getParameter("lmt")),
                                                   Integer.parseInt(request.getParameter("offst")));
                    break;
            }
            result.stream().forEach(addrzz -> {
                JSONMapper addressJsonMapper = new JSONMapper(addrzz, addressProps);
                try {
                    addressJsonMapper.prepareJSONString();
                } catch (NoSuchMethodException | SecurityException e) {
                    throw new AppException(Error.JSON_LOAD_ERROR);
                }
                out.write(addressJsonMapper.getJSONString());
            });
        } catch (AppException e) {
            out.write(e.toString());
        }
        out.close();
    }

}
