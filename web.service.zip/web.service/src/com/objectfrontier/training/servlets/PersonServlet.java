package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.io.PrintWriter;
import java.lang.reflect.InvocationTargetException;
import java.sql.Connection;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Enumeration;
import java.util.HashSet;
import java.util.List;
import java.util.Properties;
import java.util.Set;
import javax.json.JsonWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.objectfrontier.training.service.AddressService;
import com.objectfrontier.training.service.PersonService;
import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;
import com.objectfrontier.training.service.helper.AppException;
import com.objectfrontier.training.service.helper.ConnectionManager;
import com.objectfrontier.training.service.helper.Error;

/**
 * Servlet implementation class PersonServlet
 * @author Lokesh.
 * @since Nov 2, 2018
 */

@WebServlet("/PersonServlet")
public class PersonServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    private AddressService addressService;
    private PersonService personService;

    private Properties personProps;
    private Properties addressProps;
    private Set<String> addressFields;
    private Set<String> personFields;

    ObjectMapper personMapper = null;
    ObjectMapper addressMapper = null;

    /**
     * @see HttpServlet#HttpServlet()
     */
    public PersonServlet(Connection personConnection, Connection addressConnection)  {
        super();

        // Establishing connection to address and person service
        this.addressService = new AddressService(new ConnectionManager(addressConnection));
        this.personService = new PersonService(new ConnectionManager(personConnection), addressService);

        // personMapper.properties and addressMapper.properties which contain request parameter mapped to
        // respective setter methods of Person and Address classes are loaded.
        this.personProps = new Properties();
        this.addressProps = new Properties();
        try {
            personProps.load(getClass().getResourceAsStream("personMapper.properties"));
            addressProps.load(getClass().getResourceAsStream("addressMapper.properties"));
        } catch (IOException e) {
            throw new AppException(Error.ERROR_MAPPING_RESOURCES);
        }

        // Loading predefined request parameters from property files
        personFields = new HashSet<String>(personProps.stringPropertyNames());
        addressFields = new HashSet<String>(addressProps.stringPropertyNames());
    }

    public PersonServlet() throws IOException {
        this(initiliseConnection(),initiliseConnection());
    }

    static Connection initiliseConnection() {
        ConnectionManager connectionManager = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                "mysqlCredentials.txt");
        return connectionManager.getConnection();

    }

    /**
     * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        doPost(request, response);
    }


    /**
     * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
     *      response)
     */
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        action(req.getParameter("action"), req, resp);
    }

    @Override
    protected void doPut(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {

        action(req.getParameter("action"), req, resp);
    }

    @Override
    protected void doDelete(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        action(req.getParameter("action"), req, resp);
    }

    void action(String action, HttpServletRequest request, HttpServletResponse response) throws IOException {
        PrintWriter out = response.getWriter();

        try {
            personMapper = new ObjectMapper(Person.class);
            addressMapper = new ObjectMapper(Address.class);
        } catch (NoSuchMethodException | SecurityException | InstantiationException | IllegalAccessException
                | IllegalArgumentException | InvocationTargetException e1) {
            throw new AppException(Error.ERROR_MAPPING_RESOURCES);
        }

        Enumeration<String> parameters = request.getParameterNames();
        Collections.list(parameters)
                   .stream()
                   .filter(parameter -> request.getParameter(parameter) != null)
                   .forEach(parameter -> {
                       String methodAndPrameterType;
                       System.out.println(parameter);

                       if (personFields.add(parameter) == false) {
                           methodAndPrameterType = personProps.getProperty(parameter);

                           String[] params = methodAndPrameterType.split(",");
                           try {
                               personMapper.setParameter(request.getParameter(parameter), params[0], params[1]);
                           } catch (ClassNotFoundException | ParseException e) {
                               throw new AppException(Error.ERROR_MAPPING_RESOURCES);
                           }
                       } else if (addressFields.add(parameter) == false) {
                           methodAndPrameterType = addressProps.getProperty(parameter);

                           String[] params = methodAndPrameterType.split(",");
                           try {
                               addressMapper.setParameter(request.getParameter(parameter), params[0], params[1]);
                           } catch (ClassNotFoundException | ParseException e) {
                               throw new AppException(Error.ERROR_MAPPING_RESOURCES);
                           }

                           personFields.remove(parameter);
                       } else {
                           personFields.remove(parameter);
                           addressFields.remove(parameter);
                       }
                });

        Person person = (Person) personMapper.getMappedObject();
        Address address = (Address) addressMapper.getMappedObject();

        Properties personProps = new Properties();
        personProps.load(getClass().getResourceAsStream("personGetterMapper.properties"));
        Properties addressProps = new Properties();
        addressProps.load(getClass().getResourceAsStream("addressGetterMapper.properties"));

        person.setAddress(address);

        try {
            List<Person> result = new ArrayList<>();
            switch (action) {
                case "update":
                    result.add(personService.update(person));
                    break;
                case "delete":
                    result.add(personService.delete(person));
                    break;
                case "create":
                    result.add(personService.create(person));
                    break;
                case "read":
                    result.add(personService.read(person.getId(),
                               Boolean.parseBoolean(request.getParameter("addStatus"))));
                    break;
                case "readAll":
                    result = personService.readAll();
                    break;
                case "search":
                    String[] fields = request.getParameter("searchFields").split(",");
                    result = personService.searchPersonByAddress(fields, "%"+request.getParameter("searchText")+"%");
                    break;
                case "indexedReadAll":
                    result = personService.readAll(Integer.parseInt(request.getParameter("lmt")),
                                                   Integer.parseInt(request.getParameter("offst")));
                    break;
            }

            result.stream().forEach(perzon -> {
                JSONMapper personJsonMapper = new JSONMapper(perzon, personProps);
                try {
                    personJsonMapper.prepareJSONString();

                    if (perzon.getAddress() != null) {
                        JSONMapper addressJsonMapper = new JSONMapper(perzon.getAddress(), addressProps);
                        addressJsonMapper.prepareJSONString();
                        personJsonMapper.attach("address", addressJsonMapper.getObjectBuilder());
                    }
                } catch (NoSuchMethodException | SecurityException e) {
                    throw new AppException(Error.JSON_LOAD_ERROR);
                }
                out.write(personJsonMapper.getJSONString());
            });
            
        } catch (AppException e) {
            out.write(e.toString());
        }
        out.close();
    }
}
