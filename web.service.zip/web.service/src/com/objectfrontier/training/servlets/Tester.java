package com.objectfrontier.training.servlets;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.text.ParseException;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

import com.objectfrontier.training.service.entity.POJO.Address;
import com.objectfrontier.training.service.entity.POJO.Person;

public class Tester {

    public static void main(String[] args) {
        Tester obj = new Tester();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws IOException, NoSuchMethodException, SecurityException,
            InstantiationException, IllegalAccessException, IllegalArgumentException, InvocationTargetException,
            ClassNotFoundException, ParseException {

        Properties personProps = new Properties();
        personProps.load(getClass().getResourceAsStream("personGetterMapper.properties"));
        Properties addressProps = new Properties();
        addressProps.load(getClass().getResourceAsStream("addressGetterMapper.properties"));
        Person person = new Person();
        person.setFirstName("Lokesh");
        person.setLastName("Balaji");
        person.setBirthDate(LocalDate.now());
        person.setEmail("lokeshbalaji68@gmail.com");
        person.setId(new Long(20)); 
        Address address = new Address();
        address.setCity("Chennai");
        address.setId(new Long(30));
        address.setStreet("Hassan Khan Street");
        address.setPostalCode(new Long(512001));
        JSONMapper personJsonMapper = new JSONMapper(person, personProps);
        JSONMapper addressJsonMapper = new JSONMapper(address, addressProps);
        personJsonMapper.prepareJSONString();
        addressJsonMapper.prepareJSONString();
//        log("%s%n", personJsonMapper.getJSONString());
//        log("%s%n", addressJsonMapper.getJSONString());
        personJsonMapper.attach("address", addressJsonMapper.getObjectBuilder());
        log("%s%n", personJsonMapper.getJSONString());
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
