package com.ofs.training;

import java.util.Arrays;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.stream.Collectors;

public class CollectionToArrayConvertor {

    public static void main(String[] args) {
        CollectionToArrayConvertor obj = new CollectionToArrayConvertor();
        obj.run();

    }

    private void run() {

        String[] names = new String[] { "R.Lokesh",
                                        "R.Boovan",
                                        "R.vijaya",
                                        "N.Rajendran" };
        LinkedList<String> namesAsList = Arrays.stream(names)
                                               .collect(Collectors.toCollection(LinkedList::new));
        HashSet<String> namesAsSet = Arrays.stream(names)
                                           .collect(Collectors.toCollection(HashSet::new));
        List<String> nameAsListTwo = Arrays.asList(names);

        String[] namesFromCollection = namesAsList.stream().toArray(String[]::new);
        String[] nameFromCollectionTwo = nameAsListTwo.toArray(new String[nameAsListTwo.size()]);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
