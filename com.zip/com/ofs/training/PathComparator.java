package com.ofs.training;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

public class PathComparator {

    public static void main(String[] args) {
        PathComparator obj = new PathComparator();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws IOException, URISyntaxException {

                Path pathOne = Paths.get(getClass().getResource("test.csv").toURI());
                Path pathTwo = Paths.get(getClass().getResource("PathComparator.class").toURI());
                log("is %s and %s are same : %b", pathOne, pathTwo, pathOne.compareTo(pathTwo));

    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
