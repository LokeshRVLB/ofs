package com.ofs.training;

import java.util.Comparator;
import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 11, 2018
 */
public class DescFilterDemo {

    public static void main(String[] args) {

        DescFilterDemo descFilter = new DescFilterDemo();
        descFilter.run();
    }

    private void run() {

        List<Person> persons = Person.createRoster();
        persons.stream()
               .sorted(Comparator.comparing(Person::getAge)
                                 .reversed())
               .forEach(person -> log("%s\t%d%n", person.getName(),
                                                  person.getAge()));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }

}
