package com.ofs.training;

/**
 * @author Lokesh.
 * @since Aug 30, 2018
 */
public class FilePathFinder {

    public static void main(String[] args) {
        FilePathFinder obj = new FilePathFinder();

        try {
            obj.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run() {
        log("%s", getAbsolutePath(getCurrentClass()));
    }

    private String getAbsolutePath(Class currentClass) {
        return currentClass.getProtectionDomain()
                           .getCodeSource()
                           .getLocation()
                           .getFile() + currentClass.getName() + ".class";
    }

    private Class getCurrentClass() {
        return getClass();
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
