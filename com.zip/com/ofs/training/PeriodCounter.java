package com.ofs.training;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.TimeZone;

/**
 * @author Lokesh.
 * @since Sep 20, 2018
 */
public class PeriodCounter {

    public static void main(String[] args) {
        PeriodCounter obj = new PeriodCounter();
        obj.run();
    }

    private void run() {

        long startTime = System.currentTimeMillis();
        for (int i = 0; i<50; i++) {
            log("%s", "");
        }
        long endTime = System.currentTimeMillis();
        log("%s%n", getExecutionTime(endTime - startTime));
    }

    private String getExecutionTime(long time) {

        Date date = new Date(time);
        SimpleDateFormat dateFormater = new SimpleDateFormat("HH':'mm':'ss'.'S");
        dateFormater.setTimeZone(TimeZone.getTimeZone("UTC"));
        return dateFormater.format(date);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
