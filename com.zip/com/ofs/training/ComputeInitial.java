package com.ofs.training;

/**
 * @author Lokesh.
 * @since Aug 30, 2018
 */
public class ComputeInitial {

    private String fullName;

    ComputeInitial(String fullName) {
        this.fullName = fullName;
    }

    public static void main(String[] args) {
        ComputeInitial obj = new ComputeInitial("Rajendran Lokesh Balaji");

       try {
            obj.run();
        } catch (Exception t) {
            log(t);
        }
    }

    private void run() {
        log("Initial is : %s%n", getInitial());
    }

    private String getInitial() {
        StringBuilder initial = new StringBuilder();

        String[] nameParts = fullName.split(" ");
        for(String namePart : nameParts) {
            initial = initial.append(namePart.charAt(0));
        }
        return initial.toString();
    }

    private static void log(Exception t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
