package com.ofs.training;

import java.io.File;
import java.net.URL;
import java.util.Arrays;

/**
 * @author Lokesh.
 * @since Sep 17, 2018
 */
public class FilterDemo {

    public static void main(String[] args) {
        FilterDemo extensionFilter = new FilterDemo();
        extensionFilter.run();
    }

    private void run() {

        Class currentClass = getClass();
        URL filePath = currentClass.getResource("/com/ofs/training");
        log("%s", filePath);
        File directory = new File(filePath.getPath());

        if (directory.isFile()) {
            throw new RuntimeException("Enter valid direcotry path");
        }
        Arrays.stream(directory.list((parentDir, fileName) -> fileName.endsWith(".class")))
              .forEach(fileName -> log("%s%n", fileName));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
