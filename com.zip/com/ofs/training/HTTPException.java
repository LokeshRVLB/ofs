package com.ofs.training;

public class HTTPException extends Exception {

    private int errCode;

    HTTPException(int code) {

            this.errCode = code;
    }

    public String toString() {

        return (this.errCode + " : " + this.getCause());
    }
}
