package com.ofs.training;

/**
 * @author Lokesh.
 * @since Sep 20, 2018
 */
public class MilliNanoTimePrinter {

    public static void main(String[] args) {
        MilliNanoTimePrinter obj = new MilliNanoTimePrinter();
        obj.run();

    }

    private void run() {

        log("%d%n", System.currentTimeMillis());
        log("%d%n", System.nanoTime());
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
