package com.ofs.training;

/**
 * @author Lokesh.
 * @since Aug 30, 2018
 */
public class ArithmeticDemo {

    public static void main(String[] args) {

        ArithmeticDemo obj = new ArithmeticDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {
        int result = 1;

        result += 2;
        log("%d", result);

        result -= 1; // result is now 2
        log("%d", result);

        result *= result; // result is now 4
        log("%d", result);

        result /= 2; // result is now 2
        log("%d", result);

        result += 8; // result is now 10
        result %= 7; // result is now 3
        log("%d", result);
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
