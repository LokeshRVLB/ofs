package com.ofs.training;

import java.time.Month;
import java.time.Year;
import java.time.YearMonth;
import java.time.format.TextStyle;
import java.util.Locale;

public class MonthLengthCalculator {

    public static void main(String[] args) {
        MonthLengthCalculator obj = new MonthLengthCalculator();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        Year presentYear = Year.now();
        Month[] months = new Month[] { Month.JANUARY, Month.FEBRUARY,
                                 Month.MARCH, Month.APRIL,
                                 Month.MAY, Month.JUNE,
                                 Month.JULY, Month.AUGUST,
                                 Month.SEPTEMBER, Month.OCTOBER,
                                 Month.NOVEMBER, Month.DECEMBER };
        for (Month month : months) {
            log("%s : %s%n", month.getDisplayName(TextStyle.FULL, Locale.getDefault()),
                             YearMonth.of(presentYear.getValue(), month).lengthOfMonth());
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
