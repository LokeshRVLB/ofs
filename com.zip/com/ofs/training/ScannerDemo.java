package com.ofs.training;

import java.util.Scanner;

public class ScannerDemo {

    public static void main(String[] args) {
        ScannerDemo obj = new ScannerDemo();
        obj.run();

    }

    private void run() {

        Scanner scanner = new Scanner(System.in);
        log("Enter your Name%n");
        String name = scanner.next();
        log("Enter your age%n");
        int age = scanner.nextInt();
        log("Enter your phone number%nR");
        long phoneNo = scanner.nextLong();
        log("%s%n%d%n%d%n", name, age, phoneNo);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
