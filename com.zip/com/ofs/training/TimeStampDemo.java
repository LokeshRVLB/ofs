package com.ofs.training;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class TimeStampDemo {

    public static void main(String[] args) {
        TimeStampDemo obj = new TimeStampDemo();
        obj.run();

    }

    private void run() {

        LocalDateTime dateTime = LocalDateTime.now();
        log("%s%n", Timestamp.valueOf(dateTime));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
