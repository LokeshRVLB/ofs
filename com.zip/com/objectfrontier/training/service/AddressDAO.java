package com.objectfrontier.training.service;

public class AddressDAO {

}
