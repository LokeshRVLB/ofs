package com.objectfrontier.training.java.jdbc;

import java.util.ArrayDeque;
import java.util.Collection;

public class DataBaseException extends Exception {

    private String message;
    private Exception cause;
    private ArrayDeque<DataBaseException> exceptions = new ArrayDeque<>();
    
    public DataBaseException() {
        super();
    }

    public DataBaseException(Exception cause) {
        super();
        this.cause = cause;
    }
    
    public DataBaseException(String message) {
        super();
        this.message = message;
    }
    
    public DataBaseException(String message, Exception cause) {
        super();
        this.message = message;
        this.cause = cause;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public void setCause(Exception cause) {
        this.cause = cause;
    }


    public Exception getCause() {
        return cause;
    }

    public String getMessage() {
        return message;
    }

    public void add(DataBaseException dataBaseException) {
        exceptions.push(dataBaseException);
    }

    public int length() {
        return exceptions.size();
    }

    public DataBaseException get(DataBaseException dataBaseException) {
        return exceptions.pop();
    }

    public Collection<DataBaseException> getAssociateErrorsAsCollection() {
        return exceptions;
    }

}
