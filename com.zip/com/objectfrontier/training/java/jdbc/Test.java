package com.objectfrontier.training.java.jdbc;

import java.io.IOException;
import java.sql.SQLException;

public class Test {

    public static void main(String[] args) {
        Test obj = new Test();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        PersonService personService;
        ConnectionManager personDBConnection;
        try {
            personDBConnection = new ConnectionManager("jdbc:mysql://pc1620:3306/lokesh_rajendran",
                                                                          "mysqlCredentials.txt");
            personService = new PersonService(personDBConnection);
            try {
                personService.validatePersonId(1);
                log("done");
                Address address = new Address("indian street", "Delhi", 210221);
                address.setId(1);
                Person person = new Person("India", "india.country", address, Person.getDate(2018, 2, 2));
                person.setId(1);
                log("%d", personService.update(person));
            } catch (DataBaseException e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
        } catch (IOException | SQLException e) {
            new RuntimeException(e);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}

