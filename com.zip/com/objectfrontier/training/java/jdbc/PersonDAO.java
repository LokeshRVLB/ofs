package com.objectfrontier.training.java.jdbc;

import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 27, 2018
 */
public interface PersonDAO {

    List<Person> readAll() throws DataBaseException;
    Person read(int id) throws DataBaseException;
    Person read(int id, boolean includeAddress) throws DataBaseException;
    int update(Person person) throws DataBaseException;
    int delete(int id) throws DataBaseException;
    long insert(Person person) throws DataBaseException;
    <v> boolean isPresent(String field, v value) throws DataBaseException;
}
