package com.objectfrontier.training.java.jdbc;

public class DataBaseException extends Exception {

    private String message;
    private Exception cause;
    
    public String getMessage() {
        return message;
    }

}
