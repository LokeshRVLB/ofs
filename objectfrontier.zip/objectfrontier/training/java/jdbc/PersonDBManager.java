package com.objectfrontier.training.java.jdbc;

import java.util.List;

public class PersonDBManager implements PersonDAO {

    private ConnectionManager connectionManager;

    public PersonDBManager(ConnectionManager connectionManager) {
        super();
        this.connectionManager = connectionManager;
    }

    @Override
    public List<Person> readALL() {
        
        return null;
    }

    @Override
    public Person read(int id) {
        
        return null;
    }

    @Override
    public int update(Person person) {
        
        return 0;
    }

    @Override
    public int delete(int id) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public int insert(Person person) {
        // TODO Auto-generated method stub
        return 0;
    }

}
