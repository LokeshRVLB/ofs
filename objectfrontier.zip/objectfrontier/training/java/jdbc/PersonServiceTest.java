package com.objectfrontier.training.java.jdbc;

import java.text.MessageFormat;
import java.time.LocalDateTime;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

/**
 * @author Lokesh.
 * @since Sep 24, 2018
 */
public class PersonServiceTest {

    private PersonService personService;
    @BeforeClass
    private void initClass() {

        personService = new PersonService();
    }

    @Test (dataProvider = "positiveCase_insertRecord")
    private void insertRecordTest_positive(long expectedResult, Person person) {
        long actualResult = 0;
        try {
            actualResult = (personService.insertRecord(person));
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e.getMessage(), person));
        }
    }

    @Test (dataProvider = "negativeCase_insertRecord")
    private void insertRecordTest_negative(Person person, String expectedException, String expectedCause) {
        try {
            personService.insertRecord(person);
            Assert.fail(MessageFormat.format("Expected an Exception for {0}", person));
        } catch (Exception e) {
            Assert.assertEquals(e.getCause().getMessage(), expectedCause);
            Assert.assertEquals(e.getMessage(), expectedException);
        }
    }

    @Test (dataProvider = "positiveCase_delete")
    private void deleteTest_positive(long id, long expectedResult) {
        long actualResult = 0;
      try {
          actualResult = (personService.delete(id));
          Assert.assertEquals(actualResult, expectedResult);
      } catch (Exception e) {
          Assert.fail(MessageFormat.format("UnExpected behaviour {0} for input {1}", e.getMessage(), id));
      }
    }


//    @Test (dataProvider = "positiveCase_read")
//    private void readTest_positive(Person expectedResult, int id, boolean includeAddress) {
//        Person actualResult = null;
//        try {
//            actualResult = personService.read(id, includeAddress);
//            Assert.assertEquals(actualResult, expectedResult);
//        } catch (Exception e) {
//            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for id = {1}, includeAddress = {2}",
//                                                e.getMessage(),
//                                                id,
//                                                includeAddress));
//        }
//    }

    @Test
    private void updateRecordTest_positive(int expectedResult, int id, Person person) {
        int actualResult = 0;
        try {
            actualResult = personService.update(id, person);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            Assert.fail(MessageFormat.format("UnExpected behaviour {0} for id = {1}, includeAddress = {2}",
                                                e.getMessage(), id, person));
        }
    }

    @DataProvider (name = "positiveCase_insertRecord")
    private Object[][] insertRecordTest_positiveDP() {
        Address address = new Address("hassan khan street", "Chittoor", 517001);
        return new Object[][] {
            {6, new Person("R.Boovan", "boovanNaiks@gmail.com", address, Person.getDate(1997, 1, 1))},
            {7, new Person("R.Rajendran", "RajendranNaikar2@gmail.com", null, Person.getDate(1997, 1, 1))},
            {8, new Person("R.BoovanClone", "boovanNaiker3S@gmail.com", address, Person.getDate(1997, 1, 1))}
        };
    }

    @DataProvider (name = "negativeCase_insertRecord")
    private Object[][] insertRecordTEst_negativeDP() {
        Address address = new Address("hassan khan street", "Chittoor", 517001);
        return new Object[][] {
            {new Person("R.Boovan", "boovanNaik@gmail.com", address, Person.getDate(1997, 1, 1)),
                ERROR.SQL_DATA_ERROR,
                "Duplicate entry 'boovanNaik@gmail.com' for key 'email'"},
            {new Person("R.Rajendran", null, null, Person.getDate(1997, 1, 1)),
                ERROR.SQL_DATA_ERROR,
                "Column 'email' cannot be null"},
        };
    }

    @DataProvider (name = "positiveCase_delete")
    private Object[][] deleteTest_positiveDP() {
        Address address = new Address("hassan khan street", "Chittoor", 517001);
        return new Object[][] {
            {1, 1},
            {2, 1},
            {3, 1}
        };
    }

    @DataProvider (name = "positiveCase_read")
    private Object[][] readTest_positiveDP() {
        Address address = new Address("hassan khan street", "Chittoor", 517001);
        address.setId(3);
        Person personOne = new Person("R.Boovan", "boovanNaiks@gmail.com", address, Person.getDate(1997, 1, 1));
        personOne.setId(6);
        personOne.setCreatedDate(LocalDateTime.of(2018, 9, 24, 16, 47, 55));
        Person personTwo = new Person("R.Rajendran", "RajendranNaikar@gmail.com", null, Person.getDate(1997, 1, 1));
        personTwo.setId(7);
        personTwo.setCreatedDate(LocalDateTime.of(2018, 9, 24, 16, 47, 55));
        return new Object[][] {
            {personOne, 6, true},
            {personTwo, 7, false}
        };
    }
//
    @DataProvider(name = "positiveCase_update")
    private Object[][] updateTest_positiveDP() {
        return new Object[][] {
            
        };
    }
    @AfterClass
    private void afterClass() {

    }
}
