package com.objectfrontier.training.java.jdbc;

import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 27, 2018
 */
public interface PersonDAO {

    List<Person> readALL();
    Person read(int id);
    int update(Person person);
    int delete(int id);
    int insert(Person person);
}
