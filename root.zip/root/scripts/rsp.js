var rsp = {};

rsp.createView = () => rsp.init();

rsp.listenEvents = () => {
    listPanel.listenEvents();
    informationPanel.listenEvents();
}

rsp.setDefaults = () => listPanel.setDefaults();

rsp.init = () => {
    util.createChildren('html/rsp.html', 'mainPanel');
    listPanel.createView();
    informationPanel.createView();
}
