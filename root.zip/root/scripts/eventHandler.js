var subscribe = (eventName, callback, id) => {

    if (id === undefined) { document.addEventListener(eventName, callback); return;}
    document.getElementById(id).addEventListener(eventName, callback);
}

// var publish = (eventName, details) => document.dispatchEvent(new CustomEvent(eventName, details));

// var unsubscribe = (eventName, callback, id) => {
    // document.getElementById(id).removeEventListener(eventName, callback);
// }

// var unsubscribeAllEvents = (id) => document.getElementById(id)
                                           // .getEventListeners()
                                           // .click
                                           // .forEach((e)=>{e.remove()});