var login = {};

login.createView = () => util.createChildren('html/login.html', 'app');

var errorLog;
var validate = (element) => {

    let userName;
    let password;
    if (element.name === 'userName') {
        userName = element.value.trim();
    } else if (element.name === 'password') {
        password = element.value.trim();
    } else {
        userName = document.getElementById('userName').value.trim();
        password = document.getElementById('password').value.trim();
    }

    if (logError(getEmptyFieldErrors(userName, password))) { return; };
    if (logError(getFieldInputErrors(userName, password))) { return; };
    if (element.name === 'submit') {
        errorLog.style.display = 'none';
        var requestBody = 'user='+userName+'&pass='+password;
        var status = util.request('ws/login.html',
                                  'POST',
                                  () => {},
                                  null,
                                  requestBody,
                                  'application/x-www-form-urlencoded');
        if (status == 201) {
            app.init();
            return;
        }
        console.log("status " + status);
        // login.createView();
    }
}

var getEmptyFieldErrors = (userName, password) => {

    let errorMessage = '';
    if (userName === '') { errorMessage = errorMessage.concat('User name '); }
    if (password === '') { errorMessage = (errorMessage.length > 0)?errorMessage.concat('and Password ')
                                                                   :errorMessage.concat('Password '); }
    return errorMessage = errorMessage.length > 0?errorMessage.concat(' cannot be empty'):'';
}

var getFieldInputErrors = (userName, password) => {

    let errors = [];
    // if (userName !== undefined) {
        // errors.push('user name should contain only letters, numbers or underscore');
    // }
    if (password !== undefined && !/^(?=.*\d)(?=.*[a-z]).{6,}$/.test(password)) {
        errors.push('password should contain a number, alphabet and special character');
    }
    return errors.join('</br>');
}

var logError =(errorMessage) => {
    errorLog = document.getElementById('errorIndicator');
    if (errorMessage.length > 0) {
        errorLog.style.display = 'block';
        errorLog.innerHTML = errorMessage;
        return true;
    }
    return false;
}