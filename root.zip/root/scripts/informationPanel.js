var informationPanel = {};

informationPanel.createView = () => informationPanel.init();

informationPanel.listenEvents = () => {
    eventManager.subscribe("personItemSelected",
               informationPanel.loadPersonInformationPanel);
    eventManager.subscribe("addressItemSelected",
               informationPanel.loadAddressInformationPanel);
    eventManager.subscribe("personRecordSelected",
               informationPanel.loadPersonDetails);
    eventManager.subscribe("addressRecordSelected",
               informationPanel.loadAddressDetails);
    eventManager.subscribe("addPerson",
               informationPanel.setPersonAddAction);
    eventManager.subscribe("addAddress",
               informationPanel.setAddressAddAction);
    eventManager.subscribe("resetFields", () => {document.getElementById("informationForm")
                                            .reset();})
}

informationPanel.init = () => {
    util.createChildren('html/informationPanel.html', 'informationPanel');
}

informationPanel.setHeader = (heading) => document.getElementById("infoHeading")
                                                  .innerHTML = heading;

informationPanel.setPersonAddAction = () => {
    informationPanel.setHeader("Enter new Person details");
    unsubscribe('submit',
                informationPanel.createAddressRecord,
                "informationForm");
    subscribe("submit",
              informationPanel.createPersonRecord,
              "informationForm");
    document.getElementById("informationForm").reset();
}

informationPanel.setAddressAddAction = function () {
    informationPanel.setHeader("Enter new Address details");
          unsubscribe('submit',
                      informationPanel.createPersonRecord,
                      "informationForm");
          subscribe("submit",
                    informationPanel.createAddressRecord,
                    "informationForm"); 
    document.getElementById("informationForm").reset();
}

informationPanel.loadPersonInformationPanel = () => {
    util.request("html/personInformationPanel.html",
                 "GET",
                 (data) => document.getElementById("informationPanel")
                                   .innerHTML = data);
    listPanel.setDefaults();
}

informationPanel.createPersonRecord = () => {
    let param = {};
    param.firstName = document.getElementById("firstName").value;
    param.lastName = document.getElementById("lastName").value;
    param.dob = document.getElementById("dob").value;
    param.email = document.getElementById("email").value;
    eventManager.publish("createPersonRecord", { detail: param });
}

informationPanel.createAddressRecord = () => {
    let param = {};
    param.street = document.getElementById("street").value;
    param.city = document.getElementById("city").value;
    param.postalCode = document.getElementById("postalCode").value;
    eventManager.publish("createAddressRecord", { detail: param });
}

informationPanel.loadAddressInformationPanel = () => {
    util.request("html/addressInformationPanel.html",
                 "GET",
                 (data) => document.getElementById("informationPanel")
                                   .innerHTML = data);
    listPanel.setDefaults();
}

informationPanel.updatePersonRecord = () => {
    let param = {};
    param.firstName = document.getElementById("firstName").value;
    param.lastName = document.getElementById("lastName").value;
    param.dob = document.getElementById("dob").value;
    param.email = document.getElementById("email").value;
    eventManager.publish("updatePersonRecord", { detail: param });
}

informationPanel.updateAddressRecord = () => {
    let param = {};
    param.street = document.getElementById("street").value;
    param.city = document.getElementById("city").value;
    param.postalCode = document.getElementById("postalCode").value;
    eventManager.publish("updateAddressRecord", { detail: param });
}

informationPanel.loadPersonDetails = (event) => {
    let selectedRecord = event.detail.childNodes;
    console.log(selectedRecord);
    informationPanel.setHeader("Update Person with ID: " + selectedRecord[1].innerHTML);
    document.getElementById("firstName").value = selectedRecord[3].innerHTML;
    document.getElementById("lastName").value = selectedRecord[5].innerHTML;
    document.getElementById("dob").value = selectedRecord[7].innerHTML;
    document.getElementById("email").value = selectedRecord[9].innerHTML;
    unsubscribe('submit',
                informationPanel.createPersonRecord,
                "informationForm");
    subscribe("submit", informationPanel.updatePersonRecord, "informationForm");
    subscribe("click", informationPanel.loadResetD)
}


informationPanel.loadAddressDetails = (event) => {
    let selectedRecord = event.detail.childNodes;
    informationPanel.setHeader("Update Address with ID: " + selectedRecord[1].innerHTML);
    document.getElementById("street").value = selectedRecord[3].innerHTML;
    document.getElementById("city").value = selectedRecord[5].innerHTML;
    document.getElementById("postalCode").value = selectedRecord[7].innerHTML;
    document.getElementById("submit").click = informationPanel.updateAddressRecord();
    unsubscribe('submit',
                informationPanel.createAddressRecord,
                "informationForm");
    subscribe("submit", informationPanel.updateAddressRecord, "informationForm");
}