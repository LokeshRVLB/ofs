var listPanel = {};

listPanel.addressId = 0;
listPanel.personId = 0;

listPanel.createView = () => listPanel.init();

listPanel.listenEvents = function () {
    eventManager.subscribe("personItemSelected", listPanel.loadPersonList);
    eventManager.subscribe("addressItemSelected", listPanel.loadAddressList);
    eventManager.subscribe("updatePersonRecord", listPanel.updatePersonRecord);
    eventManager.subscribe("updateAddressRecord", listPanel.updateAddressRecord);
    eventManager.subscribe("createPersonRecord", listPanel.addPersonRecord);
    eventManager.subscribe("createAddressRecord", listPanel.addAddressRecord);
}

listPanel.setDefaults = () => {
    document.getElementById("list")
            .childNodes[0]
            .childNodes[1]
            .click();
}

listPanel.init = () => {
    util.createChildren('html/listPanel.html', 'listPanel');
}

listPanel.setHeading = (data) => document.getElementById("heading")
                                         .innerHTML = data;


listPanel.selectRecord = (recordSelected, recordOf) => {
    if (listPanel.highlighted !== undefined) {
        listPanel.highlighted.className = "record color-default";
    }

    listPanel.highlighted = recordSelected;
    listPanel.highlighted.className = "record color-highlight";

    if (recordOf === "person") {
        eventManager.publish("personRecordSelected", { detail: recordSelected });
        return;
    }
    eventManager.publish("addressRecordSelected", { detail: recordSelected });
}


listPanel.addAddressRecord = (event) => {

    let listTemplate = '';
    util.request("html/addressListTemplate.html",
                 "GET",
                 (data) => {listTemplate = data;});

    event.detail.id = ++listPanel.personId;
    document.getElementById('list').innerHTML += listPanel
                                                  .constructAddressRow(
                                                        event.detail,
                                                        listTemplate
                                                    );
    eventManager.publish("resetFields");
}

listPanel.addPersonRecord = (event) => {

    let listTemplate = '';
    util.request("html/personListTemplate.html",
                 "GET",
                 (data) => {listTemplate = data;});

    event.detail.id = ++listPanel.addressId;
    document.getElementById('list').innerHTML += listPanel
                                                  .constructPersonRow(
                                                        event.detail,
                                                        listTemplate
                                                   );
    eventManager.publish("resetFields");
}

listPanel.updateAddressRecord = (event) => {
    let listTemplate = '';
    util.request("html/addressListTemplate.html",
                 "GET",
                 (data) => {listTemplate = data;});
    let selectedRecord = listPanel.highlighted;
    event.detail.id = selectedRecord.childNodes[1].innerHTML;
    var status = util.request('ws/address/address.html?action=update',
                                  'POST',
                                  () => {},
                                  null,
                                  event.detail);
    if (status === 200) {
        selectedRecord.innerHTML = listPanel.constructAddressRow(
                                            event.detail, listTemplate);
        return;
    }
    console.log("update Address failed");

}

listPanel.updatePersonRecord = (event) => {
    let listTemplate = '';
    util.request("html/personListTemplate.html",
                 "GET",
                 (data) => {listTemplate = data;});

    let selectedRecord = listPanel.highlighted;
    event.detail.id = selectedRecord.childNodes[1].innerHTML;
    var status = util.request('ws/person/person.html?action=update',
                                  'POST',
                                  () => {},
                                  null,
                                  event.detail);
    if (status === 200) {
        selectedRecord.innerHTML = listPanel.constructPersonRow(
                                            event.detail, listTemplate);
        return;
    }
    console.log("update Person failed");
}

listPanel.loadPersonList = () => {
    subscribe("click",
               () => {
                    eventManager.publish("addPerson");
                    listPanel.highlighted.className = "record color-default";
                    listPanel.highlighted = undefined;
               }, 'addRecord');
    listPanel.setHeading("Person List");
    util.request("ws/person/person.html?action=readAll",
                 "GET",
                 listPanel.populateWithPersons,
                 "list");
}

listPanel.loadAddressList = () => {
    subscribe("click",
               () => {
                    eventManager.publish("addAddress");
                    listPanel.highlighted.className = "record color-default";
                    listPanel.highlighted = undefined;
                }, 'addRecord');
    listPanel.setHeading("Address List");
    util.request("ws/address/address.html?action=readAll",
                 "GET",
                 listPanel.populateWithAddresses,
                 "list");
}

listPanel.populateWithPersons = function (response, id) {

    let persons = JSON.parse(response);

    let header = ''
    util.request("html/personListHeaderTemplate.html",
                 "GET",
                 (data) => {header = data;});

    let listContent = '';
    let listTemplate = '';
    util.request("html/personListTemplate.html",
                 "GET",
                 (data) => {listTemplate = data;});

    listPanel.personId = 0;

    for (let i = 0; i < persons.length; i++) {
        let record = listTemplate;
        listContent += (listPanel.constructPersonRow(persons[i], record));
    }
    document.getElementById(id).innerHTML = header + listContent;
}

listPanel.populateWithAddresses = function (response, id) {

    let addresses = JSON.parse(response);
    let header = '';
    util.request("html/addressListHeaderTemplate.html",
                 "GET",
                 (data) => {header = data;});

    let listContent = '';
    let listTemplate = '';
    util.request("html/addressListTemplate.html",
                 "GET",
                 (data) => {listTemplate = data;});

    listPanel.addressId = 0;

    for (let i = 0; i < addresses.length; i++) {
        let record = listTemplate;
        listContent += (listPanel.constructAddressRow(addresses[i], record));
    }
    document.getElementById(id).innerHTML = header + listContent;
}

listPanel.constructPersonRow = function (person, record) {
    listPanel.personId++;
    console.log(person.personId);
    record = record.replace(/\$id/g, person.id)
                   .replace("$firstName", person.firstName)
                   .replace("$lastName", person.lastName)
                   .replace("$email", person.email)
                   .replace("$dob", person.dob);
    return record;
}

listPanel.constructAddressRow = function (address, record) {
    listPanel.addressId++;
    record = record.replace(/\$id/g, address.id)
                   .replace("$street", address.street)
                   .replace("$city", address.city)
                   .replace("$postalCode", address.postalCode);
    return record;
}

listPanel.remove = function (element, recordOf) {

    var sibling;
    var parent = element.parentNode;
    parent.onclick = () => false;
    if (listPanel.highlighted === parent) {
        if (parent.nextSibling !== null) {
            sibling = parent.nextSibling;
        } else if (parent.previousSibling !== null && parent.previousSibling.id !== 'listHeader') {
            sibling = parent.previousSibling;
        }else if (recordOf === 'person') {
            eventManager.publish("addPerson");
        } else {
            eventManager.publish("addAddress");
        }
    }
    parent.parentNode.removeChild(parent);
    if (sibling !== undefined) {
        sibling.click();
    }
}

