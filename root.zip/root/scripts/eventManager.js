var eventManager = {};

var Event = function (eventName, details) {
    this.eventName = eventName;
    this.detail = details;
}

eventManager.subscribed = {};

eventManager.subscribe = (eventName, callback, id) => {
    if (eventManager.subscribed[eventName] === undefined) {
        eventManager.subscribed[eventName] = [callback];
        return;
    }
    eventManager.subscribed[eventName].push(callback);
}

eventManager.dispatchEvent = (event) => {
    console.log(event);
    let callBacks = eventManager.subscribed[event.eventName];
    if (callBacks !== undefined) {
        for (let i = 0; i < callBacks.length; i++) {
            console.log("calling" + callBacks[i]);
            callBacks[i](event);
        }
    }
}

eventManager.publish = (eventName, data) => {
    var detail;
    if (data !== undefined) {
        detail = data.detail;
    }
    eventManager.dispatchEvent(new Event(eventName, detail));
}

var subscribe = (eventName, callback, id) => {

    if (id === undefined) { document.addEventListener(eventName, callback); return;}
    document.getElementById(id).addEventListener(eventName, callback);
}

var unsubscribe = (eventName, callback, id) => {
    document.getElementById(id).removeEventListener(eventName, callback);
}
