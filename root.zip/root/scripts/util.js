var util = {};

/**
    elementId parameter to requestHelper function specify the html element on which the call back has to be applied.
**/
util.request = (url, method, callback, elementId, requestBody, contentType) => {
    var status;
    let request = new XMLHttpRequest();
    request.onreadystatechange = function () {
        if (this.readyState < 4) {
            util.log('loading...', 'log info')
        }

        if (this.readyState === 4 
            && (this.status === 200
                || this.status === 201)) {
            console.log(this.status);
            console.log("response" + this.responseText);
            callback(this.responseText, elementId);
            return;
        }
        if (this.readyState === 4 && this.status !== 200) {
            util.log('Bad request', 'log failure');
        }
    }
    request.open(method, url, false);
    request.setRequestHeader('Content-Type', contentType);
    if (util.cookie !== undefined) {
        request.setRequestHeader('Cookie', util.cookie);
    }
    if (method === 'POST' || method === 'PUT'){
        request.send(requestBody);
        console.log(this.reponseText);
        util.cookie = request.getResponseHeader("Cookie");
        return request.status;
    }
    request.send();
    var returns = request.status;
    return returns;
}

util.log = (message) => console.log(message);
util.clear = (id) => document.getElementById(id).innerHTML = "";
util.createView = (data, id) => document.getElementById(id).innerHTML += data;
util.createChildren = (url, id) => { 
    util.request(url, 'GET', util.createView, id);
}