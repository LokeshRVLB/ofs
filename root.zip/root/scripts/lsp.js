var lsp = {};

lsp.createView = () => lsp.init();

lsp.onPersonItem = () => {
    document.getElementById('personItem')
            .className = 'sidebar-element active';
    document.getElementById('addressItem')
            .className = 'sidebar-element';
    eventManager.publish('personItemSelected');
}

lsp.onAddressItem = () => {
    document.getElementById('personItem')
            .className = 'sidebar-element';
    document.getElementById('addressItem')
            .className = 'sidebar-element active';
    eventManager.publish('addressItemSelected');
}

lsp.listenEvents = () => {

}

lsp.setDefaults = () => document.getElementById('personItem').click();

lsp.init = () => {
    util.createChildren("html/lsp.html", 'sidePanel');
}
