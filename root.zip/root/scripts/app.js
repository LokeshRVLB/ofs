var app = {};

app.createView = () => util.createChildren('html/app.html', 'app');
app.listenEvents = () => {}
app.setDefaults = () => {}


app.init = () => {
    if (util.cookie === undefined) {
       login.createView();
       return;
    }
    util.clear("app");
    app.createView();
    lsp.createView();
    rsp.createView();

    app.listenEvents();
    lsp.listenEvents();
    rsp.listenEvents();

    app.setDefaults();
    lsp.setDefaults();
    rsp.setDefaults();
}

document.body.onload = () => app.init();