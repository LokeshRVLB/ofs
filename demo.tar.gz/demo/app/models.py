from app import db

class Person(db.Model):
    """
    create person table that stores persons details
    """

    __tablename__ = 'persons'

    id = db.Column(db.Integer, primary_key=True)
    firstName = db.Column(db.String(20), nullable=False)
    lastName = db.Column(db.String(20), nullable=False)
    email = db.Column(db.String(60), nullable=False)
    addressId = db.Column(db.Integer, db.ForeignKey('addresses.id'))

class Address(db.Model):
    """
    create address table that stores persons address details
    """

    __tablename__ = 'addresses'

    id = db.Column(db.Integer, primary_key=True)
    street = db.Column(db.String(20))
    city = db.Column(db.String(20))
    postalCode = db.Column(db.Integer)