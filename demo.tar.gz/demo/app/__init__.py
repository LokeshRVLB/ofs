# app/__init__.py

# third-party imports
from flask import Flask
from flask_migrate import Migrate
from flask_sqlalchemy import SQLAlchemy

# local imports
from config import app_config

# db variable initialization
db = SQLAlchemy()


def create_app(config_name):
    app = Flask(__name__, instance_relative_config=True)
    app.config.from_object(app_config[config_name])
    # app.config.from_pyfile('instance/config.py')
    db.init_app(app)

    migrate = Migrate(app, db)

    from app import models

    @app.route("/")
    def readAll():
        return str(models.Person.query.all())
    
    return app
