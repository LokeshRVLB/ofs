#app/personService provides service to create, read, update and delete person data

#third party imports
import json
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
import pymysql

#local imports
from models import Person
#mysql+pymysql://lokesh:RVLBlokesh68@myrds.covg6nnxmrm9.ap-south-1.rds.amazonaws.com:3306/lokesh', echo=True
engine = create_engine('mysql+pymysql://loke:RVLB@loke=family@127.0.0.1:3306/test', echo=True)
Session = sessionmaker(bind=engine)

def create(event, handler):
    dic = json.loads(event['body'])
    person = Person(** dic)
    session = Session()
    session.add(person)
    session.commit()
    session.close()
    return {
        "statusCode": 200,
        "body": event['body']
    }

def update(event, handler):
    dic = json.loads(event['body'])
    session = Session()
    person = session.query(Person).get(dic['id'])
    print(person.__dict__)
    for key, value in dic.items():
        person.__dict__[key] = value
    print(person.__dict__)
    session.add(person)
    session.commit()
    session.close()
    return {
        "statusCode": 200,
        "body": event['body']
    }

def delete(event, handler):
    to_delete = event['pathParameters']['id']
    session = Session()
    person = session.query(Person).get(to_delete)
    session.commit()
    session.close()
    return {
        "statusCode": 204,
        "body": to_delete
    }

def read(event, handler):
    to_read = event['pathParameters']['id']
    result = dict()
    session = Session()
    person = session.query(Person).get(to_read)
    session.close()

    return {
        "statusCode": 200,
        "body": json.dumps(person.__dict__)
    }
