package com.objectfrontier.training.java.jdbc;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Types;
import java.text.MessageFormat;
import java.util.List;

public class PersonDBManager implements PersonDAO {

    private ConnectionManager connectionManager;
    final int NAME = 1;
    final int EMAIL = 2;
    final int ADDRESS = 3;
    final int BIRTH_DATE = 4;

    final int STREET = 1;
    final int CITY = 2;
    final int POSTAL_CODE = 3;

    public PersonDBManager(ConnectionManager connectionManager) {
        super();
        this.connectionManager = connectionManager;
    }

    @Override
    public List<Person> readALL() {

        return null;
    }

    @Override
    public Person read(int id) throws DataBaseException {
        try {
            String fetchAllQuery = MessageFormat.format("{0}{1}{2} {3}", "SELECT person.name, person.email,",
                    "address.street, address.id, address.city, address.postal_code,",
                    "person.birth_date, person.created_date ",
                    "FROM address,person WHERE address.id = person.address_id AND person.id = ?;");
            try (PreparedStatement statement = connectionManager.createStatement(fetchAllQuery)) {
                statement.setLong(1, id);
                try (ResultSet resultSet = connectionManager.executeQuery(statement)) {
                    Person person = new Person();
                    while (resultSet.next()) {
                        person.setId(id);
                        person.setName(resultSet.getString(1));
                        person.setEmail(resultSet.getString(2));
                        Address address = new Address(resultSet.getString(3), resultSet.getString(5),
                                resultSet.getLong(6));
                        address.setId(resultSet.getLong(4));
                        person.setAddress(address);
                        person.setBirthDate(resultSet.getDate(7).toLocalDate());
                        person.setCreatedDate(resultSet.getTimestamp(8).toLocalDateTime());
                    }
                    return person;
                }
            }
        } catch (SQLException e) {
            throw new DataBaseException();
        }
    }

    @Override
    public int update(int id, Person person) {
        try {
          if (person.getAddress() != null) {
              long addressId = 0;
              if ((addressId = getIdIFPersonHasAddress(id)) != 0) {
                  return updateRecord(id, person, true, false);
              } else {
                  return updateRecord(id, person, true, true);
              }
          } else {
              return updateRecord(id, person, false, false);
          }
      } catch (SQLException e) {
          throw new SQLException(ERROR.SQL_USER_ERROR, e);
      }
    }

    @Override
    public int delete(int id) {
        // TODO Auto-generated method stub
        return 0;
    }

    @Override
    public long insert(Person person) throws DataBaseException {
        Address address = person.getAddress();
        if (address != null) {
            createAddress(address);
        }
        return createPersonRecord(person);

    }

    private long createPersonRecord(Person person) throws DataBaseException {
        String personInsertquery = "INSERT INTO person(name, email, address_id, birth_date) VALUES(?, ?, ?, ?);";
        try (PreparedStatement statement = connectionManager.createStatement(personInsertquery,
                Statement.RETURN_GENERATED_KEYS)) {
            statement.setString(NAME, person.getName());

            statement.setString(EMAIL, person.getEmail());

            if (person.getAddress() != null) {
                statement.setLong(ADDRESS, person.getAddress().getId());
            } else {
                statement.setNull(ADDRESS, Types.BIGINT);
            }

            statement.setDate(BIRTH_DATE, java.sql.Date.valueOf(person.getBirthDate()));
            connectionManager.executeUpdate(statement);
            long personId = 0;

            try (ResultSet resultSet = statement.getGeneratedKeys()) {
                if (resultSet.next()) {
                    personId = resultSet.getInt(1);
                }
            }
            System.out.println(personId);
            return personId;
        } catch (SQLException e) {
            throw new DataBaseException("Unable to create person Record", e);
        }
    }

    public boolean isPresent(String field, Object value) throws DataBaseException {
        String getIdQuery = MessageFormat.format("SELECT {0} FROM person", field);
        try (PreparedStatement statement = connectionManager.createStatement(getIdQuery)) {
            try (ResultSet resultSet = statement.executeQuery()) {
                while (resultSet.next()) {
                    if (resultSet.getObject(1).equals(value)) {
                        return true;
                    }
                }
            }
            return false;
        } catch (SQLException e) {
            throw new DataBaseException("Failed to check email exsistance", e);
        }
    }

    private long createAddress(Address address) throws DataBaseException {
        long addressId = -1;
        if ((addressId = checkAddressExsistance(address)) != -1) {
            address.setId(addressId);
            return addressId;
        } else {
            String addressInsertQuery = "INSERT INTO address(street, city, postal_code) VALUES(?, ?, ?);";
            try (PreparedStatement statement = connectionManager.createStatement(addressInsertQuery,
                    Statement.RETURN_GENERATED_KEYS)) {

                statement.setString(STREET, address.getStreet());
                statement.setString(CITY, address.getCity());
                statement.setLong(POSTAL_CODE, address.getPostalCode());
                connectionManager.executeUpdate(statement);

                try (ResultSet resultSet = statement.getGeneratedKeys()) {
                    resultSet.next();
                    addressId = resultSet.getInt(1);
                }
                address.setId(addressId);
                return addressId;
            } catch (SQLException e) {
                throw new DataBaseException("Unable to create address Record", e);
            }
        }
    }

    private long checkAddressExsistance(Address address) throws DataBaseException {
        long id = 0;
        String getIdQuery = "SELECT id FROM address WHERE city = ? AND street = ? AND postal_code = ?;";

        try (PreparedStatement statement = connectionManager.createStatement(getIdQuery)) {
            statement.setString(1, address.getCity());
            statement.setString(2, address.getStreet());
            statement.setLong(3, address.getPostalCode());

            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    id = resultSet.getInt(1);
                    return id;
                }
                return -1;
            }
        } catch (SQLException e) {
            throw new DataBaseException("Failed to check address exsistance", e);
        }
    }

    @Override
    public Person read(int id, boolean includeAddress) throws DataBaseException {
        try {
            if (!includeAddress || getIdIFPersonHasAddress(id) == 0) {
                String fetchAllQuery = "SELECT person.name, person.email, person.birth_date, person.created_date "
                        + "FROM person WHERE person.id = ?;";
                try (PreparedStatement statement = connectionManager.createStatement(fetchAllQuery)) {
                    statement.setLong(1, id);
                    try (ResultSet resultSet = connectionManager.executeQuery(statement)) {
                        Person person = new Person();
                        while (resultSet.next()) {
                            person.setId(id);
                            person.setName(resultSet.getString(1));
                            person.setEmail(resultSet.getString(2));
                            person.setBirthDate(resultSet.getDate(3).toLocalDate());
                            person.setCreatedDate(resultSet.getTimestamp(4).toLocalDateTime());
                        }
                        return person;
                    }
                }
            }
        } catch (SQLException e) {
            throw new DataBaseException("Failed to read person record", e);
        }
        return read(id);
    }

    private long getIdIFPersonHasAddress(long id) throws SQLException {

        String getIdQuery = "SELECT address_id FROM person WHERE id = ?;";
        try (PreparedStatement statement = connectionManager.createStatement(getIdQuery)) {
            statement.setLong(1, id);
            try (ResultSet resultSet = statement.executeQuery()) {
                if (resultSet.next()) {
                    id = resultSet.getInt(1);
                    return id;
                }
                return 0;
            }
        }
    }

}
