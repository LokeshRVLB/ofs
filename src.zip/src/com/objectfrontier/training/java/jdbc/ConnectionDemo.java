package com.objectfrontier.training.java.jdbc;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

/**
 * @author Lokesh.
 * @since Sep 21, 2018
 */
public class ConnectionDemo {

    final int ID = 1;
    final int NAME = 2;
    final int EMAIL = 3;
    final int ADDRESS = 4;
    final int BIRTH_DATE = 5;
    final int CREATED_DATE = 6;
    final String CREATE_PERSON = "INSERT INTO person(name, email, address_id, birth_date) VALUE (?, ?, ?, ?);";
    final String CREATE_ADDRESS = "INSERT INTO address(street, city, postal_code) VALUE (?, ?, ?);";

    public static void main(String[] args) {
        ConnectionDemo obj = new ConnectionDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        String url = "jdbc:mysql://pc1620:3306/lokesh_rajendran";
        Person person = new Person();

        try (InputStream propertyFileStream = getClass().getResourceAsStream("mysqlCredentials.txt")){
            Properties mysqlCredentials = new Properties();
            mysqlCredentials.load(propertyFileStream);
            try (Connection connection = getConnection(url, mysqlCredentials)) {
                String query = "SELECT * FROM person";
                try (PreparedStatement statement = createStatement(connection, query)) {
//                    statement.setString(1, "Lokesh");
//                    statement.setLong(2, 1);
//                    int recordsUpdated = statement.executeUpdate();
//                    log("%d", recordsUpdated);
                    try (ResultSet resultSet = executeQuery(statement, query) ) {

                        while (resultSet.next()) {
                            person.setId(resultSet.getInt(ID));
                            person.setName(resultSet.getString(NAME));
                            person.setEmail(resultSet.getString(EMAIL));
                            person.setBirthDate(resultSet.getDate(BIRTH_DATE));
                        }
                        log("%s", person);
                    }
                }
            }catch (Exception e) {
                throw e;
            }
        } catch (Exception e) {
            throw new RuntimeException("Unable to read Properites File, check properties file details", e);
        }

    }

    private ResultSet executeQuery(Statement statement, String query) {
        try {
            ResultSet resultSet = statement.executeQuery(query);
            return resultSet;
        } catch (SQLException e) {
            throw new RuntimeException("Unable to Obtain result set, check query syntax", e);
        }
    }

    private PreparedStatement createStatement(Connection connection, String sqlQuery) {
        try {
            PreparedStatement statement = connection.prepareStatement(sqlQuery);;
            return statement;
        } catch (SQLException e) {
            throw new RuntimeException("Unable to create Statement", e);
        }
    }

    private Connection getConnection(String url, Properties info){
        try {
            Connection connection = DriverManager.getConnection(url, info);
            return connection;
        } catch (SQLException e) {
            throw new RuntimeException("Unable to open Connection, check credentials", e);
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
