package com.objectfrontier.training.java.jdbc;

import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.Properties;

/**
 * @author Lokesh.
 * @since Sep 21, 2018
 */
public class AddressService {

    final int ID = 1;
    final int NAME = 2;
    final int EMAIL = 3;
    final int ADDRESS = 4;
    final int BIRTH_DATE = 5;
    final int CREATED_DATE = 6;
    final String CREATE_PERSON = "INSERT INTO person(name, email, address_id, birth_date) VALUE (?, ?, ?, ?);";
    final String CREATE_ADDRESS = "INSERT INTO address(street, city, postal_code) VALUE (?, ?, ?);";

    public static void main(String[] args) {
        AddressService obj = new AddressService();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws ParseException {

        Person person = new Person(
                                       "Balaji",
                                       "lokeshbalaji68@gmail.com",
                                       new Address("Hassan Khan Street", "Chittoor", 517002),
                                       Person.getDate(1996, 6, 8).getTime()

                                  );
        String url = "jdbc:mysql://pc1620:3306/lokesh_rajendran";

        try (InputStream propertyFileStream = getClass().getResourceAsStream("mysqlCredentials.txt")){
            Properties mysqlCredentials = new Properties();
            mysqlCredentials.load(propertyFileStream);
            try (Connection connection = getConnection(url, mysqlCredentials)) {
                person = addPerson(person, connection);
            }catch (Exception e) {
                throw e;
            }
        } catch (Exception e) {
            throw new RuntimeException("Unable to read Properites File, check properties file details", e);
        }
    }

    private Person addPerson(Person person, Connection connection) {
        String query = CREATE_PERSON;
        try (PreparedStatement statement = createStatement(connection, query)) {
          try (ResultSet resultSet = executeQuery(statement, query) ) {

              while (resultSet.next()) {
                  person.setId(resultSet.getInt(ID));
                  person.setName(resultSet.getString(NAME));
                  person.setEmail(resultSet.getString(EMAIL));
                  person.setBirthDate(resultSet.getDate(BIRTH_DATE));
              }
              log("%s", person);
          }
          return null;
        }catch (Exception e) {
            // TODO: handle exception
        }
    }

    private PreparedStatement createStatement(Connection connection, String sqlQuery) {
        try {
            PreparedStatement statement = connection.prepareStatement(sqlQuery);;
            return statement;
        } catch (SQLException e) {
            throw new RuntimeException("Unable to create Statement", e);
        }
    }

    private Connection getConnection(String url, Properties info){
        try {
            Connection connection = DriverManager.getConnection(url, info);
            return connection;
        } catch (SQLException e) {
            throw new RuntimeException("Unable to open Connection, check credentials", e);
        }
    }


    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
