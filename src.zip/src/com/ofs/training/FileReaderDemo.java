package com.ofs.training;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Optional;
import java.util.stream.Collectors;

/**
 * @author Lokesh.
 * @since Sep 19, 2018
 */
public class FileReaderDemo {

    public static void main(String[] args) {
        FileReaderDemo obj = new FileReaderDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        if(args.length == 0 ) {
            throw new RuntimeException("Give atleast One file name");
        }

        if (args.length > 1) {
            throw new RuntimeException("Give only single file name");
        }
        Optional<String> fileContent = getFileContent(args[0]);
        if ( ! fileContent.isPresent()) {
            throw new RuntimeException("unable to read File");
        }
        log("%s%n", fileContent.get());

    }

    private Optional<String> getFileContent(String fileName) {
        try (InputStream fileStream = getClass().getResourceAsStream(fileName)){

            BufferedReader bufferedFileStream = new BufferedReader(new InputStreamReader(fileStream));
            return Optional.of(bufferedFileStream.lines()
                                                 .collect(Collectors.joining(System.lineSeparator())));
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
