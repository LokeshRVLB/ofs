package com.ofs.training;

import java.util.UUID;

public class UUIDDemo {

    public static void main(String[] args) {
        UUIDDemo obj = new UUIDDemo();
        obj.run();

    }

    private void run() {

        UUID uuid = UUID.randomUUID();
        log("%s%n", uuid);
        log("%d%n", uuid.variant());

    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
