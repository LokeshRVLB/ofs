package com.ofs.training;

import java.util.Date;

/**
 * @author Lokesh.
 * @since Sep 20, 2018
 */
public class EpochPrinter {

    public static void main(String[] args) {
        EpochPrinter obj = new EpochPrinter();
        obj.run();

    }

    private void run() {

        log("%s%n", System.currentTimeMillis());
        log("%s%n", new Date().getTime());
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
