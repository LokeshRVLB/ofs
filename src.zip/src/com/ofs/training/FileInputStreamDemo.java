package com.ofs.training;

import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;

/**
 * @author Lokesh.
 * @since Sep 17, 2018
 */
public class FileInputStreamDemo {

    public static void main(String[] args) {
        FileInputStreamDemo fileInputStreamDemo = new FileInputStreamDemo();

        try {
            fileInputStreamDemo.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws Throwable {

        File file = new File("src/main/java/com/ofs/training/FileInputStreamDemo.java");
        try (FileInputStream fileStream = new FileInputStream(file);
             BufferedInputStream bufferedStream = new BufferedInputStream(fileStream)) {
           byte[] contents = new byte[8096];
           bufferedStream.read(contents, 0, contents.length);

           for (byte content : contents) {
               log("%c", content);
           }
        } catch (Exception e) {
            throw e;
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
