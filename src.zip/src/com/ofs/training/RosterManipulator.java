package com.ofs.training;

import java.time.chrono.IsoChronology;
import java.util.ArrayList;
import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class RosterManipulator {

    public static void main(String[] args) {
        RosterManipulator obj = new RosterManipulator();
        obj.run();
    }

    private void run() {

        List<Person> newRoster = new ArrayList<>();

        newRoster.add(new Person("John",
                                 IsoChronology.INSTANCE.date(1980, 6, 20),
                                 Person.Sex.MALE,
                                 "john@example.com"));
        newRoster.add(new Person("Jade",
                                 IsoChronology.INSTANCE.date(1990, 7, 15),
                                 Person.Sex.FEMALE,
                                 "jade@example.com"));
        newRoster.add(new Person("Donald",
                                 IsoChronology.INSTANCE.date(1991, 8, 13),
                                 Person.Sex.MALE,
                                 "donald@example.com"));
        newRoster.add(new Person("Bob",
                                 IsoChronology.INSTANCE.date(2000, 9, 12),
                                 Person.Sex.MALE,
                                 "bob@example.com"));

        List<Person> persons = Person.createRoster();

        for (Person person : newRoster) {
            persons.add(person);
        }

//        persons.addAll(newRoster);
        log("Number of persons : %d%n", persons.size());

        persons.clear();
        log("Number of persons : %d%n", persons.size());
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
