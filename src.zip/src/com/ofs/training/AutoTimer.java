package com.ofs.training;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Timer;
import java.util.TimerTask;

/**
 * @author Lokesh.
 * @since Sep 20, 2018
 */
class MyMessage extends TimerTask{

    @Override
    public void run() {
        log("%s%n", LocalDateTime.now()
                                 .format(DateTimeFormatter.ofPattern("hh':'mm a  EEEE',' dd MMMM yyyy': Hi I am auto Counter'")));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}

public class AutoTimer {

    public static void main(String[] args) {
        AutoTimer obj = new AutoTimer();
        obj.run();

    }

    private void run() {
        MyMessage myMessage = new MyMessage();
        Timer timer = new Timer();
        timer.scheduleAtFixedRate(myMessage, 500, 1000);
    }
}
