package com.ofs.training;

import java.lang.reflect.Method;

//class MyJava {
public class MyJava {

    // public static execute(argument) {
    public static void main(String[] args) {

        // MyJava myJava = getCurrentProgram();
        // Console console = myJava.getConsole();

        // if (argument.isEmpty()) {
        //     console.print("No class file name given");
        //     return
        // }
        if (args.length == 0) {
            System.out.println("No class file name given");
            return;
        }

        // if (argument.isOutOfBound()) {
        //     console.print("Single class can only be executed");
        //     return
        // }
        if (! (args.length == 1)) {
            System.out.println("Single class can only be executed");
            return;
        }

        // if (! argument.classExists()) {
        //     console.print("Class doesnot exsits");
        //     return
        // }
        // Class classToBeExecuted = argument.getClass()

        Class classToBeExecuted = null;

        try {
            classToBeExecuted = Class.forName(args[0]);
        } catch (ClassNotFoundException e) {
            System.out.println("class not found");
        }

        // if (!classToBeExecuted.mainMethodExists()) {
        //     console.print("Main method is not defined in the class");
        //     return
        // }
        // Method method = classToBeExecuted.getMainMethod()
        Method method = null;

        try {
            method = classToBeExecuted.getMethod("main", String[].class);
        } catch (NoSuchMethodException e) {
            System.out.println(e);
        }

        // method.run();
        try {
            String[] arguments = null;
            method.invoke(null, arguments);
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
