package com.ofs.training;

import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */

public class AverageAgeFinder {

    public static void main(String[] args) {
        AverageAgeFinder averageAgeFinder = new AverageAgeFinder();
        averageAgeFinder.run();
    }

    private void run() {

        List<Person> persons = Person.createRoster();
        double averageAge = persons.stream()
                                   .mapToInt(person -> person.getAge())
                                   .mapToInt(Person::getAge)
                                   .average()
                                   .getAsDouble();

        log("%.2f%n", averageAge);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
