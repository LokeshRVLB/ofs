package com.ofs.training;

import java.util.List;

/**
 * @author Lokesh.
 * @since Sep 11, 2018
 */
public class DescFilter {

    public static void main(String[] args) {

        DescFilter descFilter = new DescFilter();
        descFilter.run();
    }

    private void run() {

        List<Person> persons = Person.createRoster();
        persons.stream().
                map(Person :: getAge).
                sorted((prev, next) -> prev.compareTo(next)).
                forEach(age -> log("%s%n", age));
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
