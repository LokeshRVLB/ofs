package com.ofs.training;

import org.testng.Assert;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;


/**
 * @author Lokesh.
 * @since Aug 31, 2018
 */

@Test
public class ArgumentAdderTest {

    private ArgumentAdder argumentAdder;

    @BeforeClass
    private void initClass() {

        argumentAdder = new ArgumentAdder();
    }

    @Test(dataProvider = "postiveCase_addArguments")
    private void testAddArguments_positive(int expected, String[] numbers) {

        int expectedResult = expected;
        int actualResult = 0;
        try {
            actualResult = argumentAdder.addArguments(numbers);
            Assert.assertEquals(actualResult, expectedResult);
        } catch (Exception e) {
            StringBuilder sBuilder = new StringBuilder();
            for (String number : numbers) {
                sBuilder.append(number + " ");
            }
            Assert.fail("Unexpected result for "
                    + sBuilder.toString()
                    + "expected result is "
                    + expectedResult
                    + " But actual result is "
                    + actualResult
                    , e);
        }
    }

    @Test(dataProvider = "negativeCase_addArguments")
    private void testAddArguments_negative(String expected, String[] numbers) {

        try {
            argumentAdder.addArguments(numbers);
            Assert.fail("Execpted an Exception");
        } catch (Exception e) {
            Assert.assertEquals(e.getMessage(), expected);
        }
    }

    @DataProvider(name = "postiveCase_addArguments")
    private Object[][] testAddArguments_positiveDP() {

        return new Object[][] {
            {5, new String[]{"3", "2"}},
            {6, new String[] {"2", "4"}},
            {20, new String[] {"10", "10"}}
        };
    }

    @DataProvider(name = "negativeCase_addArguments")
    private Object[][] testAddArguments_negativeDP() {

        return new Object[][] {
            {"Atlease two arguments are required for the program", new String[] {"5"}},
            {"Atlease two arguments are required for the program", new String[]{}},
        };
    }

    @AfterClass
    private void afterClass() {

    }
}
