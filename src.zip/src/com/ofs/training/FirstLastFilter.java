package com.ofs.training;

import java.util.List;
import java.util.stream.Stream;

import com.ofs.training.Person.Sex;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class FirstLastFilter {

    public static void main(String[] args) {
        FirstLastFilter obj = new FirstLastFilter();
        obj.run();
    }

    private void run() {

        List<Person> persons = Person.createRoster();
    //    persons.getStream();
        getStream(persons).findFirst();
        getStream(persons).findAny();
        getStream(persons).reduce((previous, next) -> next);
    }

    private Stream<Person> getStream(List<Person> persons) {
        return persons.stream().filter(person -> person.getGender() == Sex.MALE);
    }
}
