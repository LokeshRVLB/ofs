package com.ofs.training;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;

/**
 * @author Lokesh.
 * @since Sep 26, 2018
 */
public class FileReaderUsingPath {

    public static void main(String[] args) {
        FileReaderUsingPath obj = new FileReaderUsingPath();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws URISyntaxException, IOException {

        if(args.length == 0 ) {
            throw new RuntimeException("Give atleast One file name");
        }

        if (args.length > 1) {
            throw new RuntimeException("Give only single file name");
        }

        Path path = Paths.get(getClass().getResource(args[0]).toURI());
        byte[] buf = Files.readAllBytes(path);
        log("%s", new String(buf, StandardCharsets.UTF_8));
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
