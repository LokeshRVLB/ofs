package com.ofs.training;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Optional;
import java.util.Properties;


/**
 * @author Lokesh.
 * @since Sep 26, 2018
 */
public class PropertiedDemo {

    public static void main(String[] args) {
        PropertiedDemo obj = new PropertiedDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws FileNotFoundException, IOException {
        if (args.length == 0) {
            throw new RuntimeException("Enter key value as parameter");
        }
        String value = getValueFromKey(Optional.ofNullable(args[0]));
        log("%s%n", value);
    }

    private String getValueFromKey(Optional<String> key) throws FileNotFoundException, IOException {
        if (! key.isPresent()) {
            throw new RuntimeException("Specify Key value in arguments");
        }
        String keyName = key.get();
        Optional<String> value = Optional.ofNullable(System.getProperty(keyName));
        return value.orElseGet(() -> {
                                        Properties defaultProps = new Properties();
                                        Properties customisedProps = new Properties(defaultProps);
                                        try {
                                            defaultProps.load(new FileInputStream("D:/temp/defaults.properties"));
                                            customisedProps.load(new FileInputStream("D:/temp/customize.properties"));
                                        } catch (IOException e) {
                                            throw new RuntimeException("failed to load properties file");
                                        }
                                        Optional<String> valueFromFiles = Optional.of(customisedProps.getProperty(keyName));
                                        return valueFromFiles.orElseGet(() -> "lokesh.rajendran"); 
                                      });
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
