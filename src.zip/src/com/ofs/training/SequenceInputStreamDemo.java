package com.ofs.training;

import java.util.Vector;

/**
 * @author Lokesh.
 * @since Sep 17, 2018
 */
public class SequenceInputStreamDemo {

    public static void main(String[] args) {
        SequenceInputStreamDemo obj = new SequenceInputStreamDemo();

        try {
            obj.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run() throws Throwable {

        Vector<String> files = new Vector<>();
        getStream
        files.add();
        files.add(path + "SequenceInputStreamDemo.java");
        files.add(path + "ExtensionFilter.java");

//        InputStreamEnumerator inputStreamEnumerator = new InputStreamEnumerator(files);
//
//        try (InputStream inputStream = new SequenceInputStream(inputStreamEnumerator);
//             BufferedInputStream bufferedStream = new BufferedInputStream(inputStream)) {
//
//        } catch (NullPointerException e) {
//            throw e.initCause(new RuntimeException("Unable to Open File"));
//        } catch (IOException e) {
//            throw e;
//        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
