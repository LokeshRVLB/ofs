package com.ofs.training;

public class ExceptionThrower {

// TODO: Program to catch Exception and display cause and Description of the Exception

    // static void execute() {
    public static void main(String[] args) {

        String input = "index.html";

        // ExceptionThrower exceptionThrower = getCurrentProgram();
        // Server server = exceptionThrower.getServer();
        Server server = new Server();

        // Exception exception = server.getHTML(input);
        // Console console = exceptionThrower.getConsole();
        // console.print(exception.cause());
        // console.print(exception.description());
        try {
            server.getHTML("index.html");
        } catch (HTTPException e) {
            System.out.println("Exception cought is : " + e);
            System.out.println("Exception Description is : " + e.getCause().getMessage());
        }
    }
}
