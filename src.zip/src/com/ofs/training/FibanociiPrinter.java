package com.ofs.training;

public class FibanociiPrinter {

    static int preceder = 0;
    static int succesor = 1;

    public static void main(String[] args) {
        FibanociiPrinter obj = new FibanociiPrinter();

        try {
            obj.run();
        } catch (Exception t) {
            log(t);
        }
    }

    private void run() {
        int limitOfSeries = 10;
        printSeriesUsingFor(limitOfSeries);
        printSeriesUsingWhile(limitOfSeries);
        printSeriesUsingRecursion(limitOfSeries);
    }

    private void printSeriesUsingFor(int limitOfSeries) {
        int preceder = 0;
        int succesor = 1;
        log("%d\t%d\t", preceder, succesor);

        for (int count = 0; count < limitOfSeries - 2; count++) {
            log("%d\t", succesor += preceder);
            preceder = succesor - preceder;
        }
        log("%n");
    }

    private void printSeriesUsingWhile(int limitOfSeries) {
        int preceder = 0;
        int succesor = 1;
        log("%d\t%d\t", preceder, succesor);

        while (( limitOfSeries - 2 ) > 0) {
            log("%d\t", succesor += preceder);
            preceder = succesor - preceder;
            limitOfSeries--;
        }
        log("%n");
    }

    private void printSeriesUsingRecursion(int limitOfSeries) {
        log("%d\t%d\t", preceder, succesor += preceder);
        fibanocii(new Integer(limitOfSeries - 2));
        preceder = 0;
        succesor = 1;
        log("%n");
    }

    private void fibanocii(int start) {

        if (start == 1) {
            log("%d", preceder + succesor );
            return;
        }
        log("%d\t", succesor += preceder);
        preceder = succesor - preceder;
        fibanocii(start -= 1);
    }

    private static void log(Exception t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
