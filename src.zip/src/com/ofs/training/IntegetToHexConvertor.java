package com.ofs.training;

public class IntegetToHexConvertor {

    public static void main(String[] args) {
        int decimalValue = 65;
        System.out.printf("Hexadecimal representation is %s", Integer.toHexString(decimalValue));
    }
}
