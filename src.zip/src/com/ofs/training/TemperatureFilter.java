package com.ofs.training;

import java.util.ArrayList;

/**
 * @author Lokesh.
 * @since Sep 10, 2018
 */
public class TemperatureFilter {

    public static void main(String[] args) {
        TemperatureFilter obj = new TemperatureFilter();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        ArrayList<Country> countries = new ArrayList<>(6);
        countries.add(new Country("India", 32));
        countries.add(new Country("Pakistan", 33));
        countries.add(new Country("China", 31));
        countries.add(new Country("America", 32));
        countries.add(new Country("Russia",32));

        countries.stream().
                  filter(country -> country.getTemperature() > 31).
                  map(Country :: getName).
                  forEach(name -> log("%s%n", name));
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
