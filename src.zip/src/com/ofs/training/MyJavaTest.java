package com.ofs.training;

import java.lang.reflect.Method;

/**
 * @author Lokesh.
 * @since Sep 4, 2018
 */
public class MyJavaTest {

    public static void main(String[] args) {

        MyJavaTest obj = new MyJavaTest();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws Exception{

        if (args.length == 0) {
            throw new RuntimeException("No Executable class given");
        }

        if (args.length != 1) {
            throw new RuntimeException("multiple class cannot be passed as an argument");
        }

        this.invokeProgram(args[0]);
    }

    private void invokeProgram(String classToBeInitiated) throws Exception{
        Method mainMethod = getMainMethod(getClassInstance(classToBeInitiated));
        this.invokeMethod(mainMethod);
    }

    private void invokeMethod(Method mainMethod) throws Exception {
        String[] arguments = null;
        mainMethod.invoke(null, arguments);
    }

    private Method getMainMethod(Class classInstance) throws Exception{
        return classInstance.getMethod("main", String[].class);
    }

    private Class getClassInstance(String classToBeInitiated) throws Exception {
        return Class.forName(classToBeInitiated);
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
