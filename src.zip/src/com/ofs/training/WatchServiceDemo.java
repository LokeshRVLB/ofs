package com.ofs.training;

import java.io.IOException;
import java.net.URISyntaxException;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardWatchEventKinds;
import java.nio.file.WatchKey;
import java.nio.file.WatchService;
import java.util.concurrent.TimeUnit;

import javafx.scene.chart.PieChart.Data;

/**
 * @author Lokesh.
 * @since Sep 26, 2018
 */
public class WatchServiceDemo {

    public static void main(String[] args) {
        WatchServiceDemo obj = new WatchServiceDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) throws URISyntaxException, IOException, InterruptedException {

        Path path = Paths.get(getClass().getResource(".").toURI());
        WatchService watchService = path.getFileSystem().newWatchService();
        path.register(watchService, StandardWatchEventKinds.ENTRY_CREATE);
        WatchKey watchKey = null;
        while (true) {
            watchKey = watchService.poll(10, TimeUnit.MINUTES);
            if (watchKey != null) {
                watchKey.pollEvents().stream().forEach(data -> log("%s%n", data));
            }
            watchKey.reset();
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
