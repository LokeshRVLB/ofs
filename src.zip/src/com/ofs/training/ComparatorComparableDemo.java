package com.ofs.training;

import java.util.Collections;
import java.util.Comparator;
import java.util.List;

class NameComparator implements Comparator<Person> {

    @Override
    public int compare(Person o1, Person o2) {
        return o1.getName().compareTo(o2.getName());
    }
    
}

public class ComparatorComparableDemo {

    public static void main(String[] args) {
        ComparatorComparableDemo obj = new ComparatorComparableDemo();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        //Comparable
        List<Person> persons = Person.createRoster();
        Collections.sort(persons);
        persons.stream().forEach(person -> log("%s : %d%n",person.getName(), person.getAge()));
        log("%n");
        //comparator
        Collections.sort(persons, new NameComparator());
        persons.stream().forEach(person -> log("%s : %d%n",person.getName(), person.getAge()));
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
