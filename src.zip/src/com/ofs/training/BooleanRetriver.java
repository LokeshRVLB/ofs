package com.ofs.training;

/**
 * @author Lokesh.
 * @since Sep 3, 2018
 */
public class BooleanRetriver {

    public static void main(String[] args) {
        BooleanRetriver obj = new BooleanRetriver();

        try {
            obj.run();
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run() {
        int userId = 13;
        displayDetails(userId);
    }

    private void displayDetails(int userId) {
        log("is Married : %b%n", isMarried(userId));
        log("is Disabled : %b%n", isDisabled(userId));
        log("is Working : %b%n", isWorking(userId));
        log("is Indian : %b%n", isIndian(userId));
    }

    private boolean isIndian(int userId) {
        return 1 == (1 & userId);
    }

    private boolean isWorking(int userId) {
        return 2 == (2 & userId);
    }

    private boolean isDisabled(int userId) {
        return 3 == (3 & userId);
    }

    private boolean isMarried(int userId) {
        return 4 == (4 & userId);
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
