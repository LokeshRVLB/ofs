package com.ofs.training;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Optional;
import java.util.stream.Collectors;

import javafx.scene.chart.PieChart.Data;

/**
 * @author Lokesh.
 * @since Sep 19, 2018
 */
public class CSVParser {

    public static void main(String[] args) {
        CSVParser obj = new CSVParser();

        try {
            obj.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        inputStreamToString();
    }

    private Optional<String> inputStreamToString() {

        try (InputStream fileStream = getClass().getResourceAsStream("test.csv")){
            BufferedReader csvStream = new BufferedReader(new InputStreamReader(fileStream));
            return csvStream.lines()
                            .collect(Collectors.joining(System.lineSeparator()))
                            .;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
