package com.ofs.training;

import java.util.HashSet;
import java.util.Optional;

public class OptionalDemo {

    public static void main(String[] args) {
        OptionalDemo obj = new OptionalDemo();
        obj.run();

    }

    private void run() {

        String name = null;
        String street = "India";
        Optional<String> optionalName = Optional.ofNullable(name);
        Optional<String> optionalStreet = Optional.ofNullable(street);
        HashSet<String> person = new HashSet<>(2);
        if (optionalName.isPresent()) { log("%s%n", optionalName.get()); }
        if (optionalStreet.isPresent()) { log("%s%n", optionalStreet.get()); }

    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
