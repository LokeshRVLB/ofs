package com.ofs.training;

import java.io.File;

/**
 * @author Lokesh.
 * @since Sep 17, 2018
 */
public class PermissionFinder {

    public static void main(String[] args) {
        PermissionFinder permissionFinder = new PermissionFinder();

        try {
            permissionFinder.run(args);
        } catch (Throwable t) {
            log(t);
        }
    }

    private void run(String[] args) {

        if (args.length == 0) {
            throw new RuntimeException("No file specified");
        }

        for (String fileName : args) {
            log("File Name : %s%n", fileName);
            File file = new File(fileName);
            log("is Writable: %b%nis Readable: %b%nisExecutable: %b%n",
                    file.canWrite(),
                    file.canRead(),
                    file.canExecute());
        }
    }

    private static void log(Throwable t) {
        t.printStackTrace(System.err);
    }

    private static void log(String format, Object... vals) {
        System.out.format(format, vals);
    }
}
