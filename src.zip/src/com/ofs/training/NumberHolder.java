package com.ofs.training;

public class NumberHolder {

    public int anInt;
    public float aFloat;

    public static void main(String[] args) {

        NumberHolder numberHolder = new NumberHolder();
        numberHolder.anInt = 2;
        numberHolder.aFloat = 3.0f;
        System.out.printf("anInt : %d \naFloat : %f", numberHolder.anInt, numberHolder.aFloat);
    }
}
