package com.objectfrontier.training.java.jdbc;

import java.time.DayOfWeek;
import java.time.LocalDate;
import java.time.Month;
import java.time.format.DateTimeFormatter;
import java.time.temporal.TemporalAdjusters;

/**
 * @author Lokesh.
 * @since Aug 31, 2018
 */
public class MondayCounter {

    public static void main(String[] args) {

        MondayCounter obj = new MondayCounter();
        obj.run();
    }

    private void run() {

        LocalDate presentYearMonth = LocalDate.of(2018, Month.SEPTEMBER, 1);
        Month presentMonth = presentYearMonth.getMonth();
        LocalDate resultDate = presentYearMonth.with(TemporalAdjusters.nextOrSame(DayOfWeek.MONDAY));
        log(resultDate);
        presentYearMonth = resultDate;
        while (true) {
            resultDate = presentYearMonth.with(TemporalAdjusters.next(DayOfWeek.MONDAY));
            if (resultDate.getMonth() == presentMonth) {
                log(resultDate);
                presentYearMonth = resultDate;
                continue;
            }
            break;
        }
    }

    private static void log(LocalDate date) {
        System.out.println(date.format(DateTimeFormatter.ofPattern("MM/dd/yyyy")));
    }
}